/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jfree.data;

import java.awt.Paint;
import java.util.HashMap;
import java.util.Map;

import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.ojalgo.chart.ChartBuilder;
import org.ojalgo.chart.Type;

import se.optimatika.jfree.chart.JFreeChartAdaptor;

abstract class AbstractSeriesData<K extends Comparable<K>, V extends Number> extends JFreeChartBuilder {

    private final Map<String, Paint> myColours = new HashMap<String, Paint>();
    private String myDomainAxisLabel = null;
    private String myRangeAxisLabel = null;

    public AbstractSeriesData(Type aType) {
        super(aType);
    }

    @Override
    public final JFreeChartAdaptor build(Type aType) {

        switch (aType) {

        case Histogram:

            return this.createHistogram(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getIntervalXYData(), this.getJFreeOrientation(), this.isLegend());

        case PolarChart:

            return this.createPolarChart(this.getTitle(), this.getXYData(), this.isLegend());

        case ScatterPlot:

            return this.createScatterPlot(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getXYData(), this.getJFreeOrientation(), this.isLegend());

        case StackedAreaXYChart:

            return this.createStackedXYAreaChart(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getTableXYData(), this.getJFreeOrientation(), this.isLegend(), myColours);

        case TimeSeriesChart:

            return this.createTimeSeriesChart(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getXYData(), this.isLegend(), myColours, true, true);

        case XYAreaChart:

            return this.createXYAreaChart(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getXYData(), this.getJFreeOrientation(), this.isLegend());

        case XYBarChart:

            return this.createXYBarChart(this.getTitle(), myDomainAxisLabel, this.isDomainTime(), myRangeAxisLabel, this.getIntervalXYData(), this.getJFreeOrientation(), this.isLegend());

        case XYLineChart:

            return this.createXYLineChart(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getXYData(), this.getJFreeOrientation(), this.isLegend());

        case XYStepAreaChart:

            return this.createXYStepAreaChart(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getXYData(), this.getJFreeOrientation(), this.isLegend());

        case XYStepChart:

            return this.createXYStepChart(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getXYData(), this.getJFreeOrientation(), this.isLegend());

        default:

            return this.createScatterPlot(this.getTitle(), myDomainAxisLabel, myRangeAxisLabel, this.getXYData(), this.getJFreeOrientation(), this.isLegend());
        }
    }

    public final ChartBuilder domainAxisLabel(String aLabel) {
        myDomainAxisLabel = aLabel;
        return this;
    }

    public final ChartBuilder rangeAxisLabel(String aLabel) {
        myRangeAxisLabel = aLabel;
        return this;
    }

    protected abstract IntervalXYDataset getIntervalXYData();

    protected abstract TableXYDataset getTableXYData();

    protected abstract XYDataset getXYData();

    protected abstract boolean isDomainTime();

    protected final Paint setSeriesPaint(String aSeriesName, Paint aSeriesPaint) {
        return myColours.put(aSeriesName, aSeriesPaint);
    }

}
