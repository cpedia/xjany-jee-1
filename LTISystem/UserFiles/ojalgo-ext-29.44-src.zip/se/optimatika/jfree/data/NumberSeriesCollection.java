/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jfree.data;

import java.util.Map;

import org.jfree.data.xy.DefaultTableXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.ojalgo.chart.Type;
import org.ojalgo.series.BasicSeries;

/**
 * XYSeriesData
 * 
 * @author apete
 */
public class NumberSeriesCollection<N extends Number & Comparable<N>> extends AbstractSeriesData<N, N> {

    private static final class NumberSeries<NN extends Number & Comparable<NN>> extends XYSeries {

        public NumberSeries(BasicSeries<NN, NN> aSeries) {

            super(aSeries.getName(), true, false);

            for (Map.Entry<NN, NN> tmpEntry : aSeries.entrySet()) {
                this.add(tmpEntry.getKey(), tmpEntry.getValue());
            }
        }
    }

    private final XYSeriesCollection myCollection = new XYSeriesCollection();

    public NumberSeriesCollection(Type aType) {
        super(aType);
    }

    public void addSeries(BasicSeries<N, N> aSeries) {
        myCollection.addSeries(new NumberSeries<N>(aSeries));
        this.setSeriesPaint(aSeries.getName(), aSeries.getColour());
    }

    @Override
    protected IntervalXYDataset getIntervalXYData() {
        return myCollection;
    }

    @Override
    protected TableXYDataset getTableXYData() {

        DefaultTableXYDataset retVal = new DefaultTableXYDataset();

        for (Object tmpXYSeries : myCollection.getSeries()) {
            retVal.addSeries((XYSeries) tmpXYSeries);
        }

        return retVal;
    }

    @Override
    protected XYDataset getXYData() {
        return myCollection;
    }

    @Override
    protected boolean isDomainTime() {
        return false;
    }
}
