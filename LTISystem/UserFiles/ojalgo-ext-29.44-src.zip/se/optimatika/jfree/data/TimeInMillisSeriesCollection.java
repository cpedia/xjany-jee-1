/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jfree.data;

import java.util.Map;

import org.jfree.data.time.FixedMillisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeriesDataItem;
import org.jfree.data.xy.DefaultTableXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.ojalgo.chart.Type;
import org.ojalgo.random.RandomNumber;
import org.ojalgo.series.BasicTimeSeries;
import org.ojalgo.series.CoordinationSet;
import org.ojalgo.series.TimeInMillisSeries;

/**
 * TimeSeriesData
 * 
 * @author apete
 */
public class TimeInMillisSeriesCollection<N extends Number> extends AbstractSeriesData<Long, N> {

    private static final class RandomSeries<NN extends Number> extends TimeSeries {

        public RandomSeries(TimeInMillisSeries<NN> aSeries) {

            super(aSeries.getName(), FixedMillisecond.class);

            for (Map.Entry<Long, NN> tmpEntry : aSeries.entrySet()) {
                this.add(new TimeSeriesDataItem(new FixedMillisecond(tmpEntry.getKey()), tmpEntry.getValue()));
            }
        }

    }

    private final TimeSeriesCollection myCollection = new TimeSeriesCollection() {

        @Override
        public Number getEndY(int someSeries, int someItem) {

            Number tmpVal = super.getY(someSeries, someItem);

            if (tmpVal instanceof RandomNumber) {
                return ((RandomNumber) tmpVal).getExpected() + ((RandomNumber) tmpVal).getStandardDeviation();
            } else {
                return tmpVal;
            }
        }

        @Override
        public Number getStartY(int someSeries, int someItem) {

            Number tmpVal = super.getY(someSeries, someItem);

            if (tmpVal instanceof RandomNumber) {
                return ((RandomNumber) tmpVal).getExpected() - ((RandomNumber) tmpVal).getStandardDeviation();
            } else {
                return tmpVal;
            }
        }

        @Override
        public Number getY(int someSeries, int someItem) {

            Number tmpVal = super.getY(someSeries, someItem);

            if (tmpVal instanceof RandomNumber) {
                return ((RandomNumber) tmpVal).getExpected();
            } else {
                return tmpVal;
            }
        }

    };

    public TimeInMillisSeriesCollection(Type aType) {

        super(aType);

        this.legend(true);
    }

    public void addSeries(BasicTimeSeries<?, N> aSeries) {
        this.addSeries(aSeries.getTimeInMillisSeries());
    }

    public void addSeries(CoordinationSet<?, N> aSet) {
        for (BasicTimeSeries<?, N> tmpSeries : aSet.values()) {
            this.addSeries(tmpSeries.getTimeInMillisSeries());
        }
    }

    public void addSeries(TimeInMillisSeries<N> aSeries) {
        myCollection.addSeries(new RandomSeries<N>(aSeries));
        this.setSeriesPaint(aSeries.getName(), aSeries.getColour());
    }

    @Override
    protected IntervalXYDataset getIntervalXYData() {
        return myCollection;
    }

    @Override
    protected TableXYDataset getTableXYData() {

        DefaultTableXYDataset retVal = new DefaultTableXYDataset();

        for (Object tmpSeries : myCollection.getSeries()) {
            retVal.addSeries((XYSeries) tmpSeries);
        }

        return retVal;
    }

    @Override
    protected XYDataset getXYData() {
        return myCollection;
    }

    @Override
    protected boolean isDomainTime() {
        return true;
    }

}
