/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.type.StandardType;
import org.ojalgo.type.context.NumberContext;

/**
 * <p>
 * An asset is a financial instrument that can be bought and sold, and
 * something that can be put in a portfolio.
 * </p><p>
 * A portfolio is a collection/combination of assets.
 * </p><p>
 * Any asset can be viewed as a portfolio containing only itself.
 * </p>
 *
 * @author apete
 */
public abstract class FinancePortfolio {

    protected static final NumberContext CONTEXT_PARAMETER = StandardType.DECIMAL_064;
    protected static final NumberContext CONTEXT_WEIGHT = StandardType.PERCENT;

    protected FinancePortfolio() {
        super();
    }

    /**
     * The mean/expected return of this instrument. 
     * May return either the absolute or excess return of the instrument. 
     * The context in which an instance is used should make it clear 
     * which. Calling {@linkplain #shift(Number)} with an appropriate
     * argument will transform between absolute and excess return. 
     */
    public abstract BigDecimal getMeanReturn();

    /**
     * The instrument's return variance.
     * 
     * Subclasses must override either {@linkplain #getReturnVariance()} or {@linkplain #getVolatility()}.
     */
    public BigDecimal getReturnVariance() {
        return BigFunction.POWER.invoke(this.getVolatility(), 2);
    }

    /**
     * Volatility refers to the standard deviation of 
     * the change in value of an asset with a specific 
     * time horizon. It is often used to quantify the risk of the 
     * asset over that time period.
     * 
     * Subclasses must override either {@linkplain #getReturnVariance()} or {@linkplain #getVolatility()}.
     */
    public BigDecimal getVolatility() {
        return BigFunction.SQRT.invoke(this.getReturnVariance());
    }

    /**
     * This method returns a list of the weights of the Portfolio's
     * contained assets. A portfolio weight is NOT restricted to being
     * a share/percentage - it can be anything. Most subclasses do
     * however assume that the list of portfolio weights are
     * shares/percentages that sum up to 100%. Calling
     * {@linkplain #normalise()} will transform any set of weights to
     * that form.
     */
    public abstract List<BigDecimal> getWeights();

    public final NormalisedPortfolio normalise() {
        return new NormalisedPortfolio(this);
    }

    public final ShiftedPortfolio shift(final Number aReturnShift) {
        return new ShiftedPortfolio(this, aReturnShift);
    }

    protected abstract void reset();

}
