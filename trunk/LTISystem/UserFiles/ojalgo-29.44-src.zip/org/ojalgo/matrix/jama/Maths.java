package org.ojalgo.matrix.jama;

class Maths {

    /** sqrt(a^2 + b^2) without under/overflow. **/
    public static double hypot(final double a, final double b) {
        double retVal;
        if (Math.abs(a) > Math.abs(b)) {
            retVal = b / a;
            retVal = Math.abs(a) * Math.sqrt(1 + retVal * retVal);
        } else if (b != 0) {
            retVal = a / b;
            retVal = Math.abs(b) * Math.sqrt(1 + retVal * retVal);
        } else {
            retVal = 0.0;
        }
        return retVal;
    }
}
