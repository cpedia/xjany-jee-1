/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.gui.layout;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

public interface GridBagComponent {

    public static final class ConstraintsBuilder {

        static void initialiseLayout(GridBagComponent aComponent, int aRowDim, int aColDim, boolean isExpandable) {

            GridBagLayout tmpGridBagLayout = aComponent.getGridBagLayout();

            int tmpRowDim = isExpandable ? aRowDim + 1 : aRowDim;
            int tmpColDim = isExpandable ? aColDim + 1 : aColDim;

            tmpGridBagLayout.rowHeights = new int[tmpRowDim];
            tmpGridBagLayout.rowWeights = new double[tmpRowDim];

            tmpGridBagLayout.columnWidths = new int[tmpColDim];
            tmpGridBagLayout.columnWeights = new double[tmpColDim];

            if (isExpandable) {
                tmpGridBagLayout.rowWeights[aRowDim] = THOUSANDTH;
                tmpGridBagLayout.columnWeights[aColDim] = THOUSANDTH;
            }
        }

        static void initialiseLayout(GridBagComponent aComponent, int[] someRowHeights, int[] someColWidths, boolean isExpandable) {

            GridBagLayout tmpGridBagLayout = aComponent.getGridBagLayout();

            int tmpRowDim = isExpandable ? someRowHeights.length + 1 : someRowHeights.length;
            int tmpColDim = isExpandable ? someColWidths.length + 1 : someColWidths.length;

            tmpGridBagLayout.rowHeights = new int[tmpRowDim];
            tmpGridBagLayout.rowWeights = new double[tmpRowDim];

            tmpGridBagLayout.columnWidths = new int[tmpColDim];
            tmpGridBagLayout.columnWeights = new double[tmpColDim];

            for (int i = 0; i < someRowHeights.length; i++) {
                tmpGridBagLayout.rowHeights[i] = someRowHeights[i];
            }
            for (int j = 0; j < someColWidths.length; j++) {
                tmpGridBagLayout.columnWidths[j] = someColWidths[j];
            }
            if (isExpandable) {
                tmpGridBagLayout.rowWeights[someRowHeights.length] = THOUSANDTH;
                tmpGridBagLayout.columnWeights[someColWidths.length] = THOUSANDTH;
            }
        }

        static void makeColumnHeavyweight(GridBagComponent aComponent, int aCol) {
            aComponent.getGridBagLayout().columnWeights[aCol] = ONE;
        }

        static void makeRowHeavyweight(GridBagComponent aComponent, int aRow) {
            aComponent.getGridBagLayout().rowWeights[aRow] = ONE;
        }

        private int myAnchor = GridBagConstraints.CENTER;
        private int myFill = GridBagConstraints.BOTH;
        private Insets myInsets = new Insets(0, 0, 0, 0);

        public ConstraintsBuilder() {
            super();
        }

        public ConstraintsBuilder anchor(int anchor) {
            myAnchor = anchor;
            return this;
        }

        public ConstraintsBuilder fill(int fill) {
            myFill = fill;
            return this;
        }

        public ConstraintsBuilder insets(Insets insets) {
            myInsets = insets;
            return this;
        }

        public GridBagConstraints build(int gridx, int gridy) {
            return this.build(gridx, gridy, 1, 1);
        }

        public GridBagConstraints build(int gridx, int gridy, int gridwidth, int gridheight) {
            return new GridBagConstraints(gridx, gridy, gridwidth, gridheight, ZERO, ZERO, myAnchor, myFill, myInsets, 0, 0);
        }

    }

    void add(Component aComponent, int gridx, int gridy);

    void add(Component aComponent, int gridx, int gridy, int gridwidth, int gridheight);

    GridBagComponent anchor(int anchor);

    GridBagComponent fill(int fill);

    GridBagLayout getGridBagLayout();

    GridBagComponent insets(Insets insets);

    void makeColumnHeavyweight(int aCol);

    void makeRowHeavyweight(int aRow);

}