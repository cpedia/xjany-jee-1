/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import static org.ojalgo.constant.PrimitiveMath.*;
import static org.ojalgo.function.implementation.PrimitiveFunction.*;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.OjAlgoUtils;
import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.access.SimpleArray;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.array.PrimitiveArray;
import org.ojalgo.concurrent.DaemonPoolExecutor;
import org.ojalgo.concurrent.DivideAndConquer;
import org.ojalgo.concurrent.DivideAndMerge;
import org.ojalgo.concurrent.ProcessorCount;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.Aggregator;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.PrimitiveAggregator;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.operation.*;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Householder.Primitive;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.PrimitiveScalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * A {@linkplain Double} (actually double) implementation of {@linkplain PhysicalStore}.
 *
 * @author apete
 */
public final class PrimitiveDenseStore extends PrimitiveArray implements PhysicalStore<Double>, DecompositionStore<Double> {

    public static final DecompositionStore.Factory<Double> FACTORY = new DecompositionStore.Factory<Double>() {

        public PrimitiveDenseStore conjugate(final Access2D<? extends Number> aSource) {
            return this.transpose(aSource);
        }

        public PrimitiveDenseStore copy(final Access2D<? extends Number> aSource) {

            final PrimitiveDenseStore retVal = new PrimitiveDenseStore(aSource.getRowDim(), aSource.getColDim());

            retVal.fillMatching(aSource);

            return retVal;
        }

        public PrimitiveDenseStore copy(final double[][] aSource) {

            final PrimitiveDenseStore retVal = new PrimitiveDenseStore(aSource.length, aSource[INT_ZERO].length);

            retVal.fillMatching(ArrayUtils.wrapAccess2D(aSource));

            return retVal;
        }

        public AggregatorCollection<Double> getAggregatorCollection() {
            return PrimitiveAggregator.getCollection();
        }

        public FunctionSet<Double> getFunctionSet() {
            return PrimitiveFunction.getSet();
        }

        public Double getNumber(final double aNmbr) {
            return aNmbr;
        }

        public Double getNumber(final Number aNmbr) {
            return aNmbr.doubleValue();
        }

        public PrimitiveScalar getStaticOne() {
            return PrimitiveScalar.ONE;
        }

        public PrimitiveScalar getStaticZero() {
            return PrimitiveScalar.ZERO;
        }

        public PhysicalStore<Double> makeColumn(final Access1D<? extends Number> aColumn) {

            final int tmpRowDim = aColumn.size();
            final double[] retValData = new double[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = aColumn.doubleValue(i);
            }

            return new PrimitiveDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public PrimitiveDenseStore makeColumn(final double[] aColumn) {
            return new PrimitiveDenseStore(aColumn.length, INT_ONE, ArrayUtils.copyOf(aColumn));
        }

        public PrimitiveDenseStore makeColumn(final Double[] aColumn) {

            final int tmpRowDim = aColumn.length;
            final double[] retValData = new double[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = aColumn[i];
            }

            return new PrimitiveDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public PrimitiveDenseStore makeColumn(final List<Double> aColumn) {

            final int tmpRowDim = aColumn.size();
            final double[] retValData = new double[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = aColumn.get(i);
            }

            return new PrimitiveDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public PrimitiveDenseStore makeEmpty(final int aRowDim, final int aColDim) {
            return new PrimitiveDenseStore(aRowDim, aColDim, new double[aRowDim * aColDim]);
        }

        public PrimitiveDenseStore makeEye(final int aRowDim, final int aColDim) {

            final PrimitiveDenseStore retVal = this.makeZero(aRowDim, aColDim);

            retVal.myUtility.fillDiagonal(INT_ZERO, INT_ZERO, this.getStaticOne().getNumber());

            return retVal;
        }

        public Householder.Primitive makeHouseholderWorker(final int aLength) {
            return new Householder.Primitive(aLength);
        }

        public SimpleArray.Primitive makeSimpleArrayWorker(final int aLength) {
            return SimpleArray.makePrimitive(aLength);
        }

        public PrimitiveDenseStore makeZero(final int aRowDim, final int aColDim) {
            return new PrimitiveDenseStore(aRowDim, aColDim);
        }

        public PrimitiveScalar toScalar(final double aNmbr) {
            return new PrimitiveScalar(aNmbr);
        }

        public PrimitiveScalar toScalar(final Number aNmbr) {
            return new PrimitiveScalar(aNmbr.doubleValue());
        }

        public PrimitiveDenseStore transpose(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final double[] retValData = new double[tmpRowDim * tmpColDim];

            if (tmpColDim > Transpose.TRESHOLD) {

                final DivideAndConquer tmpConquerer = new DivideAndConquer(Transpose.TRESHOLD) {

                    @Override
                    public void conquer(final int aFirst, final int aLimit) {
                        Transpose.invoke(retValData, tmpRowDim, aFirst, aLimit, aSource);
                    }

                };

                tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

            } else {

                Transpose.invoke(retValData, tmpRowDim, INT_ZERO, tmpColDim, aSource);
            }

            return new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);
        }
    };

    static Householder.Primitive cast(final Householder<Double> aTransf) {
        if (aTransf instanceof Householder.Primitive) {
            return (Householder.Primitive) aTransf;
        } else if (aTransf instanceof DecompositionStore.HouseholderReference) {
            return ((DecompositionStore.HouseholderReference<Double>) aTransf).getPrimitiveWorker().copy(aTransf);
        } else {
            return new Householder.Primitive(aTransf);
        }
    }

    static PrimitiveDenseStore cast(final MatrixStore<Double> aStore) {
        if (aStore instanceof PrimitiveDenseStore) {
            return (PrimitiveDenseStore) aStore;
        } else {
            return (PrimitiveDenseStore) FACTORY.copy(aStore);
        }
    }

    static void doAfter(final double[] aMtrxH, final double[] aMtrxV, final double[] tmpMainDiagonal, final double[] tmpOffDiagonal, double r, double s, double z, final double aNorm1) {

        final int tmpDiagDim = (int) Math.sqrt(aMtrxH.length);
        final int tmpDiagDimMinusOne = tmpDiagDim - INT_ONE;

        //        BasicLogger.logDebug("r={}, s={}, z={}", r, s, z);

        double p;
        double q;
        double t;
        double w;
        double x;
        double y;

        for (int ij = tmpDiagDimMinusOne; ij >= INT_ZERO; ij--) {

            p = tmpMainDiagonal[ij];
            q = tmpOffDiagonal[ij];

            // Real vector
            if (q == INT_ZERO) {
                int l = ij;
                aMtrxH[ij + tmpDiagDim * ij] = 1.0;
                for (int i = ij - INT_ONE; i >= INT_ZERO; i--) {
                    w = aMtrxH[i + tmpDiagDim * i] - p;
                    r = PrimitiveMath.ZERO;
                    for (int j = l; j <= ij; j++) {
                        r = r + aMtrxH[i + tmpDiagDim * j] * aMtrxH[j + tmpDiagDim * ij];
                    }
                    if (tmpOffDiagonal[i] < PrimitiveMath.ZERO) {
                        z = w;
                        s = r;
                    } else {
                        l = i;
                        if (tmpOffDiagonal[i] == PrimitiveMath.ZERO) {
                            if (w != PrimitiveMath.ZERO) {
                                aMtrxH[i + tmpDiagDim * ij] = -r / w;
                            } else {
                                aMtrxH[i + tmpDiagDim * ij] = -r / (PrimitiveMath.MACHINE_DOUBLE_ERROR * aNorm1);
                            }

                            // Solve real equations
                        } else {
                            x = aMtrxH[i + tmpDiagDim * (i + INT_ONE)];
                            y = aMtrxH[(i + INT_ONE) + tmpDiagDim * i];
                            q = (tmpMainDiagonal[i] - p) * (tmpMainDiagonal[i] - p) + tmpOffDiagonal[i] * tmpOffDiagonal[i];
                            t = (x * s - z * r) / q;
                            aMtrxH[i + tmpDiagDim * ij] = t;
                            if (Math.abs(x) > Math.abs(z)) {
                                aMtrxH[(i + INT_ONE) + tmpDiagDim * ij] = (-r - w * t) / x;
                            } else {
                                aMtrxH[(i + INT_ONE) + tmpDiagDim * ij] = (-s - y * t) / z;
                            }
                        }

                        // Overflow control
                        t = Math.abs(aMtrxH[i + tmpDiagDim * ij]);
                        if ((PrimitiveMath.MACHINE_DOUBLE_ERROR * t) * t > INT_ONE) {
                            for (int j = i; j <= ij; j++) {
                                aMtrxH[j + tmpDiagDim * ij] = aMtrxH[j + tmpDiagDim * ij] / t;
                            }
                        }
                    }
                }

                // Complex vector
            } else if (q < INT_ZERO) {
                int l = ij - INT_ONE;

                // Last vector component imaginary so matrix is triangular
                if (Math.abs(aMtrxH[ij + tmpDiagDim * (ij - INT_ONE)]) > Math.abs(aMtrxH[(ij - INT_ONE) + tmpDiagDim * ij])) {
                    aMtrxH[(ij - INT_ONE) + tmpDiagDim * (ij - INT_ONE)] = q / aMtrxH[ij + tmpDiagDim * (ij - INT_ONE)];
                    aMtrxH[(ij - INT_ONE) + tmpDiagDim * ij] = -(aMtrxH[ij + tmpDiagDim * ij] - p) / aMtrxH[ij + tmpDiagDim * (ij - INT_ONE)];
                } else {

                    final ComplexNumber tmpX = ComplexNumber.makeRectangular(PrimitiveMath.ZERO, (-aMtrxH[(ij - INT_ONE) + tmpDiagDim * ij]));
                    final ComplexNumber tmpY = ComplexNumber.makeRectangular((aMtrxH[(ij - INT_ONE) + tmpDiagDim * (ij - INT_ONE)] - p), q);

                    final ComplexNumber tmpZ = tmpX.divide(tmpY);

                    aMtrxH[(ij - INT_ONE) + tmpDiagDim * (ij - INT_ONE)] = tmpZ.getReal();
                    aMtrxH[(ij - INT_ONE) + tmpDiagDim * ij] = tmpZ.getImaginary();
                }
                aMtrxH[ij + tmpDiagDim * (ij - INT_ONE)] = PrimitiveMath.ZERO;
                aMtrxH[ij + tmpDiagDim * ij] = 1.0;
                for (int i = ij - INT_TWO; i >= INT_ZERO; i--) {
                    double ra, sa, vr, vi;
                    ra = PrimitiveMath.ZERO;
                    sa = PrimitiveMath.ZERO;
                    for (int j = l; j <= ij; j++) {
                        ra = ra + aMtrxH[i + tmpDiagDim * j] * aMtrxH[j + tmpDiagDim * (ij - INT_ONE)];
                        sa = sa + aMtrxH[i + tmpDiagDim * j] * aMtrxH[j + tmpDiagDim * ij];
                    }
                    w = aMtrxH[i + tmpDiagDim * i] - p;

                    if (tmpOffDiagonal[i] < PrimitiveMath.ZERO) {
                        z = w;
                        r = ra;
                        s = sa;
                    } else {
                        l = i;
                        if (tmpOffDiagonal[i] == INT_ZERO) {
                            final ComplexNumber tmpX = ComplexNumber.makeRectangular((-ra), (-sa));
                            final ComplexNumber tmpY = ComplexNumber.makeRectangular(w, q);

                            final ComplexNumber tmpZ = tmpX.divide(tmpY);

                            aMtrxH[i + tmpDiagDim * (ij - INT_ONE)] = tmpZ.getReal();
                            aMtrxH[i + tmpDiagDim * ij] = tmpZ.getImaginary();
                        } else {

                            // Solve complex equations
                            x = aMtrxH[i + tmpDiagDim * (i + INT_ONE)];
                            y = aMtrxH[(i + INT_ONE) + tmpDiagDim * i];
                            vr = (tmpMainDiagonal[i] - p) * (tmpMainDiagonal[i] - p) + tmpOffDiagonal[i] * tmpOffDiagonal[i] - q * q;
                            vi = (tmpMainDiagonal[i] - p) * 2.0 * q;
                            if ((vr == PrimitiveMath.ZERO) & (vi == PrimitiveMath.ZERO)) {
                                vr = PrimitiveMath.MACHINE_DOUBLE_ERROR * aNorm1 * (Math.abs(w) + Math.abs(q) + Math.abs(x) + Math.abs(y) + Math.abs(z));
                            }

                            final ComplexNumber tmpX = ComplexNumber.makeRectangular((x * r - z * ra + q * sa), (x * s - z * sa - q * ra));
                            final ComplexNumber tmpY = ComplexNumber.makeRectangular(vr, vi);

                            final ComplexNumber tmpZ = tmpX.divide(tmpY);

                            aMtrxH[i + tmpDiagDim * (ij - INT_ONE)] = tmpZ.getReal();
                            aMtrxH[i + tmpDiagDim * ij] = tmpZ.getImaginary();

                            if (Math.abs(x) > (Math.abs(z) + Math.abs(q))) {
                                aMtrxH[(i + INT_ONE) + tmpDiagDim * (ij - INT_ONE)] = (-ra - w * aMtrxH[i + tmpDiagDim * (ij - INT_ONE)] + q * aMtrxH[i + tmpDiagDim * ij]) / x;
                                aMtrxH[(i + INT_ONE) + tmpDiagDim * ij] = (-sa - w * aMtrxH[i + tmpDiagDim * ij] - q * aMtrxH[i + tmpDiagDim * (ij - INT_ONE)]) / x;
                            } else {
                                final ComplexNumber tmpX1 = ComplexNumber.makeRectangular((-r - y * aMtrxH[i + tmpDiagDim * (ij - INT_ONE)]), (-s - y * aMtrxH[i + tmpDiagDim * ij]));
                                final ComplexNumber tmpY1 = ComplexNumber.makeRectangular(z, q);

                                final ComplexNumber tmpZ1 = tmpX1.divide(tmpY1);

                                aMtrxH[(i + INT_ONE) + tmpDiagDim * (ij - INT_ONE)] = tmpZ1.getReal();
                                aMtrxH[(i + INT_ONE) + tmpDiagDim * ij] = tmpZ1.getImaginary();
                            }
                        }

                        // Overflow control
                        t = Math.max(Math.abs(aMtrxH[i + tmpDiagDim * (ij - INT_ONE)]), Math.abs(aMtrxH[i + tmpDiagDim * ij]));
                        if ((PrimitiveMath.MACHINE_DOUBLE_ERROR * t) * t > INT_ONE) {
                            for (int j = i; j <= ij; j++) {
                                aMtrxH[j + tmpDiagDim * (ij - INT_ONE)] = aMtrxH[j + tmpDiagDim * (ij - INT_ONE)] / t;
                                aMtrxH[j + tmpDiagDim * ij] = aMtrxH[j + tmpDiagDim * ij] / t;
                            }
                        }
                    }
                }
            }
        }

        // Back transformation to get eigenvectors of original matrix
        for (int j = tmpDiagDimMinusOne; j >= INT_ZERO; j--) {
            for (int i = INT_ZERO; i <= tmpDiagDimMinusOne; i++) {
                z = PrimitiveMath.ZERO;
                for (int k = INT_ZERO; k <= j; k++) {
                    z += aMtrxV[i + tmpDiagDim * k] * aMtrxH[k + tmpDiagDim * j];
                }
                aMtrxV[i + tmpDiagDim * j] = z;
            }
        }
    }

    static int doHessenberg(final double[] aMtrxH, final double[] aMtrxV) {

        final int tmpDiagDim = (int) Math.sqrt(aMtrxH.length);
        final int tmpDiagDimMinusTwo = tmpDiagDim - INT_TWO;

        final double[] tmpWorkCopy = new double[tmpDiagDim];

        for (int ij = INT_ZERO; ij < tmpDiagDimMinusTwo; ij++) {

            // Scale column.
            double tmpColNorm1 = PrimitiveMath.ZERO;
            for (int i = ij + INT_ONE; i < tmpDiagDim; i++) {
                tmpColNorm1 += Math.abs(aMtrxH[i + tmpDiagDim * ij]);
            }

            if (tmpColNorm1 != PrimitiveMath.ZERO) {

                // Compute Householder transformation.
                double tmpInvBeta = PrimitiveMath.ZERO;
                for (int i = tmpDiagDim - INT_ONE; i >= ij + INT_ONE; i--) {
                    tmpWorkCopy[i] = aMtrxH[i + tmpDiagDim * ij] / tmpColNorm1;
                    tmpInvBeta += tmpWorkCopy[i] * tmpWorkCopy[i];
                }
                double g = Math.sqrt(tmpInvBeta);
                if (tmpWorkCopy[ij + INT_ONE] > INT_ZERO) {
                    g = -g;
                }
                tmpInvBeta = tmpInvBeta - tmpWorkCopy[ij + INT_ONE] * g;
                tmpWorkCopy[ij + INT_ONE] = tmpWorkCopy[ij + INT_ONE] - g;

                // Apply Householder similarity transformation
                // H = (I-u*u'/h)*H*(I-u*u')/h)
                for (int j = ij + INT_ONE; j < tmpDiagDim; j++) {
                    double f = PrimitiveMath.ZERO;
                    for (int i = tmpDiagDim - INT_ONE; i >= ij + INT_ONE; i--) {
                        f += tmpWorkCopy[i] * aMtrxH[i + tmpDiagDim * j];
                    }
                    f = f / tmpInvBeta;
                    for (int i = ij + INT_ONE; i <= tmpDiagDim - INT_ONE; i++) {
                        aMtrxH[i + tmpDiagDim * j] -= f * tmpWorkCopy[i];
                    }
                }

                for (int i = INT_ZERO; i < tmpDiagDim; i++) {
                    double f = PrimitiveMath.ZERO;
                    for (int j = tmpDiagDim - INT_ONE; j >= ij + INT_ONE; j--) {
                        f += tmpWorkCopy[j] * aMtrxH[i + tmpDiagDim * j];
                    }
                    f = f / tmpInvBeta;
                    for (int j = ij + INT_ONE; j < tmpDiagDim; j++) {
                        aMtrxH[i + tmpDiagDim * j] -= f * tmpWorkCopy[j];
                    }
                }

                tmpWorkCopy[ij + INT_ONE] = tmpColNorm1 * tmpWorkCopy[ij + INT_ONE];
                aMtrxH[(ij + INT_ONE) + tmpDiagDim * ij] = tmpColNorm1 * g;
            }
        }

        //  BasicLogger.logDebug("Jama H", new PrimitiveDenseStore(tmpDiagDim, tmpDiagDim, aMtrxH));

        // Här borde Hessenberg vara klar
        // Nedan börjar uträkningen av Q

        // Accumulate transformations (Algol's ortran).
        for (int ij = tmpDiagDimMinusTwo; ij >= 1; ij--) {
            final int tmpIndex = ij + tmpDiagDim * (ij - 1);
            if (aMtrxH[tmpIndex] != PrimitiveMath.ZERO) {
                for (int i = ij + 1; i <= tmpDiagDim - 1; i++) {
                    tmpWorkCopy[i] = aMtrxH[i + tmpDiagDim * (ij - 1)];
                }
                for (int j = ij; j <= tmpDiagDim - 1; j++) {
                    double g = PrimitiveMath.ZERO;
                    for (int i = ij; i <= tmpDiagDim - 1; i++) {
                        g += tmpWorkCopy[i] * aMtrxV[i + tmpDiagDim * j];
                    }
                    // Double division avoids possible underflow
                    g = (g / tmpWorkCopy[ij]) / aMtrxH[tmpIndex];
                    for (int i = ij; i <= tmpDiagDim - 1; i++) {
                        aMtrxV[i + tmpDiagDim * j] += g * tmpWorkCopy[i];
                    }
                }
            } else {
                //                BasicLogger.logDebug("Iter V", new PrimitiveDenseStore(tmpDiagDim, tmpDiagDim, aMtrxV));
            }
        }

        //      BasicLogger.logDebug("Jama V", new PrimitiveDenseStore(tmpDiagDim, tmpDiagDim, aMtrxV));

        return tmpDiagDim;
    }

    static void doHouseholderBoth1Derive(final double[] aData, final int aFirstCol, final int aColLimit, final Householder.Primitive aHouseholder, final double[] aDerived, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > INT_ONE) && (tmpColCount > HouseholderBoth.TRESHOLD)) {

            final int tmpSplit = aFirstCol + tmpColCount / INT_TWO;
            final int tmpCPUs = availableCPUs / INT_TWO;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth1Derive(aData, aFirstCol, tmpSplit, aHouseholder, aDerived, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth1Derive(aData, tmpSplit, aColLimit, aHouseholder, aDerived, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpVector = aHouseholder.vector;
            final int tmpFirst = aHouseholder.first;
            final int tmpLength = tmpVector.length;

            double tmpVal;
            for (int i = aFirstCol; i < aColLimit; i++) {
                tmpVal = ZERO;
                for (int c = tmpFirst; c < i; c++) {
                    tmpVal += aData[i + c * tmpLength] * tmpVector[c];
                }
                for (int c = i; c < tmpLength; c++) {
                    tmpVal += aData[c + i * tmpLength] * tmpVector[c];
                }
                aDerived[i] = tmpVal;
            }
        }
    }

    static void doHouseholderBoth2Scale(final Householder.Primitive aHouseholder, final double[] aDerived) {

        final double[] tmpVector = aHouseholder.vector;
        final int tmpFirst = aHouseholder.first;
        final int tmpLength = tmpVector.length;
        final double tmpBeta = aHouseholder.beta;

        double tmpVal = ZERO;
        for (int c = tmpFirst; c < tmpLength; c++) {
            tmpVal += tmpVector[c] * aDerived[c];
        }
        tmpVal *= (tmpBeta / TWO);

        for (int c = tmpFirst; c < tmpLength; c++) {
            aDerived[c] = tmpBeta * (aDerived[c] - (tmpVal * tmpVector[c]));
        }
    }

    static void doHouseholderBoth3Update(final double[] aData, final int aFirstCol, final int aColLimit, final Householder.Primitive tmpHouseholder, final double[] aDerived, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > INT_ONE) && (tmpColCount > HouseholderBoth.TRESHOLD)) {

            final int tmpSplit = aFirstCol + tmpColCount / INT_TWO;
            final int tmpCPUs = availableCPUs / INT_TWO;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth3Update(aData, aFirstCol, tmpSplit, tmpHouseholder, aDerived, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth3Update(aData, tmpSplit, aColLimit, tmpHouseholder, aDerived, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpVector = tmpHouseholder.vector;
            final int tmpLength = tmpVector.length;

            double tmpHouseJ;
            double tmpDerivJ;

            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {

                tmpHouseJ = tmpVector[j];
                tmpDerivJ = aDerived[j];

                tmpIndex = j + j * tmpLength;
                for (int i = j; i < tmpLength; i++) {
                    aData[tmpIndex++] -= (aDerived[i] * tmpHouseJ + tmpVector[i] * tmpDerivJ);
                }
            }
        }
    }

    static void doMultiplyBoth(final double[] aProductArray, final Access2D<?> aLeftStore, final Access2D<?> aRightStore) {

        final int tmpRowDim = aLeftStore.getRowDim();

        if (tmpRowDim > MultiplyBoth.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyBoth.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyBoth.invoke(aProductArray, aFirst, aLimit, aLeftStore, aRightStore);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpRowDim, ProcessorCount.getFree());

        } else {

            MultiplyBoth.invoke(aProductArray, INT_ZERO, tmpRowDim, aLeftStore, aRightStore);
        }
    }

    static void doMultiplyLeft(final double[] aProductArray, final MatrixStore<Double> aLeftStore, final double[] aRightArray) {

        final int tmpRowDim = aLeftStore.getRowDim();

        if (tmpRowDim > MultiplyLeft.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyLeft.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyLeft.invoke(aProductArray, aFirst, aLimit, aLeftStore, aRightArray);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpRowDim, ProcessorCount.getFree());

        } else {

            MultiplyLeft.invoke(aProductArray, INT_ZERO, tmpRowDim, aLeftStore, aRightArray);
        }
    }

    static void doMultiplyRight(final double[] aProductArray, final double[] aLeftArray, final MatrixStore<Double> aRightStore) {

        final int tmpColDim = aRightStore.getColDim();

        if (tmpColDim > MultiplyRight.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyRight.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyRight.invoke(aProductArray, aFirst, aLimit, aLeftArray, aRightStore);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            MultiplyRight.invoke(aProductArray, INT_ZERO, tmpColDim, aLeftArray, aRightStore);
        }
    }

    static double[][] doSchur(final double[] aMtrxH, final double[] aMtrxV, final boolean allTheWay) {

        final int tmpDiagDim = (int) Math.sqrt(aMtrxH.length);
        final int tmpDiagDimMinusOne = tmpDiagDim - INT_ONE;

        // Store roots isolated by balanc and compute matrix norm
        double tmpVal = PrimitiveMath.ZERO;
        for (int j = INT_ZERO; j < tmpDiagDim; j++) {
            for (int i = Math.min(j + INT_ONE, tmpDiagDim - INT_ONE); i >= INT_ZERO; i--) {
                tmpVal += Math.abs(aMtrxH[i + tmpDiagDim * j]);
            }
        }
        final double tmpNorm1 = tmpVal;

        final double[] tmpMainDiagonal = new double[tmpDiagDim];
        final double[] tmpOffDiagonal = new double[tmpDiagDim];

        double exshift = PrimitiveMath.ZERO;
        double p = INT_ZERO, q = INT_ZERO, r = INT_ZERO, s = INT_ZERO, z = INT_ZERO;

        double w, x, y;
        // Outer loop over eigenvalue index
        int tmpIterCount = INT_ZERO;
        int tmpMainIterIndex = tmpDiagDimMinusOne;
        while (tmpMainIterIndex >= INT_ZERO) {

            // Look for single small sub-diagonal element
            int l = tmpMainIterIndex;
            while (l > INT_ZERO) {
                s = Math.abs(aMtrxH[(l - INT_ONE) + tmpDiagDim * (l - INT_ONE)]) + Math.abs(aMtrxH[l + tmpDiagDim * l]);
                if (s == PrimitiveMath.ZERO) {
                    s = tmpNorm1;
                }
                if (Math.abs(aMtrxH[l + tmpDiagDim * (l - INT_ONE)]) < PrimitiveMath.MACHINE_DOUBLE_ERROR * s) {
                    break;
                }
                l--;
            }

            // Check for convergence
            // One root found
            if (l == tmpMainIterIndex) {
                aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] + exshift;
                tmpMainDiagonal[tmpMainIterIndex] = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex];
                tmpOffDiagonal[tmpMainIterIndex] = PrimitiveMath.ZERO;
                tmpMainIterIndex--;
                tmpIterCount = INT_ZERO;

                // Two roots found
            } else if (l == tmpMainIterIndex - INT_ONE) {
                w = aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - INT_ONE)] * aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * tmpMainIterIndex];
                p = (aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * (tmpMainIterIndex - INT_ONE)] - aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex]) / 2.0;
                q = p * p + w;
                z = Math.sqrt(Math.abs(q));
                aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] + exshift;
                aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * (tmpMainIterIndex - INT_ONE)] = aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * (tmpMainIterIndex - INT_ONE)] + exshift;
                x = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex];

                // Real pair
                if (q >= INT_ZERO) {
                    if (p >= INT_ZERO) {
                        z = p + z;
                    } else {
                        z = p - z;
                    }
                    tmpMainDiagonal[tmpMainIterIndex - INT_ONE] = x + z;
                    tmpMainDiagonal[tmpMainIterIndex] = tmpMainDiagonal[tmpMainIterIndex - INT_ONE];
                    if (z != PrimitiveMath.ZERO) {
                        tmpMainDiagonal[tmpMainIterIndex] = x - w / z;
                    }
                    tmpOffDiagonal[tmpMainIterIndex - INT_ONE] = PrimitiveMath.ZERO;
                    tmpOffDiagonal[tmpMainIterIndex] = PrimitiveMath.ZERO;
                    x = aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - INT_ONE)];
                    s = Math.abs(x) + Math.abs(z);
                    p = x / s;
                    q = z / s;
                    r = Math.sqrt(p * p + q * q);
                    p = p / r;
                    q = q / r;

                    // Row modification
                    for (int j = tmpMainIterIndex - INT_ONE; j < tmpDiagDim; j++) {
                        z = aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * j];
                        aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * j] = q * z + p * aMtrxH[tmpMainIterIndex + tmpDiagDim * j];
                        aMtrxH[tmpMainIterIndex + tmpDiagDim * j] = q * aMtrxH[tmpMainIterIndex + tmpDiagDim * j] - p * z;
                    }

                    // Column modification
                    for (int i = INT_ZERO; i <= tmpMainIterIndex; i++) {
                        z = aMtrxH[i + tmpDiagDim * (tmpMainIterIndex - INT_ONE)];
                        aMtrxH[i + tmpDiagDim * (tmpMainIterIndex - INT_ONE)] = q * z + p * aMtrxH[i + tmpDiagDim * tmpMainIterIndex];
                        aMtrxH[i + tmpDiagDim * tmpMainIterIndex] = q * aMtrxH[i + tmpDiagDim * tmpMainIterIndex] - p * z;
                    }

                    // Accumulate transformations
                    for (int i = INT_ZERO; i <= tmpDiagDimMinusOne; i++) {
                        z = aMtrxV[i + tmpDiagDim * (tmpMainIterIndex - INT_ONE)];
                        aMtrxV[i + tmpDiagDim * (tmpMainIterIndex - INT_ONE)] = q * z + p * aMtrxV[i + tmpDiagDim * tmpMainIterIndex];
                        aMtrxV[i + tmpDiagDim * tmpMainIterIndex] = q * aMtrxV[i + tmpDiagDim * tmpMainIterIndex] - p * z;
                    }

                    // Complex pair
                } else {
                    tmpMainDiagonal[tmpMainIterIndex - INT_ONE] = x + p;
                    tmpMainDiagonal[tmpMainIterIndex] = x + p;
                    tmpOffDiagonal[tmpMainIterIndex - INT_ONE] = z;
                    tmpOffDiagonal[tmpMainIterIndex] = -z;
                }
                tmpMainIterIndex = tmpMainIterIndex - INT_TWO;
                tmpIterCount = INT_ZERO;

                // No convergence yet
            } else {

                // Form shift
                x = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex];
                y = PrimitiveMath.ZERO;
                w = PrimitiveMath.ZERO;
                if (l < tmpMainIterIndex) {
                    y = aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * (tmpMainIterIndex - INT_ONE)];
                    w = aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - INT_ONE)] * aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * tmpMainIterIndex];
                }

                // Wilkinson's original ad hoc shift
                if (tmpIterCount == 10) {
                    exshift += x;
                    for (int i = INT_ZERO; i <= tmpMainIterIndex; i++) {
                        aMtrxH[i + tmpDiagDim * i] -= x;
                    }
                    s = Math.abs(aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - INT_ONE)]) + Math.abs(aMtrxH[(tmpMainIterIndex - INT_ONE) + tmpDiagDim * (tmpMainIterIndex - INT_TWO)]);
                    x = y = 0.75 * s;
                    w = -0.4375 * s * s;
                }

                // MATLAB's new ad hoc shift
                if (tmpIterCount == 30) {
                    s = (y - x) / 2.0;
                    s = s * s + w;
                    if (s > INT_ZERO) {
                        s = Math.sqrt(s);
                        if (y < x) {
                            s = -s;
                        }
                        s = x - w / ((y - x) / 2.0 + s);
                        for (int i = INT_ZERO; i <= tmpMainIterIndex; i++) {
                            aMtrxH[i + tmpDiagDim * i] -= s;
                        }
                        exshift += s;
                        x = y = w = 0.964;
                    }
                }

                tmpIterCount++; // (Could check iteration count here.)

                // Look for two consecutive small sub-diagonal elements
                int m = tmpMainIterIndex - INT_TWO;
                while (m >= l) {
                    z = aMtrxH[m + tmpDiagDim * m];
                    r = x - z;
                    s = y - z;
                    p = (r * s - w) / aMtrxH[(m + INT_ONE) + tmpDiagDim * m] + aMtrxH[m + tmpDiagDim * (m + INT_ONE)];
                    q = aMtrxH[(m + INT_ONE) + tmpDiagDim * (m + INT_ONE)] - z - r - s;
                    r = aMtrxH[(m + INT_TWO) + tmpDiagDim * (m + INT_ONE)];
                    s = Math.abs(p) + Math.abs(q) + Math.abs(r);
                    p = p / s;
                    q = q / s;
                    r = r / s;
                    if (m == l) {
                        break;
                    }
                    if (Math.abs(aMtrxH[m + tmpDiagDim * (m - INT_ONE)]) * (Math.abs(q) + Math.abs(r)) < PrimitiveMath.MACHINE_DOUBLE_ERROR * (Math.abs(p) * (Math.abs(aMtrxH[(m - INT_ONE) + tmpDiagDim * (m - INT_ONE)]) + Math.abs(z) + Math.abs(aMtrxH[(m + INT_ONE) + tmpDiagDim * (m + INT_ONE)])))) {
                        break;
                    }
                    m--;
                }

                for (int i = m + INT_TWO; i <= tmpMainIterIndex; i++) {
                    aMtrxH[i + tmpDiagDim * (i - INT_TWO)] = PrimitiveMath.ZERO;
                    if (i > m + INT_TWO) {
                        aMtrxH[i + tmpDiagDim * (i - 3)] = PrimitiveMath.ZERO;
                    }
                }

                // Double QR step involving rows l:n and columns m:n
                for (int k = m; k <= tmpMainIterIndex - INT_ONE; k++) {
                    final boolean notlast = (k != tmpMainIterIndex - INT_ONE);
                    if (k != m) {
                        p = aMtrxH[k + tmpDiagDim * (k - INT_ONE)];
                        q = aMtrxH[(k + INT_ONE) + tmpDiagDim * (k - INT_ONE)];
                        r = (notlast ? aMtrxH[(k + INT_TWO) + tmpDiagDim * (k - INT_ONE)] : PrimitiveMath.ZERO);
                        x = Math.abs(p) + Math.abs(q) + Math.abs(r);
                        if (x != PrimitiveMath.ZERO) {
                            p = p / x;
                            q = q / x;
                            r = r / x;
                        }
                    }
                    if (x == PrimitiveMath.ZERO) {
                        break;
                    }
                    s = Math.sqrt(p * p + q * q + r * r);
                    if (p < INT_ZERO) {
                        s = -s;
                    }
                    if (s != INT_ZERO) {
                        if (k != m) {
                            aMtrxH[k + tmpDiagDim * (k - INT_ONE)] = -s * x;
                        } else if (l != m) {
                            aMtrxH[k + tmpDiagDim * (k - INT_ONE)] = -aMtrxH[k + tmpDiagDim * (k - INT_ONE)];
                        }
                        p = p + s;
                        x = p / s;
                        y = q / s;
                        z = r / s;
                        q = q / p;
                        r = r / p;

                        // Row modification
                        for (int j = k; j < tmpDiagDim; j++) {
                            p = aMtrxH[k + tmpDiagDim * j] + q * aMtrxH[(k + INT_ONE) + tmpDiagDim * j];
                            if (notlast) {
                                p = p + r * aMtrxH[(k + INT_TWO) + tmpDiagDim * j];
                                aMtrxH[(k + INT_TWO) + tmpDiagDim * j] = aMtrxH[(k + INT_TWO) + tmpDiagDim * j] - p * z;
                            }
                            aMtrxH[k + tmpDiagDim * j] = aMtrxH[k + tmpDiagDim * j] - p * x;
                            aMtrxH[(k + INT_ONE) + tmpDiagDim * j] = aMtrxH[(k + INT_ONE) + tmpDiagDim * j] - p * y;
                        }

                        // Column modification
                        for (int i = INT_ZERO; i <= Math.min(tmpMainIterIndex, k + 3); i++) {
                            p = x * aMtrxH[i + tmpDiagDim * k] + y * aMtrxH[i + tmpDiagDim * (k + INT_ONE)];
                            if (notlast) {
                                p = p + z * aMtrxH[i + tmpDiagDim * (k + INT_TWO)];
                                aMtrxH[i + tmpDiagDim * (k + INT_TWO)] = aMtrxH[i + tmpDiagDim * (k + INT_TWO)] - p * r;
                            }
                            aMtrxH[i + tmpDiagDim * k] = aMtrxH[i + tmpDiagDim * k] - p;
                            aMtrxH[i + tmpDiagDim * (k + INT_ONE)] = aMtrxH[i + tmpDiagDim * (k + INT_ONE)] - p * q;
                        }

                        // Accumulate transformations
                        for (int i = INT_ZERO; i <= tmpDiagDimMinusOne; i++) {
                            p = x * aMtrxV[i + tmpDiagDim * k] + y * aMtrxV[i + tmpDiagDim * (k + INT_ONE)];
                            if (notlast) {
                                p = p + z * aMtrxV[i + tmpDiagDim * (k + INT_TWO)];
                                aMtrxV[i + tmpDiagDim * (k + INT_TWO)] = aMtrxV[i + tmpDiagDim * (k + INT_TWO)] - p * r;
                            }
                            aMtrxV[i + tmpDiagDim * k] = aMtrxV[i + tmpDiagDim * k] - p;
                            aMtrxV[i + tmpDiagDim * (k + INT_ONE)] = aMtrxV[i + tmpDiagDim * (k + INT_ONE)] - p * q;
                        }
                    } // (s != 0)
                } // k loop
            } // check convergence
        } // while (n >= low)

        // Backsubstitute to find vectors of upper triangular form
        if (allTheWay && (tmpNorm1 != PrimitiveMath.ZERO)) {
            PrimitiveDenseStore.doAfter(aMtrxH, aMtrxV, tmpMainDiagonal, tmpOffDiagonal, r, s, z, tmpNorm1);
        }

        return new double[][] { tmpMainDiagonal, tmpOffDiagonal };
    }

    private final int myColDim;
    private final int myRowDim;
    private final Array2D<Double> myUtility;

    PrimitiveDenseStore(final double[] anArray) {

        super(anArray);

        myRowDim = anArray.length;
        myColDim = INT_ONE;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aLength) {

        super(aLength);

        myRowDim = aLength;
        myColDim = INT_ONE;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aRowDim, final int aColDim) {

        super(aRowDim * aColDim);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aRowDim, final int aColDim, final double[] anArray) {

        super(anArray);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    public Double aggregateAll(final Aggregator aVisitor) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > AggregateAll.TRESHOLD) {

            final DivideAndMerge<Double> tmpConquerer = new DivideAndMerge<Double>(AggregateAll.TRESHOLD) {

                @Override
                public Double conquer(final int aFirst, final int aLimit) {

                    final AggregatorFunction<Double> tmpAggrFunc = aVisitor.getPrimitiveFunction();

                    PrimitiveDenseStore.this.visit(tmpRowDim * aFirst, tmpRowDim * aLimit, INT_ONE, tmpAggrFunc);

                    return tmpAggrFunc.getNumber();
                }

                @Override
                public Double merge(final Double aFirstResult, final Double aSecondResult) {

                    final AggregatorFunction<Double> tmpAggrFunc = aVisitor.getPrimitiveFunction();

                    tmpAggrFunc.merge(aFirstResult);
                    tmpAggrFunc.merge(aSecondResult);

                    return tmpAggrFunc.getNumber();
                }
            };

            return tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            final AggregatorFunction<Double> tmpAggrFunc = aVisitor.getPrimitiveFunction();

            PrimitiveDenseStore.this.visit(INT_ZERO, length, INT_ONE, tmpAggrFunc);

            return tmpAggrFunc.getNumber();
        }
    }

    public void applyCholesky(final int aNextIndex, final int aDim, final SimpleArray<Double> aMultipliers) {

        final double[] tmpData = this.data();
        final double[] tmpColumn = ((SimpleArray.Primitive) aMultipliers).data;

        if (aDim - aNextIndex > ApplyCholesky.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ApplyCholesky.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ApplyCholesky.invoke(tmpData, aDim, aFirst, aLimit, tmpColumn);
                }

            };

            tmpConquerer.divide(aNextIndex, aDim, ProcessorCount.getFree());

        } else {

            ApplyCholesky.invoke(tmpData, aDim, aNextIndex, aDim, tmpColumn);
        }
    }

    public void applyLU(final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColDim, final SimpleArray<Double> aMultipliers) {

        final double[] tmpData = this.data();
        final double[] tmpColumn = ((SimpleArray.Primitive) aMultipliers).data;

        if (aColDim - aFirstCol > ApplyLU.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ApplyLU.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ApplyLU.invoke(tmpData, aPivotRow, aRowDim, aFirst, aLimit, tmpColumn);
                }
            };

            tmpConquerer.divide(aFirstCol, aColDim, ProcessorCount.getFull());

        } else {

            ApplyLU.invoke(tmpData, aPivotRow, aRowDim, aFirstCol, aColDim, tmpColumn);
        }
    }

    public Array2D<Double> asArray2D() {
        return myUtility;
    }

    public Array1D<Double> asList() {
        return myUtility.asArray1D();
    }

    public final MatrixStore.Builder<Double> builder() {
        return new MatrixStore.Builder<Double>(this);
    }

    public void caxpy(final Double aSclrA, final int aColX, final int aColY, final int aFirstRow) {
        CAXPY.invoke(this.data(), aSclrA.doubleValue(), this.data(), aColX, aColY, aFirstRow, myRowDim);
    }

    public boolean computeInPlaceCholesky(final boolean checkForSPD) {

        // true if (Symmetric) Positive Definite 
        boolean retVal = myRowDim == myColDim;

        final int tmpDim = myRowDim;

        final double[] tmpData = this.data();
        int tmpIndex;

        // Check for symmetry, maybe
        if (retVal && checkForSPD) {
            for (int j = INT_ZERO; retVal && (j < tmpDim); j++) {
                for (int i = j + INT_ONE; retVal && (i < tmpDim); i++) {
                    retVal &= TypeUtils.isZero(tmpData[i + j * tmpDim] - tmpData[j + i * tmpDim]);
                }
            }
        }

        final SimpleArray.Primitive tmpMultipliers = SimpleArray.makePrimitive(tmpDim);
        final double[] tmpColumn = tmpMultipliers.data;
        double tmpVal;

        // Main loop - along the diagonal
        for (int ij = INT_ZERO; retVal && (ij < tmpDim); ij++) {

            // "Pivot" element
            tmpVal = tmpData[tmpIndex = ij + ij * tmpDim];

            if (tmpVal > ZERO) {

                tmpColumn[ij] = tmpData[tmpIndex] = tmpVal = Math.sqrt(tmpVal);

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                this.divideAndCopyColumn(ij + INT_ONE, ij, tmpVal, tmpMultipliers);

                // Remaining columns, below the diagonal
                this.applyCholesky(ij + INT_ONE, tmpDim, tmpMultipliers);

            } else {

                retVal = BOOLEAN_FALSE;
            }
        }

        return retVal;
    }

    public Pivot computeInPlaceLU(final boolean assumeNoPivotingRequired) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;
        final int tmpMinDim = Math.min(tmpRowDim, tmpColDim);

        final Pivot retVal = new Pivot(tmpRowDim);

        final double[] tmpData = this.data();
        int tmpIndex;

        int tmpPivotRowIndex;

        final SimpleArray.Primitive tmpMultipliers = SimpleArray.makePrimitive(tmpRowDim);
        double tmpVal;

        // Main loop - along the diagonal
        for (int ij = INT_ZERO; ij < tmpMinDim; ij++) {

            final int tmpPivotRow = ij;
            final int tmpFirstCol = ij + INT_ONE;

            if (!assumeNoPivotingRequired) {
                // Find next pivot row, stop searching when something good enough is found
                tmpVal = Math.abs(tmpData[tmpIndex = tmpPivotRow + ij * tmpRowDim]);
                tmpPivotRowIndex = tmpPivotRow;
                for (int i = tmpPivotRow + INT_ONE; (i < tmpRowDim) && (tmpVal < HALF); i++) {
                    if (Math.abs(tmpData[++tmpIndex]) > tmpVal) {
                        tmpVal = Math.abs(tmpData[tmpIndex]);
                        tmpPivotRowIndex = i;
                    }
                }
                // Pivot?
                if (tmpPivotRowIndex != tmpPivotRow) {
                    myUtility.exchangeRows(tmpPivotRowIndex, tmpPivotRow);
                    retVal.change(tmpPivotRowIndex, tmpPivotRow);
                }
            }

            // Do the calculations...

            // "Pivot" element
            tmpVal = tmpData[tmpIndex = tmpPivotRow + ij * tmpRowDim];
            if (!TypeUtils.isZero(tmpVal)) {

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                this.divideAndCopyColumn(ij + INT_ONE, ij, tmpVal, tmpMultipliers);

                // Apply transformations to everything below and to the right of the pivot element
                this.applyLU(tmpPivotRow, tmpRowDim, tmpFirstCol, tmpColDim, tmpMultipliers);

            } else {

                tmpData[tmpIndex] = ZERO;
            }
        }

        return retVal;
    }

    public Array1D<ComplexNumber> computeInPlaceSchur(final PhysicalStore<Double> aTransformationCollector, final boolean eigenvalue) {

        //        final PrimitiveDenseStore tmpThisCopy = this.copy();
        //        final PrimitiveDenseStore tmpCollCopy = (PrimitiveDenseStore) aTransformationCollector.copy();
        //
        //        tmpThisCopy.computeInPlaceHessenberg(true);

        // Actual

        final double[] tmpData = this.data();

        final double[] tmpCollectorData = ((PrimitiveDenseStore) aTransformationCollector).data();

        PrimitiveDenseStore.doHessenberg(tmpData, tmpCollectorData);

        //        BasicLogger.logDebug("Schur Step", this);
        //        BasicLogger.logDebug("Hessenberg", tmpThisCopy);

        final double[][] tmpDiags = PrimitiveDenseStore.doSchur(tmpData, tmpCollectorData, eigenvalue);
        return Array1D.makeComplex(tmpDiags[INT_ZERO], tmpDiags[INT_ONE]);
    }

    public void computeInPlaceTridiagonal() {

        final double[] tmpData = this.data();
        final int tmpRowDim = myRowDim; // Which is also the col-dim.

        final Householder.Primitive tmpHouseholder = new Householder.Primitive(tmpRowDim);
        final double[] tmpDerived = new double[tmpRowDim];

        final int tmpLimit = tmpRowDim - INT_TWO;
        for (int ij = INT_ZERO; ij < tmpLimit; ij++) {

            if (this.generateApplyAndCopyHouseholderColumn(ij + INT_ONE, ij, tmpHouseholder)) {

                PrimitiveDenseStore.doHouseholderBoth1Derive(tmpData, tmpHouseholder.first, tmpRowDim, tmpHouseholder, tmpDerived, OjAlgoUtils.HARDWARE.processors);

                PrimitiveDenseStore.doHouseholderBoth2Scale(tmpHouseholder, tmpDerived);

                PrimitiveDenseStore.doHouseholderBoth3Update(tmpData, tmpHouseholder.first, tmpRowDim, tmpHouseholder, tmpDerived, OjAlgoUtils.HARDWARE.processors);
            }
        }
    }

    public PrimitiveDenseStore conjugate() {
        return (PrimitiveDenseStore) FACTORY.conjugate(this);
    }

    public PrimitiveDenseStore copy() {
        return new PrimitiveDenseStore(myRowDim, myColDim, this.copyOfData());
    }

    public void divideAndCopyColumn(final int aRow, final int aCol, final Double aNumerator, final SimpleArray<Double> aDestination) {

        final double tmpNumerator = aNumerator;
        final double[] tmpDestination = ((SimpleArray.Primitive) aDestination).data;

        final double[] tmpData = this.data();
        final int tmpRowDim = myRowDim;

        int tmpIndex = aRow + aCol * tmpRowDim;
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpDestination[i] = tmpData[tmpIndex++] /= tmpNumerator;
        }
    }

    public double doubleValue(final int aRow, final int aCol) {
        return myUtility.doubleValue(aRow, aCol);
    }

    public boolean equals(final MatrixStore<Double> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this, aStore, aCntxt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof MatrixStore) {
            return this.equals((MatrixStore<Double>) anObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(anObj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myUtility.exchangeColumns(aColA, aColB);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myUtility.exchangeRows(aRowA, aRowB);
    }

    public void fillAll(final Double aNmbr) {
        myUtility.fillAll(aNmbr);
    }

    public void fillByMultiplying(final MatrixStore<Double> aLeftStore, final MatrixStore<Double> aRightStore) {

        final double[] tmpProductData = this.data();

        if (aRightStore instanceof PrimitiveDenseStore) {

            PrimitiveDenseStore.doMultiplyLeft(tmpProductData, aLeftStore, PrimitiveDenseStore.cast(aRightStore).data());

        } else if (aLeftStore instanceof PrimitiveDenseStore) {

            PrimitiveDenseStore.doMultiplyRight(tmpProductData, PrimitiveDenseStore.cast(aLeftStore).data(), aRightStore);

        } else {

            PrimitiveDenseStore.doMultiplyBoth(tmpProductData, aLeftStore, aRightStore);
        }
    }

    public void fillColumn(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillColumn(aRow, aCol, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillDiagonal(aRow, aCol, aNmbr);
    }

    public void fillMatching(final Access2D<? extends Number> aSource2D) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > Copy.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(Copy.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    Copy.invoke(PrimitiveDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aSource2D);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            Copy.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aSource2D);
        }
    }

    public void fillMatching(final Double aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingRight.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingRight.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    PrimitiveDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillMatching(final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final Double aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingLeft.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingLeft.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    PrimitiveDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillMatching(final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingBoth.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingBoth.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    PrimitiveDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillRow(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillRow(aRow, aCol, aNmbr);
    }

    public final boolean generateApplyAndCopyHouseholderColumn(final int aRow, final int aCol, final Householder<Double> aDestination) {

        final Householder.Primitive tmpDestination = (Householder.Primitive) aDestination;

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColBase = aCol * tmpRowDim;

        final double[] tmpVector = tmpDestination.vector;
        tmpDestination.first = aRow;

        double tmpNormInf = ZERO; // Copy column and calculate its infinity-norm.
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpNormInf = Math.max(tmpNormInf, Math.abs(tmpVector[i] = tmpData[i + tmpColBase]));
        }

        boolean retVal = tmpNormInf != ZERO;
        double tmpVal;
        double tmpNorm2 = ZERO;

        if (retVal) {
            for (int i = aRow + INT_ONE; i < tmpRowDim; i++) {
                tmpVal = tmpVector[i] /= tmpNormInf;
                tmpNorm2 += tmpVal * tmpVal;
            }
            retVal = !TypeUtils.isZero(tmpNorm2);
        }

        if (retVal) {

            double tmpScale = tmpVector[aRow] / tmpNormInf;
            tmpNorm2 += tmpScale * tmpScale;
            tmpNorm2 = Math.sqrt(tmpNorm2); // 2-norm of the vector to transform (scaled by inf-norm)

            if (tmpScale <= ZERO) {
                tmpScale -= tmpNorm2;
                tmpData[(aRow + tmpColBase)] = tmpNorm2 * tmpNormInf;
            } else {
                tmpScale += tmpNorm2;
                tmpData[(aRow + tmpColBase)] = -tmpNorm2 * tmpNormInf;
            }
            tmpVector[aRow] = INT_ONE;

            for (int i = aRow + INT_ONE; i < tmpRowDim; i++) {
                tmpData[i + tmpColBase] = tmpVector[i] /= tmpScale;
            }

            tmpDestination.beta = Math.abs(tmpScale) / tmpNorm2;
        }

        return retVal;
    }

    public final boolean generateApplyAndCopyHouseholderRow(final int aRow, final int aCol, final Householder<Double> aDestination) {

        final Householder.Primitive tmpDestination = (Householder.Primitive) aDestination;

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final double[] tmpVector = tmpDestination.vector;
        tmpDestination.first = aCol;

        double tmpNormInf = ZERO; // Copy row and calculate its infinity-norm.
        for (int j = aCol; j < tmpColDim; j++) {
            tmpNormInf = Math.max(tmpNormInf, Math.abs(tmpVector[j] = tmpData[aRow + j * tmpRowDim]));
        }

        boolean retVal = tmpNormInf != ZERO;
        double tmpVal;
        double tmpNorm2 = ZERO;

        if (retVal) {
            for (int j = aCol + INT_ONE; j < tmpColDim; j++) {
                tmpVal = tmpVector[j] /= tmpNormInf;
                tmpNorm2 += tmpVal * tmpVal;
            }
            retVal = !TypeUtils.isZero(tmpNorm2);
        }

        if (retVal) {

            double tmpScale = tmpVector[aCol] / tmpNormInf;
            tmpNorm2 += tmpScale * tmpScale;
            tmpNorm2 = Math.sqrt(tmpNorm2); // 2-norm of the vector to transform (scaled by inf-norm)

            if (tmpScale <= ZERO) {
                tmpScale -= tmpNorm2;
                tmpData[(aRow + aCol * tmpRowDim)] = tmpNorm2 * tmpNormInf;
            } else {
                tmpScale += tmpNorm2;
                tmpData[(aRow + aCol * tmpRowDim)] = -tmpNorm2 * tmpNormInf;
            }
            tmpVector[aCol] = INT_ONE;

            for (int j = aCol + INT_ONE; j < tmpColDim; j++) {
                tmpData[aRow + j * tmpRowDim] = tmpVector[j] /= tmpScale;
            }

            tmpDestination.beta = Math.abs(tmpScale) / tmpNorm2;
        }

        return retVal;
    }

    public Double get(final int aRow, final int aCol) {
        return myUtility.get(aRow, aCol);
    }

    public int getColDim() {
        return myColDim;
    }

    public PhysicalStore.Factory<Double> getFactory() {
        return FACTORY;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInColumn(aRow, aCol);
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInRow(aRow, aCol);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return MatrixUtils.hashCode(this);
    }

    public boolean isAbsolute(final int aRow, final int aCol) {
        return myUtility.isAbsolute(aRow, aCol);
    }

    public boolean isLowerLeftShaded() {
        return BOOLEAN_FALSE;
    }

    public boolean isReal(final int aRow, final int aCol) {
        return myUtility.isReal(aRow, aCol);
    }

    public boolean isUpperRightShaded() {
        return BOOLEAN_FALSE;
    }

    public boolean isZero(final int aRow, final int aCol) {
        return this.isZero(aRow + aCol * myRowDim);
    }

    public void maxpy(final Double aSclrA, final MatrixStore<Double> aMtrxX) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > MAXPY.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MAXPY.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MAXPY.invoke(PrimitiveDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aSclrA, aMtrxX);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            MAXPY.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aSclrA, aMtrxX);
        }
    }

    public void modifyAll(final UnaryFunction<Double> aFunc) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > ModifyAll.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ModifyAll.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    PrimitiveDenseStore.this.modify(tmpRowDim * aFirst, tmpRowDim * aLimit, INT_ONE, aFunc);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.modify(tmpRowDim * INT_ZERO, tmpRowDim * tmpColDim, INT_ONE, aFunc);
        }
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyColumn(aRow, aCol, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyDiagonal(aRow, aCol, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyRow(aRow, aCol, aFunc);
    }

    public MatrixStore<Double> multiplyLeft(final MatrixStore<Double> aStore) {

        final PrimitiveDenseStore retVal = (PrimitiveDenseStore) FACTORY.makeZero(aStore.getRowDim(), myColDim);

        PrimitiveDenseStore.doMultiplyLeft(retVal.data(), aStore, this.data());

        return retVal;
    }

    public MatrixStore<Double> multiplyRight(final MatrixStore<Double> aStore) {

        final PrimitiveDenseStore retVal = (PrimitiveDenseStore) FACTORY.makeZero(myRowDim, aStore.getColDim());

        PrimitiveDenseStore.doMultiplyRight(retVal.data(), this.data(), aStore);

        return retVal;
    }

    public void raxpy(final Double aSclrA, final int aRowX, final int aRowY, final int aFirstCol) {
        RAXPY.invoke(this.data(), aSclrA, this.data(), aRowX, aRowY, aFirstCol, myColDim);
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void set(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void substituteBackwards(final Access2D<Double> aBody, final boolean transposed) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > SubstituteBackwards.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(SubstituteBackwards.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    SubstituteBackwards.invoke(PrimitiveDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aBody, transposed);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            SubstituteBackwards.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aBody, transposed);
        }
    }

    public void substituteForwards(final Access2D<Double> aBody, final boolean onesOnDiagonal, final boolean zerosAboveDiagonal) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > SubstituteForwards.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(SubstituteForwards.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    SubstituteForwards.invoke(PrimitiveDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aBody, onesOnDiagonal, zerosAboveDiagonal);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            SubstituteForwards.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aBody, onesOnDiagonal, zerosAboveDiagonal);
        }
    }

    public PrimitiveScalar toScalar(final int aRow, final int aCol) {
        return new PrimitiveScalar(this.doubleValue(aRow + aCol * myRowDim));
    }

    public void transformLeft(final Householder<Double> aTransf, final int aFirstCol) {

        final Primitive tmpTransf = PrimitiveDenseStore.cast(aTransf);

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > HouseholderLeft.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(HouseholderLeft.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    HouseholderLeft.invoke(tmpData, tmpRowDim, aFirst, aLimit, tmpTransf);
                }

            };

            tmpConquerer.divide(aFirstCol, tmpColDim, ProcessorCount.getFree());

        } else {

            HouseholderLeft.invoke(tmpData, tmpRowDim, aFirstCol, tmpColDim, tmpTransf);
        }
    }

    public void transformLeft(final Rotation<Double> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {
            if ((aTransf.cos != null) && (aTransf.sin != null)) {
                RotateLeft.invoke(this.data(), myColDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);
            } else {
                myUtility.exchangeRows(tmpLow, tmpHigh);
            }
        } else {
            if (aTransf.cos != null) {
                myUtility.modifyRow(tmpLow, INT_ZERO, MULTIPLY, aTransf.cos);
            } else if (aTransf.sin != null) {
                myUtility.modifyRow(tmpLow, INT_ZERO, DIVIDE, aTransf.sin);
            } else {
                myUtility.modifyRow(tmpLow, INT_ZERO, NEGATE);
            }
        }
    }

    public void transformRight(final Householder<Double> aTransf, final int aFirstRow) {

        final Primitive tmpTransf = PrimitiveDenseStore.cast(aTransf);

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > HouseholderRight.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(HouseholderRight.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    HouseholderRight.invoke(tmpData, aFirst, aLimit, tmpColDim, tmpTransf);
                }

            };

            tmpConquerer.divide(aFirstRow, tmpRowDim, ProcessorCount.getFree());

        } else {

            HouseholderRight.invoke(tmpData, aFirstRow, tmpRowDim, tmpColDim, tmpTransf);
        }
    }

    public void transformRight(final Rotation<Double> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {
            if ((aTransf.cos != null) && (aTransf.sin != null)) {
                RotateRight.doRotateRight(this.data(), myRowDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);
            } else {
                myUtility.exchangeColumns(tmpLow, tmpHigh);
            }
        } else {
            if (aTransf.cos != null) {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, MULTIPLY, aTransf.cos);
            } else if (aTransf.sin != null) {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, DIVIDE, aTransf.sin);
            } else {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, NEGATE);
            }
        }
    }

    public PrimitiveDenseStore transpose() {
        return (PrimitiveDenseStore) FACTORY.transpose(this);
    }

    public void visitAll(final AggregatorFunction<Double> aVisitor) {
        myUtility.visitAll(aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitColumn(aRow, aCol, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitDiagonal(aRow, aCol, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitRow(aRow, aCol, aVisitor);
    }

}
