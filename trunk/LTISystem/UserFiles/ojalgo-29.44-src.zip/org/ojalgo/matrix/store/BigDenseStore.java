/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import static org.ojalgo.constant.BigMath.*;
import static org.ojalgo.function.implementation.BigFunction.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.OjAlgoUtils;
import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.access.SimpleArray;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.array.BigArray;
import org.ojalgo.concurrent.DaemonPoolExecutor;
import org.ojalgo.concurrent.DivideAndConquer;
import org.ojalgo.concurrent.DivideAndMerge;
import org.ojalgo.concurrent.ProcessorCount;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.Aggregator;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.BigAggregator;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.operation.*;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.BigScalar;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * A {@linkplain BigDecimal} implementation of {@linkplain PhysicalStore}.
 *
 * @author apete
 */
public final class BigDenseStore extends BigArray implements PhysicalStore<BigDecimal>, DecompositionStore<BigDecimal> {

    public static final DecompositionStore.Factory<BigDecimal> FACTORY = new DecompositionStore.Factory<BigDecimal>() {

        public BigDenseStore conjugate(final Access2D<? extends Number> aSource) {
            return this.transpose(aSource);
        }

        public BigDenseStore copy(final Access2D<? extends Number> aSource) {

            final BigDenseStore retVal = new BigDenseStore(aSource.getRowDim(), aSource.getColDim());

            retVal.fillMatching(aSource);

            return retVal;
        }

        public BigDenseStore copy(final double[][] aSource) {

            final BigDenseStore retVal = new BigDenseStore(aSource.length, aSource[INT_ZERO].length);

            retVal.fillMatching(ArrayUtils.wrapAccess2D(aSource));

            return retVal;
        }

        public AggregatorCollection<BigDecimal> getAggregatorCollection() {
            return BigAggregator.getCollection();
        }

        public FunctionSet<BigDecimal> getFunctionSet() {
            return BigFunction.getSet();
        }

        public BigDecimal getNumber(final double aNmbr) {
            return new BigDecimal(aNmbr);
        }

        public BigDecimal getNumber(final Number aNmbr) {
            return TypeUtils.toBigDecimal(aNmbr);
        }

        public BigScalar getStaticOne() {
            return BigScalar.ONE;
        }

        public BigScalar getStaticZero() {
            return BigScalar.ZERO;
        }

        public PhysicalStore<BigDecimal> makeColumn(final Access1D<? extends Number> aColumn) {

            final int tmpRowDim = aColumn.size();
            final BigDecimal[] retValData = new BigDecimal[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = TypeUtils.toBigDecimal(aColumn.get(i));
            }

            return new BigDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public BigDenseStore makeColumn(final BigDecimal[] aColumn) {
            return new BigDenseStore(aColumn.length, INT_ONE, ArrayUtils.copyOf(aColumn));
        }

        public BigDenseStore makeColumn(final double[] aColumn) {

            final int tmpRowDim = aColumn.length;
            final BigDecimal[] retValData = new BigDecimal[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = new BigDecimal(aColumn[i]);
            }

            return new BigDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public BigDenseStore makeColumn(final List<BigDecimal> aColumn) {

            final int tmpRowDim = aColumn.size();
            final BigDecimal[] retValData = new BigDecimal[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = aColumn.get(i);
            }

            return new BigDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public BigDenseStore makeEmpty(final int aRowDim, final int aColDim) {
            return new BigDenseStore(aRowDim, aColDim, new BigDecimal[aRowDim * aColDim]);
        }

        public BigDenseStore makeEye(final int aRowDim, final int aColDim) {

            final BigDenseStore retVal = this.makeZero(aRowDim, aColDim);

            retVal.myUtility.fillDiagonal(INT_ZERO, INT_ZERO, this.getStaticOne().getNumber());

            return retVal;
        }

        public Householder.Big makeHouseholderWorker(final int aLength) {
            return new Householder.Big(aLength);
        }

        public SimpleArray.Big makeSimpleArrayWorker(final int aLength) {
            return SimpleArray.makeBig(aLength);
        }

        public BigDenseStore makeZero(final int aRowDim, final int aColDim) {
            return new BigDenseStore(aRowDim, aColDim);
        }

        public BigScalar toScalar(final double aNmbr) {
            return new BigScalar(aNmbr);
        }

        public BigScalar toScalar(final Number aNmbr) {
            return new BigScalar(TypeUtils.toBigDecimal(aNmbr));
        }

        public BigDenseStore transpose(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final BigDecimal[] retValData = new BigDecimal[tmpRowDim * tmpColDim];

            if (tmpColDim > Transpose.TRESHOLD) {

                final DivideAndConquer tmpConquerer = new DivideAndConquer(Transpose.TRESHOLD) {

                    @Override
                    public void conquer(final int aFirst, final int aLimit) {
                        Transpose.invoke(retValData, tmpRowDim, aFirst, aLimit, aSource);
                    }

                };

                tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

            } else {

                Transpose.invoke(retValData, tmpRowDim, INT_ZERO, tmpColDim, aSource);
            }

            return new BigDenseStore(tmpRowDim, tmpColDim, retValData);
        }
    };

    static Householder.Big cast(final Householder<BigDecimal> aTransf) {
        if (aTransf instanceof Householder.Big) {
            return (Householder.Big) aTransf;
        } else if (aTransf instanceof DecompositionStore.HouseholderReference) {
            final DecompositionStore.HouseholderReference<BigDecimal> tmpTransf = (DecompositionStore.HouseholderReference<BigDecimal>) aTransf;
            return tmpTransf.getBigWorker().copy(tmpTransf);
        } else {
            return new Householder.Big(aTransf);
        }
    }

    static BigDenseStore cast(final MatrixStore<BigDecimal> aStore) {
        if (aStore instanceof BigDenseStore) {
            return (BigDenseStore) aStore;
        } else {
            return (BigDenseStore) FACTORY.copy(aStore);
        }
    }

    static void doHouseholderLeft(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Householder.Big aHouseholder, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > INT_ONE) && (tmpColCount > HouseholderLeft.TRESHOLD)) {

            final int tmpSplit = aFirstCol + tmpColCount / INT_TWO;
            final int tmpCPUs = availableCPUs / INT_TWO;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderLeft(aData, aRowDim, aFirstCol, tmpSplit, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderLeft(aData, aRowDim, tmpSplit, aColLimit, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            HouseholderLeft.invoke(aData, aRowDim, aFirstCol, aColLimit, aHouseholder);
        }
    }

    static void doHouseholderRight(final BigDecimal[] aData, final int aFirstRow, final int aRowLimit, final int aColDim, final Householder.Big aHouseholder, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > INT_ONE) && (tmpRowCount > HouseholderRight.TRESHOLD)) {

            final int tmpSplit = aFirstRow + tmpRowCount / INT_TWO;
            final int tmpCPUs = availableCPUs / INT_TWO;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderRight(aData, aFirstRow, tmpSplit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderRight(aData, tmpSplit, aRowLimit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            HouseholderRight.invoke(aData, aFirstRow, aRowLimit, aColDim, aHouseholder);
        }
    }

    static void doMultiplyBoth(final BigDecimal[] aProductArray, final Access2D<BigDecimal> aLeftStore, final Access2D<BigDecimal> aRightStore) {

        final int tmpRowDim = aLeftStore.getRowDim();

        if (tmpRowDim > MultiplyBoth.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyBoth.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyBoth.invoke(aProductArray, aFirst, aLimit, aLeftStore, aRightStore);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpRowDim, ProcessorCount.getFree());

        } else {

            MultiplyBoth.invoke(aProductArray, INT_ZERO, tmpRowDim, aLeftStore, aRightStore);
        }
    }

    static void doMultiplyLeft(final BigDecimal[] aProductArray, final MatrixStore<BigDecimal> aLeftStore, final BigDecimal[] aRightArray) {

        final int tmpRowDim = aLeftStore.getRowDim();

        if (tmpRowDim > MultiplyLeft.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyLeft.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyLeft.invoke(aProductArray, aFirst, aLimit, aLeftStore, aRightArray);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpRowDim, ProcessorCount.getFree());

        } else {

            MultiplyLeft.invoke(aProductArray, INT_ZERO, tmpRowDim, aLeftStore, aRightArray);
        }
    }

    static void doMultiplyRight(final BigDecimal[] aProductArray, final BigDecimal[] aLeftArray, final MatrixStore<BigDecimal> aRightStore) {

        final int tmpColDim = aRightStore.getColDim();

        if (tmpColDim > MultiplyRight.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyRight.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyRight.invoke(aProductArray, aFirst, aLimit, aLeftArray, aRightStore);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            MultiplyRight.invoke(aProductArray, INT_ZERO, tmpColDim, aLeftArray, aRightStore);
        }
    }

    private final int myColDim;
    private final int myRowDim;
    private final Array2D<BigDecimal> myUtility;

    BigDenseStore(final BigDecimal[] anArray) {

        super(anArray);

        myRowDim = anArray.length;
        myColDim = INT_ONE;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    BigDenseStore(final int aLength) {

        super(aLength);

        myRowDim = aLength;
        myColDim = INT_ONE;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    BigDenseStore(final int aRowDim, final int aColDim) {

        super(aRowDim * aColDim);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    BigDenseStore(final int aRowDim, final int aColDim, final BigDecimal[] anArray) {

        super(anArray);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    public BigDecimal aggregateAll(final Aggregator aVisitor) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > AggregateAll.TRESHOLD) {

            final DivideAndMerge<BigDecimal> tmpConquerer = new DivideAndMerge<BigDecimal>(AggregateAll.TRESHOLD) {

                @Override
                public BigDecimal conquer(final int aFirst, final int aLimit) {

                    final AggregatorFunction<BigDecimal> tmpAggrFunc = aVisitor.getBigFunction();

                    BigDenseStore.this.visit(tmpRowDim * aFirst, tmpRowDim * aLimit, INT_ONE, tmpAggrFunc);

                    return tmpAggrFunc.getNumber();
                }

                @Override
                public BigDecimal merge(final BigDecimal aFirstResult, final BigDecimal aSecondResult) {

                    final AggregatorFunction<BigDecimal> tmpAggrFunc = aVisitor.getBigFunction();

                    tmpAggrFunc.merge(aFirstResult);
                    tmpAggrFunc.merge(aSecondResult);

                    return tmpAggrFunc.getNumber();
                }
            };

            return tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            final AggregatorFunction<BigDecimal> tmpAggrFunc = aVisitor.getBigFunction();

            BigDenseStore.this.visit(INT_ZERO, length, INT_ONE, tmpAggrFunc);

            return tmpAggrFunc.getNumber();
        }
    }

    public void applyCholesky(final int aNextIndex, final int aDim, final SimpleArray<BigDecimal> aMultipliers) {

        final BigDecimal[] tmpData = this.data();
        final BigDecimal[] tmpColumn = ((SimpleArray.Big) aMultipliers).data;

        if (aDim - aNextIndex > ApplyCholesky.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ApplyCholesky.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ApplyCholesky.invoke(tmpData, aDim, aFirst, aLimit, tmpColumn);
                }

            };

            tmpConquerer.divide(aNextIndex, aDim, ProcessorCount.getFree());

        } else {

            ApplyCholesky.invoke(tmpData, aDim, aNextIndex, aDim, tmpColumn);
        }
    }

    public void applyLU(final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColDim, final SimpleArray<BigDecimal> aMultipliers) {

        final BigDecimal[] tmpData = this.data();
        final BigDecimal[] tmpColumn = ((SimpleArray.Big) aMultipliers).data;

        if (aColDim - aFirstCol > ApplyLU.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ApplyLU.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ApplyLU.invoke(tmpData, aPivotRow, aRowDim, aFirst, aLimit, tmpColumn);
                }
            };

            tmpConquerer.divide(aFirstCol, aColDim, ProcessorCount.getFull());

        } else {

            ApplyLU.invoke(tmpData, aPivotRow, aRowDim, aFirstCol, aColDim, tmpColumn);
        }
    }

    public Array2D<BigDecimal> asArray2D() {
        return myUtility;
    }

    public Array1D<BigDecimal> asList() {
        return myUtility.asArray1D();
    }

    public final MatrixStore.Builder<BigDecimal> builder() {
        return new MatrixStore.Builder<BigDecimal>(this);
    }

    public void caxpy(final BigDecimal aSclrA, final int aColX, final int aColY, final int aFirstRow) {
        CAXPY.invoke(this.data(), aSclrA, this.data(), aColX, aColY, aFirstRow, myRowDim);
    }

    public boolean computeInPlaceCholesky(final boolean checkForSPD) {

        // true if (Symmetric) Positive Definite 
        boolean retVal = myRowDim == myColDim;

        final int tmpDim = myRowDim;

        final BigDecimal[] tmpData = this.data();
        int tmpIndex;

        // Check for symmetry, maybe
        if (retVal && checkForSPD) {
            for (int j = INT_ZERO; retVal && (j < tmpDim); j++) {
                for (int i = j + INT_ONE; retVal && (i < tmpDim); i++) {
                    retVal &= tmpData[i + j * tmpDim].subtract(tmpData[j + i * tmpDim]).signum() == INT_ZERO;
                }
            }
        }

        final SimpleArray.Big tmpMultipliers = SimpleArray.makeBig(tmpDim);
        final BigDecimal[] tmpColumn = tmpMultipliers.data;
        BigDecimal tmpVal;

        // Main loop - along the diagonal
        for (int ij = INT_ZERO; retVal && (ij < tmpDim); ij++) {

            // "Pivot" element
            tmpVal = tmpData[tmpIndex = ij + ij * tmpDim];

            if (tmpVal.signum() == INT_ONE) {

                tmpColumn[ij] = tmpData[tmpIndex] = tmpVal = BigFunction.SQRT.invoke(tmpVal);

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                this.divideAndCopyColumn(ij + INT_ONE, ij, tmpVal, tmpMultipliers);

                // Remaining columns, below the diagonal
                this.applyCholesky(ij + INT_ONE, tmpDim, tmpMultipliers);

            } else {

                retVal = BOOLEAN_FALSE;
            }
        }

        return retVal;
    }

    public Pivot computeInPlaceLU(final boolean assumeNoPivotingRequired) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;
        final int tmpMinDim = Math.min(tmpRowDim, tmpColDim);

        final Pivot retVal = new Pivot(tmpRowDim);

        final BigDecimal[] tmpData = this.data();
        int tmpIndex;

        int tmpPivotRowIndex;

        final SimpleArray.Big tmpMultipliers = SimpleArray.makeBig(tmpRowDim);
        BigDecimal tmpNmbr;

        // Main loop - along the diagonal
        for (int ij = INT_ZERO; ij < tmpMinDim; ij++) {

            final int tmpPivotRow = ij;
            final int tmpFirstCol = ij + INT_ONE;

            if (!assumeNoPivotingRequired) {
                // Find next pivot row, stop searching when something good enough is found
                tmpNmbr = tmpData[tmpIndex = ij + tmpRowDim * ij].abs();
                tmpPivotRowIndex = ij;
                for (int i = ij + INT_ONE; (i < tmpRowDim) && (tmpNmbr.compareTo(HALF) == -INT_ONE); i++) {
                    if (tmpData[++tmpIndex].abs().compareTo(tmpNmbr) == INT_ONE) {
                        tmpNmbr = tmpData[tmpIndex].abs();
                        tmpPivotRowIndex = i;
                    }
                }
                // Pivot?
                if (tmpPivotRowIndex != ij) {
                    myUtility.exchangeRows(tmpPivotRowIndex, ij);
                    retVal.change(tmpPivotRowIndex, ij);
                }
            }

            // Do the calculations...

            // "Pivot" element
            tmpNmbr = tmpData[tmpIndex = ij + tmpRowDim * ij];
            if (tmpNmbr.signum() != INT_ZERO) {

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                this.divideAndCopyColumn(ij + INT_ONE, ij, tmpNmbr, tmpMultipliers);

                // Apply transformations to everything below and to the right of the pivot element
                this.applyLU(tmpPivotRow, tmpRowDim, tmpFirstCol, tmpColDim, tmpMultipliers);

            } else {

                tmpData[tmpIndex] = ZERO;
            }
        }

        return retVal;
    }

    public Array1D<ComplexNumber> computeInPlaceSchur(final PhysicalStore<BigDecimal> aTransformationCollector, final boolean eigenvalue) {
        throw new UnsupportedOperationException();
    }

    public void computeInPlaceTridiagonal() {

        final int tmpDim = myRowDim;
        final int tmpLim = tmpDim - INT_TWO;

        final BigDecimal[] tmpData = this.data();

        final Householder.Big tmpHousehoulder = new Householder.Big(tmpDim);

        int tmpNext;
        for (int ij = INT_ZERO; ij < tmpLim; ij++) {

            tmpNext = ij + INT_ONE;

            if (this.generateApplyAndCopyHouseholderColumn(tmpNext, ij, tmpHousehoulder)) {
                BigDenseStore.doHouseholderLeft(tmpData, tmpDim, tmpNext, tmpDim, tmpHousehoulder, OjAlgoUtils.HARDWARE.processors);
                BigDenseStore.doHouseholderRight(tmpData, tmpNext, tmpDim, tmpDim, tmpHousehoulder, OjAlgoUtils.HARDWARE.processors);
            }
        }
    }

    public BigDenseStore conjugate() {
        return this.transpose();
    }

    public BigDenseStore copy() {
        return new BigDenseStore(myRowDim, myColDim, this.copyOfData());
    }

    public void divideAndCopyColumn(final int aRow, final int aCol, final BigDecimal aNumerator, final SimpleArray<BigDecimal> aDestination) {

        final BigDecimal[] tmpDestination = ((SimpleArray.Big) aDestination).data;

        final BigDecimal[] tmpData = this.data();
        final int tmpRowDim = myRowDim;

        int tmpIndex = aRow + aCol * tmpRowDim;
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpDestination[i] = tmpData[tmpIndex] = BigFunction.DIVIDE.invoke(tmpData[tmpIndex], aNumerator);
            tmpIndex++;
        }
    }

    public double doubleValue(final int aRow, final int aCol) {
        return myUtility.doubleValue(aRow, aCol);
    }

    public boolean equals(final MatrixStore<BigDecimal> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this, aStore, aCntxt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof MatrixStore) {
            return this.equals((MatrixStore<BigDecimal>) anObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(anObj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myUtility.exchangeColumns(aColA, aColB);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myUtility.exchangeRows(aRowA, aRowB);
    }

    public void fillAll(final BigDecimal aNmbr) {
        myUtility.fillAll(aNmbr);
    }

    public void fillByMultiplying(final MatrixStore<BigDecimal> aLeftStore, final MatrixStore<BigDecimal> aRightStore) {

        final BigDecimal[] tmpProductData = this.data();

        if (aRightStore instanceof BigDenseStore) {

            BigDenseStore.doMultiplyLeft(tmpProductData, aLeftStore, BigDenseStore.cast(aRightStore).data());

        } else if (aLeftStore instanceof BigDenseStore) {

            BigDenseStore.doMultiplyRight(tmpProductData, BigDenseStore.cast(aLeftStore).data(), aRightStore);

        } else {

            BigDenseStore.doMultiplyBoth(tmpProductData, aLeftStore, aRightStore);
        }
    }

    public void fillColumn(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.fillColumn(aRow, aCol, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.fillDiagonal(aRow, aCol, aNmbr);
    }

    public void fillMatching(final Access2D<? extends Number> aSource2D) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > Copy.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(Copy.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    Copy.invoke(BigDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aSource2D);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            Copy.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aSource2D);
        }
    }

    public void fillMatching(final BigDecimal aLeftArg, final BinaryFunction<BigDecimal> aFunc, final MatrixStore<BigDecimal> aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingRight.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingRight.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    BigDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillMatching(final MatrixStore<BigDecimal> aLeftArg, final BinaryFunction<BigDecimal> aFunc, final BigDecimal aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingLeft.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingLeft.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    BigDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillMatching(final MatrixStore<BigDecimal> aLeftArg, final BinaryFunction<BigDecimal> aFunc, final MatrixStore<BigDecimal> aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingBoth.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingBoth.TRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    BigDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillRow(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.fillRow(aRow, aCol, aNmbr);
    }

    public final boolean generateApplyAndCopyHouseholderColumn(final int aRow, final int aCol, final Householder<BigDecimal> aDestination) {

        final Householder.Big tmpDestination = (Householder.Big) aDestination;

        final BigDecimal[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColBase = aCol * tmpRowDim;

        final BigDecimal[] tmpVector = tmpDestination.vector;
        tmpDestination.first = aRow;

        BigDecimal tmpNormInf = ZERO;
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpNormInf = tmpNormInf.max((tmpVector[i] = tmpData[i + tmpColBase]).abs());
        }

        boolean retVal = tmpNormInf.signum() != INT_ZERO;
        BigDecimal tmpVal;
        BigDecimal tmpNorm2 = ZERO;

        if (retVal) {
            for (int i = aRow + INT_ONE; i < tmpRowDim; i++) {
                tmpVal = BigFunction.DIVIDE.invoke(tmpVector[i], tmpNormInf);
                tmpNorm2 = BigFunction.ADD.invoke(tmpNorm2, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
                tmpVector[i] = tmpVal;
            }
            retVal = !TypeUtils.isZero(tmpNorm2.doubleValue());
        }

        if (retVal) {

            BigDecimal tmpScale = BigFunction.DIVIDE.invoke(tmpVector[aRow], tmpNormInf);
            tmpNorm2 = BigFunction.ADD.invoke(tmpNorm2, BigFunction.MULTIPLY.invoke(tmpScale, tmpScale));
            tmpNorm2 = BigFunction.SQRT.invoke(tmpNorm2);

            if (tmpScale.signum() != INT_ONE) {
                tmpScale = BigFunction.SUBTRACT.invoke(tmpScale, tmpNorm2);
                tmpData[aRow + tmpColBase] = tmpNorm2.multiply(tmpNormInf);
            } else {
                tmpScale = BigFunction.ADD.invoke(tmpScale, tmpNorm2);
                tmpData[aRow + tmpColBase] = tmpNorm2.negate().multiply(tmpNormInf);
            }
            tmpVector[aRow] = ONE;

            for (int i = aRow + INT_ONE; i < tmpRowDim; i++) {
                tmpVector[i] = tmpData[i + tmpColBase] = BigFunction.DIVIDE.invoke(tmpVector[i], tmpScale);
            }

            tmpDestination.beta = BigFunction.DIVIDE.invoke(tmpScale.abs(), tmpNorm2);
        }

        return retVal;
    }

    public final boolean generateApplyAndCopyHouseholderRow(final int aRow, final int aCol, final Householder<BigDecimal> aDestination) {

        final Householder.Big tmpDestination = (Householder.Big) aDestination;

        final BigDecimal[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final BigDecimal[] tmpVector = tmpDestination.vector;
        tmpDestination.first = aCol;

        BigDecimal tmpNormInf = ZERO;
        for (int j = aCol; j < tmpColDim; j++) {
            tmpNormInf = tmpNormInf.max((tmpVector[j] = tmpData[aRow + j * tmpRowDim]).abs());
        }

        boolean retVal = tmpNormInf.signum() != INT_ZERO;
        BigDecimal tmpVal;
        BigDecimal tmpNorm2 = ZERO;

        if (retVal) {
            for (int j = aCol + INT_ONE; j < tmpColDim; j++) {
                tmpVal = BigFunction.DIVIDE.invoke(tmpVector[j], tmpNormInf);
                tmpNorm2 = BigFunction.ADD.invoke(tmpNorm2, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
                tmpVector[j] = tmpVal;
            }
            retVal = !TypeUtils.isZero(tmpNorm2.doubleValue());
        }

        if (retVal) {

            BigDecimal tmpScale = BigFunction.DIVIDE.invoke(tmpVector[aCol], tmpNormInf);
            tmpNorm2 = BigFunction.ADD.invoke(tmpNorm2, BigFunction.MULTIPLY.invoke(tmpScale, tmpScale));
            tmpNorm2 = BigFunction.SQRT.invoke(tmpNorm2);

            if (tmpScale.signum() != INT_ONE) {
                tmpScale = BigFunction.SUBTRACT.invoke(tmpScale, tmpNorm2);
                tmpData[(aRow + aCol * tmpRowDim)] = tmpNorm2.multiply(tmpNormInf);
            } else {
                tmpScale = BigFunction.ADD.invoke(tmpScale, tmpNorm2);
                tmpData[(aRow + aCol * tmpRowDim)] = tmpNorm2.negate().multiply(tmpNormInf);
            }
            tmpVector[aCol] = ONE;

            for (int j = aCol + INT_ONE; j < tmpColDim; j++) {
                tmpVector[j] = tmpData[aRow + j * tmpRowDim] = BigFunction.DIVIDE.invoke(tmpVector[j], tmpScale);
            }

            tmpDestination.beta = BigFunction.DIVIDE.invoke(tmpScale.abs(), tmpNorm2);
        }

        return retVal;
    }

    public BigDecimal get(final int aRow, final int aCol) {
        return myUtility.get(aRow, aCol);
    }

    public int getColDim() {
        return myColDim;
    }

    public PhysicalStore.Factory<BigDecimal> getFactory() {
        return FACTORY;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInColumn(aRow, aCol);
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInRow(aRow, aCol);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return MatrixUtils.hashCode(this);
    }

    public boolean isAbsolute(final int aRow, final int aCol) {
        return myUtility.isAbsolute(aRow, aCol);
    }

    public boolean isLowerLeftShaded() {
        return BOOLEAN_FALSE;
    }

    public boolean isReal(final int aRow, final int aCol) {
        return myUtility.isReal(aRow, aCol);
    }

    public boolean isUpperRightShaded() {
        return BOOLEAN_FALSE;
    }

    public boolean isZero(final int aRow, final int aCol) {
        return myUtility.isZero(aRow, aCol);
    }

    public void maxpy(final BigDecimal aSclrA, final MatrixStore<BigDecimal> aMtrxX) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > MAXPY.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MAXPY.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MAXPY.invoke(BigDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aSclrA, aMtrxX);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            MAXPY.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aSclrA, aMtrxX);
        }
    }

    public void modifyAll(final UnaryFunction<BigDecimal> aFunc) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > ModifyAll.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ModifyAll.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    BigDenseStore.this.modify(tmpRowDim * aFirst, tmpRowDim * aLimit, INT_ONE, aFunc);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            this.modify(tmpRowDim * INT_ZERO, tmpRowDim * tmpColDim, INT_ONE, aFunc);
        }
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<BigDecimal> aFunc) {
        myUtility.modifyColumn(aRow, aCol, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<BigDecimal> aFunc) {
        myUtility.modifyDiagonal(aRow, aCol, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<BigDecimal> aFunc) {
        myUtility.modifyRow(aRow, aCol, aFunc);
    }

    public MatrixStore<BigDecimal> multiplyLeft(final MatrixStore<BigDecimal> aStore) {

        final BigDenseStore retVal = (BigDenseStore) FACTORY.makeZero(aStore.getRowDim(), myColDim);

        BigDenseStore.doMultiplyLeft(retVal.data(), aStore, this.data());

        return retVal;
    }

    public MatrixStore<BigDecimal> multiplyRight(final MatrixStore<BigDecimal> aStore) {

        final BigDenseStore retVal = (BigDenseStore) FACTORY.makeZero(myRowDim, aStore.getColDim());

        BigDenseStore.doMultiplyRight(retVal.data(), this.data(), aStore);

        return retVal;
    }

    public void raxpy(final BigDecimal aSclrA, final int aRowX, final int aRowY, final int aFirstCol) {
        RAXPY.invoke(this.data(), aSclrA, this.data(), aRowX, aRowY, aFirstCol, myColDim);
    }

    public void set(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void substituteBackwards(final Access2D<BigDecimal> aBody, final boolean transposed) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > SubstituteBackwards.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(SubstituteBackwards.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    SubstituteBackwards.invoke(BigDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aBody, transposed);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            SubstituteBackwards.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aBody, transposed);
        }
    }

    public void substituteForwards(final Access2D<BigDecimal> aBody, final boolean onesOnDiagonal, final boolean zerosAboveDiagonal) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > SubstituteForwards.TRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(SubstituteForwards.TRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    SubstituteForwards.invoke(BigDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aBody, onesOnDiagonal, zerosAboveDiagonal);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, ProcessorCount.getFree());

        } else {

            SubstituteForwards.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aBody, onesOnDiagonal, zerosAboveDiagonal);
        }
    }

    public Scalar<BigDecimal> toScalar(final int aRow, final int aCol) {
        return new BigScalar(this.get(aRow, aCol));
    }

    public void transformLeft(final Householder<BigDecimal> aTransf, final int aFirstCol) {
        BigDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, BigDenseStore.cast(aTransf), OjAlgoUtils.HARDWARE.processors);
    }

    public void transformLeft(final Rotation<BigDecimal> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {
            if ((aTransf.cos != null) && (aTransf.sin != null)) {
                RotateLeft.invoke(this.data(), myColDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);
            } else {
                myUtility.exchangeRows(tmpLow, tmpHigh);
            }
        } else {
            if (aTransf.cos != null) {
                myUtility.modifyRow(tmpLow, INT_ZERO, MULTIPLY, aTransf.cos);
            } else if (aTransf.sin != null) {
                myUtility.modifyRow(tmpLow, INT_ZERO, DIVIDE, aTransf.sin);
            } else {
                myUtility.modifyRow(tmpLow, INT_ZERO, NEGATE);
            }
        }
    }

    public void transformRight(final Householder<BigDecimal> aTransf, final int aFirstRow) {
        BigDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, BigDenseStore.cast(aTransf), OjAlgoUtils.HARDWARE.processors);
    }

    public void transformRight(final Rotation<BigDecimal> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {
            if ((aTransf.cos != null) && (aTransf.sin != null)) {
                RotateRight.doRotateRight(this.data(), myRowDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);
            } else {
                myUtility.exchangeColumns(tmpLow, tmpHigh);
            }
        } else {
            if (aTransf.cos != null) {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, MULTIPLY, aTransf.cos);
            } else if (aTransf.sin != null) {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, DIVIDE, aTransf.sin);
            } else {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, NEGATE);
            }
        }
    }

    public BigDenseStore transpose() {
        return (BigDenseStore) FACTORY.transpose(this);
    }

    public void visitAll(final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitAll(aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitColumn(aRow, aCol, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitDiagonal(aRow, aCol, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitRow(aRow, aCol, aVisitor);
    }

}
