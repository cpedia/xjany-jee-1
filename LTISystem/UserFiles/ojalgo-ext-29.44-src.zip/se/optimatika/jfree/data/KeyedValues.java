/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jfree.data;

import java.awt.Paint;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.jfree.data.general.DefaultKeyedValuesDataset;
import org.jfree.data.general.KeyedValuesDataset;
import org.ojalgo.chart.Type;

import se.optimatika.jfree.chart.JFreeChartAdaptor;

/**
 * @see KeyedValuesDataset
 * @author apete
 */
public class KeyedValues extends JFreeChartBuilder {

    private final Map<String, Paint> myColours = new HashMap<String, Paint>();
    private final DefaultKeyedValuesDataset myDataset = new DefaultKeyedValuesDataset();

    public KeyedValues(Type aType) {
        super(aType);
    }

    @Override
    public JFreeChartAdaptor build(Type aType) {

        switch (aType) {

        case PieChart:

            return this.createPieChart(this.getTitle(), myDataset, this.isLegend(), myColours);

        case PieChart3D:

            return this.createPieChart3D(this.getTitle(), myDataset, this.isLegend(), myColours);

        case RingChart:

            return this.createRingChart(this.getTitle(), myDataset, this.isLegend(), myColours);

        default:

            return this.createPieChart(this.getTitle(), myDataset, this.isLegend(), myColours);
        }
    }

    public void setValue(String aKey, Paint aPaint, BigDecimal aValue) {
        myDataset.setValue(aKey, aValue);
        myColours.put(aKey, aPaint);
    }

}
