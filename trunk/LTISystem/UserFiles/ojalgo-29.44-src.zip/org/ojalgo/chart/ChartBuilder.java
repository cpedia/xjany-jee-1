/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.chart;

import java.awt.Paint;

import org.ojalgo.ProgrammingError;

public abstract class ChartBuilder {

    private boolean myLegend = false;
    private Orientation myOrientation = Orientation.VERTICAL;
    private Priority myPriority = Priority.COLUMN;
    private String myTitle = null;
    private final Type myType;
    private Paint myBackground;
    private boolean myBorder;
    private Paint myPlotBackground;
    private Paint myPlotOutline;

    public ChartBuilder(Type aType) {

        super();

        myType = aType;
    }

    @SuppressWarnings("unused")
    private ChartBuilder() {

        super();

        myType = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    public final ChartBuilder background(Paint aPaint) {
        myBackground = aPaint;
        return this;
    }

    public final ChartBuilder border(boolean aFlag) {
        myBorder = aFlag;
        return this;
    }

    public final <T> BasicChart<T> build() {
        return this.build(myType);
    }

    public abstract <T> BasicChart<T> build(Type aType);

    public final ChartBuilder legend(boolean aFlag) {
        myLegend = aFlag;
        return this;
    }

    public final ChartBuilder orientation(Orientation anOrientation) {
        myOrientation = anOrientation;
        return this;
    }

    public final ChartBuilder plotBackground(Paint aPaint) {
        myPlotBackground = aPaint;
        return this;
    }

    public final ChartBuilder plotOutline(Paint aPaint) {
        myPlotOutline = aPaint;
        return this;

    }

    public final ChartBuilder priority(Priority aPriority) {
        myPriority = aPriority;
        return this;
    }

    public final ChartBuilder title(String aTitle) {
        myTitle = aTitle;
        return this;
    }

    protected final Paint getBackground() {
        return myBackground;
    }

    protected final Orientation getOrientation() {
        return myOrientation;
    }

    protected final Paint getPlotBackground() {
        return myPlotBackground;
    }

    protected final Paint getPlotOutline() {
        return myPlotOutline;
    }

    protected final Priority getPriority() {
        return myPriority;
    }

    protected final String getTitle() {
        return myTitle;
    }

    protected final boolean isBorder() {
        return myBorder;
    }

    protected final boolean isLegend() {
        return myLegend;
    }

}
