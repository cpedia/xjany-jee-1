/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jexcel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import jxl.BooleanCell;
import jxl.Cell;
import jxl.CellType;
import jxl.DateCell;
import jxl.LabelCell;
import jxl.NumberCell;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.DisplayFormat;
import jxl.format.CellFormat;
import jxl.read.biff.BiffException;
import jxl.write.NumberFormat;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.PrimitiveMatrix;

import se.optimatika.jexcel.database.Column;
import se.optimatika.jexcel.database.Table;

public class InMemorySpreadsheet implements Spreadsheet {

    private static final int FIRST = 0;
    private static final int LAST = Integer.MAX_VALUE;

    private int myColumn;
    private int myRow;
    private WritableSheet mySheet;
    private final ByteArrayOutputStream myStream;
    private final WritableWorkbook myWorkbook;

    public InMemorySpreadsheet() {

        super();

        myStream = new ByteArrayOutputStream();

        WritableWorkbook tmpWorkbook;
        try {
            tmpWorkbook = Workbook.createWorkbook(myStream, new WorkbookSettings());
        } catch (IOException anException) {
            tmpWorkbook = null;
        }
        myWorkbook = tmpWorkbook;
    }

    public InMemorySpreadsheet(InputStream aStream) {

        super();

        myStream = new ByteArrayOutputStream();

        WritableWorkbook tmpWorkbook;
        try {
            tmpWorkbook = Workbook.createWorkbook(myStream, Workbook.getWorkbook(aStream));
        } catch (BiffException anException) {
            tmpWorkbook = null;
            anException.printStackTrace();
        } catch (IOException anException) {
            tmpWorkbook = null;
            anException.printStackTrace();
        }
        myWorkbook = tmpWorkbook;
    }

    InMemorySpreadsheet(Workbook aWorkbook) {

        super();

        myStream = new ByteArrayOutputStream();

        WritableWorkbook tmpWorkbook;
        try {
            tmpWorkbook = Workbook.createWorkbook(myStream, aWorkbook, new WorkbookSettings());
        } catch (IOException anException) {
            tmpWorkbook = null;
        }

        myWorkbook = tmpWorkbook;
    }

    public void activateSheet(String aName) {

        mySheet = myWorkbook.getSheet(aName);
        if (mySheet == null) {
            mySheet = myWorkbook.createSheet(aName, LAST);
        }

        myColumn = FIRST;
        myRow = FIRST;
    }

    public Boolean getBooleanCellValue() {

        Cell tmpCell = this.getCell();
        CellType tmpType = tmpCell.getType();

        if (tmpType == CellType.BOOLEAN) {
            return ((BooleanCell) tmpCell).getValue();
        } else {
            return null;
        }
    }

    public Object getCellValue() {

        Cell tmpCell = this.getCell();
        CellType tmpType = tmpCell.getType();

        if (tmpType == CellType.BOOLEAN) {
            return this.getBooleanCellValue();
        } else if (tmpType == CellType.DATE) {
            return this.getDateCellValue();
        } else if (tmpType == CellType.NUMBER) {
            return this.getNumberCellValue();
        } else if (tmpType == CellType.LABEL) {
            return this.getStringCellValue();
        } else {
            return null;
        }
    }

    public Date getDateCellValue() {

        Cell tmpCell = this.getCell();
        CellType tmpType = tmpCell.getType();

        if (tmpType == CellType.DATE) {
            return ((DateCell) tmpCell).getDate();
        } else {
            return null;
        }
    }

    public BasicMatrix getMatrixSheetValue() {

        this.goHome();
        while (this.getCell() instanceof NumberCell) {
            this.goToNextColumn();
        }
        int tmpColDim = myColumn;

        this.goHome();
        while (this.getCell() instanceof NumberCell) {
            this.goToNextRow();
        }
        int tmpRowDim = myRow;

        double[][] retVal = new double[tmpRowDim][tmpColDim];

        this.goHome();
        for (int i = FIRST; i < tmpRowDim; i++) {
            for (int j = FIRST; j < tmpColDim; j++) {
                retVal[i][j] = this.getNumberCellValue().doubleValue();
                this.goToNextColumn();
            }
            this.goToFirstColumnOnNextRow();
        }

        return PrimitiveMatrix.FACTORY.copy(retVal);
    }

    public Number getNumberCellValue() {

        Cell tmpCell = this.getCell();
        CellType tmpType = tmpCell.getType();

        if (tmpType == CellType.NUMBER) {
            return ((NumberCell) tmpCell).getValue();
        } else {
            return null;
        }
    }

    public String getStringCellValue() {

        Cell tmpCell = this.getCell();
        CellType tmpType = tmpCell.getType();

        if (tmpType == CellType.LABEL) {
            return ((LabelCell) tmpCell).getString();
        } else {
            return null;
        }
    }

    public void goHome() {
        myColumn = FIRST;
        myRow = FIRST;
    }

    public void goTo(int aColumn, int aRow) {
        myColumn = aColumn;
        myRow = aRow;
    }

    public void goToFirstColumnOnNextRow() {
        myColumn = FIRST;
        myRow++;
    }

    public void goToFirstRowInNextColumn() {
        myColumn++;
        myRow = FIRST;
    }

    public void goToNextColumn() {
        myColumn++;
    }

    public void goToNextRow() {
        myRow++;
    }

    public void setBooleanCellValue(Boolean aCellValue) {
        if (aCellValue != null) {
            this.setCell(new jxl.write.Boolean(myColumn, myRow, aCellValue));
        }
    }

    public void setBooleanColumnValues(List<Boolean> someColumnValues) {
        for (Boolean tmpBoolean : someColumnValues) {
            this.setCell(new jxl.write.Boolean(myColumn, myRow, tmpBoolean));
            this.goToNextRow();
        }
    }

    public void setBooleanRowValues(List<Boolean> someRowValues) {
        for (Boolean tmpBoolean : someRowValues) {
            this.setCell(new jxl.write.Boolean(myColumn, myRow, tmpBoolean));
            this.goToNextColumn();
        }
    }

    public void setDateCellValue(Date aCellValue) {
        if (aCellValue != null) {
            this.setCell(new jxl.write.DateTime(myColumn, myRow, aCellValue));
        }
    }

    public void setDateColumnValues(List<Date> someColumnValues) {
        for (Date tmpDate : someColumnValues) {
            this.setCell(new jxl.write.DateTime(myColumn, myRow, tmpDate));
            this.goToNextRow();
        }
    }

    public void setDateRowValues(List<Date> someRowValues) {
        for (Date tmpDate : someRowValues) {
            this.setCell(new jxl.write.DateTime(myColumn, myRow, tmpDate));
            this.goToNextColumn();
        }
    }

    public void setMatrixSheetValue(BasicMatrix aSheetValue) {

        this.goHome();

        int tmpRowDim = aSheetValue.getRowDim();
        int tmpColDim = aSheetValue.getColDim();
        for (int i = FIRST; i < tmpRowDim; i++) {
            for (int j = FIRST; j < tmpColDim; j++) {
                this.setNumberCellValue(aSheetValue.toBigDecimal(i, j));
                this.goToNextColumn();
            }
            this.goToFirstColumnOnNextRow();
        }
    }

    public void setNumberCellValue(Number aCellValue) {
        this.setNumberCellValue(aCellValue, null);
    }

    public void setNumberCellValue(Number aCellValue, String aPattern) {

        if (aCellValue != null) {

            if (aPattern != null) {

                DisplayFormat tmpDisplayFormat = new NumberFormat(aPattern);
                CellFormat tmpCellFormat = new WritableCellFormat(tmpDisplayFormat);

                this.setCell(new jxl.write.Number(myColumn, myRow, aCellValue.doubleValue(), tmpCellFormat));

            } else {

                this.setCell(new jxl.write.Number(myColumn, myRow, aCellValue.doubleValue()));
            }
        }
    }

    public void setNumberColumnValues(List<Number> someColumnValues) {
        for (Number tmpNumber : someColumnValues) {
            this.setCell(new jxl.write.Number(myColumn, myRow, tmpNumber.doubleValue()));
            this.goToNextRow();
        }
    }

    public void setNumberRowValues(List<Number> someRowValues) {
        for (Number tmpNumber : someRowValues) {
            this.setCell(new jxl.write.Number(myColumn, myRow, tmpNumber.doubleValue()));
            this.goToNextColumn();
        }
    }

    public void setStringCellValue(String aCellValue) {
        if (aCellValue != null) {
            this.setCell(new jxl.write.Label(myColumn, myRow, aCellValue));
        }
    }

    public void setStringColumnValues(List<String> someColumnValues) {
        for (String tmpString : someColumnValues) {
            this.setCell(new jxl.write.Label(myColumn, myRow, tmpString));
            this.goToNextRow();
        }
    }

    public void setStringRowValues(List<String> someRowValues) {
        for (String tmpString : someRowValues) {
            this.setCell(new jxl.write.Label(myColumn, myRow, tmpString));
            this.goToNextColumn();
        }
    }

    public void setTableSheetValue(Table aSheetValue) {

        this.goHome();

        List<Column<Object>> tmpColumns = aSheetValue.getColumns();
        for (Column<Object> tmpColumn : tmpColumns) {

            this.setStringCellValue(tmpColumn.getName());
            this.goToNextRow();

            List<Object> tmpData = tmpColumn.getData();
            for (Object tmpCellValue : tmpData) {

                tmpColumn.setCellValue(this, tmpCellValue);
                this.goToNextRow();
            }

            this.goToFirstRowInNextColumn();
        }
    }

    public byte[] toByteArray() {

        try {
            myWorkbook.write();
            myWorkbook.close();
        } catch (IOException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        } catch (WriteException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        }

        return myStream.toByteArray();
    }

    @Override
    public String toString() {

        try {
            myWorkbook.write();
            myWorkbook.close();
        } catch (IOException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        } catch (WriteException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        }

        return myStream.toString();
    }

    public void writeToFile(File aFile) {

        try {

            myWorkbook.write();
            myWorkbook.close();

            FileOutputStream tmpFileStream = new FileOutputStream(aFile);

            myStream.writeTo(tmpFileStream);

            tmpFileStream.close();

        } catch (IOException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        } catch (WriteException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        }
    }

    private Cell getCell() {
        return mySheet.getCell(myColumn, myRow);
    }

    private void setCell(WritableCell aCell) {
        try {
            mySheet.addCell(aCell);
        } catch (RowsExceededException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        } catch (WriteException anException) {
            // TODO Auto-generated catch block
            anException.printStackTrace();
        }
    }
}
