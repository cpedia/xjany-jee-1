/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.ProgrammingError;
import org.ojalgo.constant.BigMath;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.type.TypeUtils;

/**
 * Shifted return Portfolio
 *
 * @author apete
 */
public final class ShiftedPortfolio extends FinancePortfolio {

    private final FinancePortfolio myPortfolio;
    private final BigDecimal myReturnShift;

    public ShiftedPortfolio(final FinancePortfolio aPortfolio) {

        super();

        myPortfolio = aPortfolio;

        BigDecimal tmpMinWeight = BigMath.VERY_POSITIVE;
        for (final BigDecimal tmpWeight : aPortfolio.getWeights()) {
            tmpMinWeight = BigFunction.MIN.invoke(tmpWeight, tmpMinWeight);
        }
        myReturnShift = tmpMinWeight.negate();
    }

    public ShiftedPortfolio(final FinancePortfolio aPortfolio, final Number aReturnShift) {

        super();

        myPortfolio = aPortfolio;
        myReturnShift = TypeUtils.toBigDecimal(aReturnShift, CONTEXT_PARAMETER);
    }

    @SuppressWarnings("unused")
    private ShiftedPortfolio() {

        this(null, null);

        ProgrammingError.throwForIllegalInvocation();
    }

    @Override
    public BigDecimal getMeanReturn() {
        return BigFunction.ADD.invoke(myPortfolio.getMeanReturn(), this.getReturnShift());
    }

    @Override
    public BigDecimal getReturnVariance() {
        return myPortfolio.getReturnVariance();
    }

    @Override
    public BigDecimal getVolatility() {
        return myPortfolio.getVolatility();
    }

    @Override
    public List<BigDecimal> getWeights() {
        return myPortfolio.getWeights();
    }

    private final BigDecimal getReturnShift() {
        return myReturnShift;
    }

    @Override
    protected void reset() {
        myPortfolio.reset();
    }

}
