/* 
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.quadratic;

import org.ojalgo.RecoverableCondition;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.GenericSolver;
import org.ojalgo.optimisation.OptimisationModel;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.State;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.quadratic.QuadraticSolver.Builder;
import org.ojalgo.type.context.NumberContext;

/**
 * QuadraticSolver solves optimisation problems of the form:
 * <p>
 * min 1/2 [X]<sup>T</sup>[Q][X] - [C]<sup>T</sup>[X]<br>
 * when [AE][X] == [BE]<br>
 *  and [AI][X] <= [BI]
 * </p><p>
 * You construct instances by using the {@linkplain Builder} class. It
 * will return an appropriate subclass for you. It's recommended that
 * you first create a {@linkplain QuadraticExpressionsModel} and feed that to the
 * {@linkplain Builder}.
 * </p>
 * 
 * @author apete
 */
public abstract class QuadraticSolver extends GenericSolver {

    public static final class Builder extends GenericSolver.Matrices<Builder> implements OptimisationSolver.Builder<QuadraticSolver> {

        public Builder(final Matrices<?> aMatrices) {
            super(aMatrices);
        }

        public Builder(final MatrixStore<Double> Q, final MatrixStore<Double> C) {

            super();

            this.objective(Q, C);
        }

        public Builder(final QuadraticExpressionsModel aModel) {

            super();

            QuadraticSolver.copy(aModel, this);
        }

        Builder() {
            super();
        }

        Builder(final MatrixStore<Double>[] aMtrxArr) {
            super(aMtrxArr);
        }

        public QuadraticSolver build() {
            if (this.hasInequalityConstraints()) {
                return new ActiveSetSolver(this);
            } else if (this.hasObjective()) {
                return new LagrangeSolver(this);
            } else {
                return new EquationSystemSolver(this);
            }
        }

    }

    static final PhysicalStore.Factory<Double> FACTORY = PrimitiveDenseStore.FACTORY;

    static final String NULL = "null";

    @SuppressWarnings("unchecked")
    static void copy(final ExpressionsBasedModel<?> aSourceModel, final QuadraticSolver.Builder aDestinationBuilder) {

        final Variable[] tmpAllVar = aSourceModel.getVariables();

        final int tmpAllVarDim = tmpAllVar.length;

        // AE & BE

        final Variable[] tmpEqVar = aSourceModel.selectEqualityConstraintVariables();
        final Expression[] tmpEqExpr = aSourceModel.selectEqualityConstraintExpressions();

        final int tmpEqVarDim = tmpEqVar.length;
        final int tmpEqExprDim = tmpEqExpr.length;

        if ((tmpEqExprDim + tmpEqVarDim) > 0) {

            final PhysicalStore<Double> tmpAE = PrimitiveDenseStore.FACTORY.makeZero(tmpEqExprDim + tmpEqVarDim, tmpAllVarDim);
            final PhysicalStore<Double> tmpBE = PrimitiveDenseStore.FACTORY.makeZero(tmpEqExprDim + tmpEqVarDim, 1);

            if (tmpEqExprDim > 0) {
                for (int i = 0; i < tmpEqExprDim; i++) {
                    for (int j = 0; j < tmpAllVarDim; j++) {
                        tmpAE.set(i, j, tmpEqExpr[i].getAdjustedLinearFactor(j).doubleValue());
                    }
                    tmpBE.set(i, 0, tmpEqExpr[i].getAdjustedUpperLimit().doubleValue());
                }
            }

            if (tmpEqVarDim > 0) {
                int i = 0;
                for (int j = 0; j < tmpAllVarDim; j++) {
                    if ((i < tmpEqVarDim) && tmpEqVar[i].equals(tmpAllVar[j])) {
                        tmpAE.set(tmpEqExprDim + i, j, tmpEqVar[i].getAdjustmentFactor().doubleValue());
                        tmpBE.set(tmpEqExprDim + i, 0, tmpEqVar[i].getAdjustedUpperLimit().doubleValue());
                        i++;
                    }
                }
            }

            aDestinationBuilder.equalities(tmpAE, tmpBE);
        }

        // Q & C

        final Expression tmpObjectiveFunc = aSourceModel.getObjectiveExpression();

        PhysicalStore<Double> tmpQ = null;
        if (tmpObjectiveFunc.hasQuadratic()) {
            tmpQ = PrimitiveDenseStore.FACTORY.makeZero(tmpAllVarDim, tmpAllVarDim);
            final boolean tmpMax = aSourceModel.isMaximisation();
            for (int j = 0; j < tmpAllVarDim; j++) {
                for (int i = 0; i < tmpAllVarDim; i++) {
                    if (tmpMax) {
                        tmpQ.set(i, j, tmpObjectiveFunc.getAdjustedQuadraticFactor(i, j).add(tmpObjectiveFunc.getAdjustedQuadraticFactor(j, i)).negate().doubleValue());
                    } else {
                        tmpQ.set(i, j, tmpObjectiveFunc.getAdjustedQuadraticFactor(i, j).add(tmpObjectiveFunc.getAdjustedQuadraticFactor(j, i)).doubleValue());
                    }
                }
            }
        }

        PhysicalStore<Double> tmpC = null;
        if (tmpObjectiveFunc.hasLinear()) {
            tmpC = PrimitiveDenseStore.FACTORY.makeZero(tmpAllVarDim, 1);
            final boolean tmpMin = aSourceModel.isMinimisation();
            for (int i = 0; i < tmpAllVarDim; i++) {
                if (tmpMin) {
                    tmpC.set(i, 0, tmpObjectiveFunc.getAdjustedLinearFactor(i).negate().doubleValue());
                } else {
                    tmpC.set(i, 0, tmpObjectiveFunc.getAdjustedLinearFactor(i).doubleValue());
                }
            }
        }

        aDestinationBuilder.objective(tmpQ, tmpC);

        // AI & BI

        final Variable[] tmpUpVar = aSourceModel.selectUpperConstraintVariables();
        final Expression[] tmpUpExpr = aSourceModel.selectUpperConstraintExpressions();

        final Variable[] tmpLoVar = aSourceModel.selectLowerConstraintVariables();
        final Expression[] tmpLoExpr = aSourceModel.selectLowerConstraintExpressions();

        final int tmpUpVarDim = tmpUpVar.length;
        final int tmpUpExprDim = tmpUpExpr.length;

        final int tmpLoVarDim = tmpLoVar.length;
        final int tmpLoExprDim = tmpLoExpr.length;

        if ((tmpUpExprDim + tmpUpVarDim + tmpLoExprDim + tmpLoVarDim) > 0) {

            final PhysicalStore<Double> tmpUAI = PrimitiveDenseStore.FACTORY.makeZero(tmpUpExprDim + tmpUpVarDim, tmpAllVarDim);
            final PhysicalStore<Double> tmpUBI = PrimitiveDenseStore.FACTORY.makeZero(tmpUpExprDim + tmpUpVarDim, 1);

            if (tmpUpExprDim > 0) {
                for (int i = 0; i < tmpUpExprDim; i++) {
                    for (int j = 0; j < tmpAllVarDim; j++) {
                        tmpUAI.set(i, j, tmpUpExpr[i].getAdjustedLinearFactor(j).doubleValue());
                    }
                    tmpUBI.set(i, 0, tmpUpExpr[i].getAdjustedUpperLimit().doubleValue());
                }
            }

            if (tmpUpVarDim > 0) {
                int i = 0;
                for (int j = 0; j < tmpAllVarDim; j++) {
                    if ((i < tmpUpVarDim) && tmpUpVar[i].equals(tmpAllVar[j])) {
                        tmpUAI.set(tmpUpExprDim + i, j, tmpUpVar[i].getAdjustmentFactor().doubleValue());
                        tmpUBI.set(tmpUpExprDim + i, 0, tmpUpVar[i].getAdjustedUpperLimit().doubleValue());
                        i++;
                    }
                }
            }

            final PhysicalStore<Double> tmpLAI = PrimitiveDenseStore.FACTORY.makeZero(tmpLoExprDim + tmpLoVarDim, tmpAllVarDim);
            final PhysicalStore<Double> tmpLBI = PrimitiveDenseStore.FACTORY.makeZero(tmpLoExprDim + tmpLoVarDim, 1);

            if (tmpLoExprDim > 0) {
                for (int i = 0; i < tmpLoExprDim; i++) {
                    for (int j = 0; j < tmpAllVarDim; j++) {
                        tmpLAI.set(i, j, tmpLoExpr[i].getAdjustedLinearFactor(j).negate().doubleValue());
                    }
                    tmpLBI.set(i, 0, tmpLoExpr[i].getAdjustedLowerLimit().negate().doubleValue());
                }
            }

            if (tmpLoVarDim > 0) {
                int i = 0;
                for (int j = 0; j < tmpAllVarDim; j++) {
                    if ((i < tmpLoVarDim) && tmpLoVar[i].equals(tmpAllVar[j])) {
                        tmpLAI.set(tmpLoExprDim + i, j, tmpLoVar[i].getAdjustmentFactor().negate().doubleValue());
                        tmpLBI.set(tmpLoExprDim + i, 0, tmpLoVar[i].getAdjustedLowerLimit().negate().doubleValue());
                        i++;
                    }
                }
            }

            final MatrixStore<Double> tmpAI = tmpLAI.builder().above(tmpUAI).build();
            final MatrixStore<Double> tmpBI = tmpLBI.builder().above(tmpUBI).build();

            aDestinationBuilder.inequalities(tmpAI, tmpBI);
        }

    }

    private final Matrices<?> myMatrices;

    QuadraticSolver(final QuadraticSolver.Builder aBuilder) {

        super();

        myMatrices = aBuilder;
    }

    public final Result solve() {
        return this.solve(null, null);
    }

    public final Result solve(final MatrixStore<Double> anInitialIterationPoint) {
        return this.solve(anInitialIterationPoint, null);
    }

    public final Result solve(final MatrixStore<Double> anInitialIterationPoint, final NumberContext aPrecision) {

        this.getMatrices().setX(anInitialIterationPoint);
        if (aPrecision != null) {
            options.solutionContext = aPrecision;
        }

        this.initialise();

        this.resetIterationsCount();

        do {
            this.iterate();
        } while (this.getState().isNotLessThan(State.NEW) && this.needsAnotherIteration());

        return new Result(this.getState(), this.getMatrices().getX(), this.getIterationsCount());
    }

    public final Result solve(final NumberContext aPrecision) {
        return this.solve(null, aPrecision);
    }

    public Result solve(final OptimisationModel aValidationModel) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String toString() {
        return myMatrices.toString();
    }

    private State iterate() {

        if (this.getState().isNotLessThan(State.NEW)) {

            try {

                this.incrementIterationsCount();

                this.performIteration();

                //                    final String tmpSolverClass = this.getClass().getSimpleName();
                //
                //                    if (myMatrices.getX() != null) {
                //                        BasicLogger.logDebug(tmpSolverClass + " X: {}", FACTORY.copy(myMatrices.getX()));
                //                    } else {
                //                        BasicLogger.logDebug(tmpSolverClass + " X: {}", "N/A");
                //                    }
                //                    if (myMatrices.getSE() != null) {
                //                        BasicLogger.logDebug(tmpSolverClass + " SE: {}", FACTORY.copy(myMatrices.getSE()));
                //                    }
                //                    if (myMatrices.getSI() != null) {
                //                        BasicLogger.logDebug(tmpSolverClass + " SI: {}", FACTORY.copy(myMatrices.getSI()));
                //                    }
                //                    if (myMatrices.getLI() != null) {
                //                        BasicLogger.logDebug(tmpSolverClass + " LI: {}", FACTORY.copy(myMatrices.getLI()));
                //                    }

                if (this.getState().isLessThan(State.ITERATION)) {
                    this.setState(State.ITERATION);
                }

            } catch (final RecoverableCondition anException) {

                this.setState(State.FAILED);
            }
        }

        return this.getState();
    }

    protected final Matrices<?> getMatrices() {
        return myMatrices;
    }

    abstract protected void initialise();

    abstract protected void performIteration() throws RecoverableCondition;

}
