/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaEigenvalue;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

public abstract class EigenvalueDecomposition<N extends Number> extends AbstractDecomposition<N> implements Eigenvalue<N> {

    /**
     * @return A BigDecimal adapter to PrimitiveEigenvalue.
     */
    public static final Eigenvalue<BigDecimal> makeBig() {
        return new Eigenvalue<BigDecimal>() {

            private final Eigenvalue<Double> myDelegate = EigenvalueDecomposition.makePrimitive();

            public boolean compute(final Access2D<BigDecimal> aStore) {
                return myDelegate.compute(PrimitiveDenseStore.FACTORY.copy(aStore));
            }

            public boolean computeNonsymmetric(final Access2D<BigDecimal> aNonsymmetricStore) {
                return myDelegate.computeNonsymmetric(PrimitiveDenseStore.FACTORY.copy(aNonsymmetricStore));
            }

            public boolean computeSymmetric(final Access2D<BigDecimal> aSymmetricStore) {
                return myDelegate.computeSymmetric(PrimitiveDenseStore.FACTORY.copy(aSymmetricStore));
            }

            public boolean equals(final MatrixDecomposition<BigDecimal> aDecomp, final NumberContext aCntxt) {
                return false;
            }

            public boolean equals(final MatrixStore<BigDecimal> aStore, final NumberContext aCntxt) {
                return MatrixUtils.equals(aStore, this, aCntxt);
            }

            public MatrixStore<BigDecimal> getD() {
                return BigDenseStore.FACTORY.copy(myDelegate.getD());
            }

            public ComplexNumber getDeterminant() {
                return myDelegate.getDeterminant();
            }

            public Array1D<ComplexNumber> getEigenvalues() {
                return myDelegate.getEigenvalues();
            }

            public MatrixStore<BigDecimal> getInverse() {
                return BigDenseStore.FACTORY.copy(myDelegate.getInverse());
            }

            public ComplexNumber getTrace() {
                return myDelegate.getTrace();
            }

            public MatrixStore<BigDecimal> getV() {
                return BigDenseStore.FACTORY.copy(myDelegate.getV());
            }

            public MatrixStore<BigDecimal> invert(final MatrixStore<BigDecimal> aStore) {
                return BigDenseStore.FACTORY.copy(myDelegate.invert(PrimitiveDenseStore.FACTORY.copy(aStore)));
            }

            public boolean isComputed() {
                return myDelegate.isComputed();
            }

            public boolean isFullSize() {
                return myDelegate.isFullSize();
            }

            public boolean isOrdered() {
                return myDelegate.isOrdered();
            }

            public boolean isSolvable() {
                return myDelegate.isSolvable();
            }

            public boolean isSymmetric() {
                return myDelegate.isSymmetric();
            }

            public MatrixStore<BigDecimal> reconstruct() {
                return BigDenseStore.FACTORY.copy(myDelegate.reconstruct());
            }

            public void reset() {
                myDelegate.reset();
            }

            public MatrixStore<BigDecimal> solve(final MatrixStore<BigDecimal> aRHS) {
                return BigDenseStore.FACTORY.copy(myDelegate.solve(PrimitiveDenseStore.FACTORY.copy(aRHS)));
            }

        };
    }

    public static final Eigenvalue<Double> makeJama() {
        return new JamaEigenvalue();
    }

    public static final Eigenvalue<Double> makePrimitive() {
        return new GeneralEvD1.Primitive();
    }

    protected EigenvalueDecomposition(final DecompositionStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public final MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

}
