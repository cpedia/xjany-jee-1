/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.operation;

import java.math.BigDecimal;

import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.scalar.ComplexNumber;

public final class ApplyLU extends StoreOperation {

    public static int TRESHOLD = INT_0128;

    public static void invoke(final BigDecimal[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final BigDecimal[] aMultipliers) {

        BigDecimal tmpVal;
        int tmpIndex;
        for (int j = aFirstCol; j < aColLimit; j++) {
            tmpIndex = aPivotRow + j * aRowDim;
            tmpVal = aData[tmpIndex];
            for (int i = aPivotRow + INT_0001; i < aRowDim; i++) {
                tmpIndex++;
                aData[tmpIndex] = aData[tmpIndex].subtract(BigFunction.MULTIPLY.invoke(aMultipliers[i], tmpVal));
            }
        }
    }

    public static void invoke(final ComplexNumber[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexNumber[] aMultipliers) {

        ComplexNumber tmpVal;
        int tmpIndex;
        for (int j = aFirstCol; j < aColLimit; j++) {
            tmpIndex = aPivotRow + j * aRowDim;
            tmpVal = aData[tmpIndex];
            for (int i = aPivotRow + INT_0001; i < aRowDim; i++) {
                tmpIndex++;
                aData[tmpIndex] = aData[tmpIndex].subtract(aMultipliers[i].multiply(tmpVal));
            }
        }
    }

    public static void invoke(final double[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final double[] aMultipliers) {

        double tmpVal;
        int tmpIndex;
        for (int j = aFirstCol; j < aColLimit; j++) {
            tmpVal = aData[tmpIndex = aPivotRow + j * aRowDim];
            for (int i = aPivotRow + INT_0001; i < aRowDim; i++) {
                aData[++tmpIndex] -= aMultipliers[i] * tmpVal;
            }
        }
    }

    private ApplyLU() {
        super();
    }

}
