/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.polynomial;

import java.util.Map;

import org.ojalgo.array.Array1D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.decomposition.QR;
import org.ojalgo.matrix.decomposition.QRDecomposition;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.PrimitiveScalar;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.series.NumberSeries;

public class PrimitivePolynomial extends AbstractPolynomial<Double> {

    @SuppressWarnings("unused")
    private static final class Evaluator implements AggregatorFunction<Double> {

        private double myPoint;
        private int myParameter;
        private double myValue;

        public Evaluator(final double aPoint) {

            super();

            myPoint = aPoint;

            this.reset();
        }

        public double doubleValue() {
            return myValue;
        }

        public Double getNumber() {
            return myValue;
        }

        public int intValue() {
            return this.getNumber().intValue();
        }

        public void invoke(final double anArg) {
            myValue += PrimitiveFunction.MULTIPLY.invoke(anArg, PrimitiveFunction.POWER.invoke(myPoint, myParameter));
            myParameter++;
        }

        public void invoke(final Double anArg) {
            this.invoke(anArg.doubleValue());
        }

        public void merge(final Double anArg) {

        }

        public Double merge(final Double aResult1, final Double aResult2) {
            // TODO Auto-generated method stub
            return null;
        }

        public Evaluator reset() {
            myValue = PrimitiveMath.ZERO;
            myParameter = 0;
            return this;
        }

        public void setArgument(final double somePoint) {
            myPoint = somePoint;
        }

        public void setParameter(final int aParameter) {
            myParameter = aParameter;
        }

        public Scalar<Double> toScalar() {
            return new PrimitiveScalar(myValue);
        }

    }

    public static PolynomialFunction<Double> estimate(final NumberSeries<? extends Number> aSeries) {
        return PrimitivePolynomial.estimate(aSeries, aSeries.size());
    }

    /**
     * @see BigPolynomial#estimate(NumberSeries, int)
     */
    public static PolynomialFunction<Double> estimate(final NumberSeries<? extends Number> aSeries, final int aSize) {

        final PhysicalStore<Double> tmpBody = PrimitiveDenseStore.FACTORY.makeEmpty(aSeries.size(), aSize);
        final PhysicalStore<Double> tmpRHS = PrimitiveDenseStore.FACTORY.makeEmpty(aSeries.size(), 1);

        int i = 0;
        double tmpKey;
        for (final Map.Entry<? extends Number, ? extends Number> tmpEntry : aSeries.entrySet()) {
            tmpKey = tmpEntry.getKey().doubleValue();
            for (int j = 0; j < aSize; j++) {
                tmpBody.set(i, j, PrimitiveFunction.POWER.invoke(tmpKey, j));
            }
            tmpRHS.set(i, 0, tmpEntry.getValue().doubleValue());
            i++;
        }

        final QR<Double> tmpQR = QRDecomposition.makePrimitive();
        tmpQR.compute(tmpBody);

        final MatrixStore<Double> tmpSol = tmpQR.solve(tmpRHS);

        final double[] retVal = new double[tmpSol.getRowDim()];

        for (i = 0; i < retVal.length; i++) {
            retVal[i] = tmpSol.doubleValue(i, 0);
        }

        return new PrimitivePolynomial(retVal);
    }

    public PrimitivePolynomial(final Array1D<Double> someCoefficients) {
        super(someCoefficients);
    }

    public PrimitivePolynomial(final double[] someCoefficients) {
        super(Array1D.makePrimitive(someCoefficients));
    }

    public Double integrate(final Double aFromPoint, final Double aToPoint) {

        final PolynomialFunction<Double> tmpPrim = this.buildPrimitive();

        final double tmpFromVal = tmpPrim.invoke(aFromPoint.doubleValue());
        final double tmpToVal = tmpPrim.invoke(aToPoint.doubleValue());

        return tmpToVal - tmpFromVal;
    }

    public double invoke(final double anArg) {

        double retVal = this.getConstant();

        final int tmpSize = this.size();

        for (int i = 1; i < tmpSize; i++) {
            retVal += this.doubleValue(i) * PrimitiveFunction.POWER.invoke(anArg, i);
        }

        return retVal;
    }

    public Double invoke(final Double anArg) {
        return this.invoke(anArg.doubleValue());
    }

    @Override
    protected Double getDerivativeFactor(final int anIndex) {
        final int tmpNextIndex = anIndex + 1;
        return tmpNextIndex * this.doubleValue(tmpNextIndex);
    }

    @Override
    protected Double getPrimitiveFactor(final int anIndex) {
        if (anIndex <= 0) {
            return PrimitiveMath.ZERO;
        } else {
            return this.doubleValue(anIndex - 1) / anIndex;
        }
    }

    @Override
    protected Double getStaticZero() {
        return PrimitiveMath.ZERO;
    }

    @Override
    protected AbstractPolynomial<Double> makeInstance(final int aSize) {
        return new PrimitivePolynomial(Array1D.makePrimitive(aSize));
    }

}
