/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Map.Entry;

import org.ojalgo.array.Array1D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.random.Normal;
import org.ojalgo.random.RandomNumber;
import org.ojalgo.random.RandomUtils;
import org.ojalgo.random.SampleSet;
import org.ojalgo.random.process.GeometricBrownianMotion;
import org.ojalgo.series.BasicTimeSeries;
import org.ojalgo.series.CalendarSeries;
import org.ojalgo.series.CoordinationSet;
import org.ojalgo.series.DateSeries;
import org.ojalgo.series.TimeInMillisSeries;
import org.ojalgo.type.CalendarDateUnit;

public abstract class FinanceUtils {

    public static double calculateValueAtRisk(final double aReturn, final double aStdDev, final double aConfidence, final double aTime) {

        final double tmpConfidenceScale = SQRT_TWO * RandomUtils.erfi(ONE - (TWO * (ONE - aConfidence)));

        return Math.max(Math.sqrt(aTime) * aStdDev * tmpConfidenceScale - aTime * aReturn, ZERO);
    }

    public static <K extends Comparable<K>, V extends Number> GeometricBrownianMotion estimateExcessDiffusionProcess(final BasicTimeSeries<K, V> aPriceSeries, final BasicTimeSeries<K, V> aRiskFreeInterestRateSeries, final CalendarDateUnit aTimeUnit) {

        final SampleSet tmpSampleSet = FinanceUtils.makeExcessSampleSet(aPriceSeries, aRiskFreeInterestRateSeries);

        // The average number of millis between to subsequent keys in the series.
        double tmpStepSize = aPriceSeries.getResolution().size();
        // The time between to keys expressed in terms of the specified time meassure and unit.
        tmpStepSize /= aTimeUnit.size();

        final double tmpExp = tmpSampleSet.getMean();
        final double tmpVar = tmpSampleSet.getVariance();

        final double tmpDiff = Math.sqrt(tmpVar / tmpStepSize);
        final double tmpDrift = (tmpExp / tmpStepSize) + ((tmpDiff * tmpDiff) / TWO);

        return new GeometricBrownianMotion(tmpDrift, tmpDiff);
    }

    public static TimeInMillisSeries<RandomNumber> forecast(final TimeInMillisSeries<? extends Number> aSeries, final int aPointCount, final CalendarDateUnit aTimeUnit, final boolean includeOriginalSeries) {

        final TimeInMillisSeries<RandomNumber> retVal = new TimeInMillisSeries<RandomNumber>();
        retVal.name(aSeries.getName()).colour(aSeries.getColour());
        final double tmpSamplePeriod = (double) aSeries.getAverageStepSize() / (double) aTimeUnit.size();

        final GeometricBrownianMotion tmpProcess = GeometricBrownianMotion.estimate(aSeries.getDataSeries(), tmpSamplePeriod);

        if (includeOriginalSeries) {
            for (final Entry<Long, ? extends Number> tmpEntry : aSeries.entrySet()) {
                retVal.put(tmpEntry.getKey(), new Normal(tmpEntry.getValue().doubleValue(), PrimitiveMath.ZERO));
            }
        }

        final long tmpLastKey = aSeries.lastKey();
        final double tmpLastValue = aSeries.lastValue().doubleValue();

        long tmpForecastTime;
        double tmpMean;
        double tmpStdDev;

        tmpProcess.setValue(tmpLastValue);

        // Make forecasts
        for (int i = 1; i <= aPointCount; i++) {

            tmpForecastTime = i * aTimeUnit.size();

            tmpMean = tmpProcess.getExpected(i);
            tmpStdDev = tmpProcess.getStandardDeviation(i);

            retVal.put(tmpLastKey + tmpForecastTime, new Normal(tmpMean, tmpStdDev));
        }

        return retVal;
    }

    public static CalendarSeries<BigDecimal> makeCalendarPriceSeries(final double[] somePrices, final Calendar aStartCalendar, final CalendarDateUnit aResolution) {

        final CalendarSeries<BigDecimal> retVal = new CalendarSeries<BigDecimal>(aResolution);

        FinanceUtils.copyValues(retVal, aStartCalendar, somePrices);

        return retVal;
    }

    /**
     * @param aTimeSeriesCollection
     * @return Annualised covariances
     */
    public static <K extends Comparable<K>, V extends Number> BasicMatrix makeCovarianceMatrix(final Collection<BasicTimeSeries<K, V>> aTimeSeriesCollection) {

        final CoordinationSet<K, V> tmpCoordinator = new CoordinationSet<K, V>(aTimeSeriesCollection).prune();

        final ArrayList<SampleSet> tmpSampleSets = new ArrayList<SampleSet>();
        for (final BasicTimeSeries<K, V> tmpTimeSeries : aTimeSeriesCollection) {
            final double[] someValues = tmpCoordinator.get(tmpTimeSeries).getPrimitiveValues();
            final int tmpSize1 = someValues.length - 1;

            final double[] retVal = new double[tmpSize1];

            for (int i = 0; i < tmpSize1; i++) {
                retVal[i] = Math.log(someValues[i + 1] / someValues[i]);
            }
            final SampleSet tmpMakeUsingLogarithmicChanges = SampleSet.wrap(ArrayUtils.wrapAccess1D(retVal));
            tmpSampleSets.add(tmpMakeUsingLogarithmicChanges);
        }

        final int tmpSize = aTimeSeriesCollection.size();

        final PhysicalStore<Double> retValStore = PrimitiveDenseStore.FACTORY.makeEmpty(tmpSize, tmpSize);

        final double tmpToYearFactor = (double) CalendarDateUnit.YEAR.size() / (double) tmpCoordinator.getResolution().size();

        SampleSet tmpRowSet;
        SampleSet tmpColSet;

        for (int j = 0; j < tmpSize; j++) {

            tmpColSet = tmpSampleSets.get(j);

            for (int i = 0; i < tmpSize; i++) {

                tmpRowSet = tmpSampleSets.get(i);

                retValStore.set(i, j, tmpToYearFactor * tmpRowSet.getCovariance(tmpColSet));
            }
        }

        return new PrimitiveMatrix(retValStore);
    }

    public static DateSeries<BigDecimal> makeDatePriceSeries(final double[] somePrices, final Date aStartDate, final CalendarDateUnit aResolution) {

        final DateSeries<BigDecimal> retVal = new DateSeries<BigDecimal>(aStartDate, aResolution);

        FinanceUtils.copyValues(retVal, aStartDate, somePrices);

        return retVal;
    }

    /**
     * @param <K> Time series key type
     * @param <V> Time series value type
     * @param aPriceSeries A series of prices
     * @param aRiskFreeInterestRateSeries A series of interest rates (risk free return expressed in %)
     * @return A sample set of price growth factors adjusted for risk free return
     */
    public static <K extends Comparable<K>, V extends Number> SampleSet makeExcessSampleSet(final BasicTimeSeries<K, V> aPriceSeries, final BasicTimeSeries<K, V> aRiskFreeInterestRateSeries) {

        if (aPriceSeries.size() != aRiskFreeInterestRateSeries.size()) {
            throw new IllegalArgumentException("The two series must have the same size (number of elements).");
        }

        if (!aPriceSeries.firstKey().equals(aRiskFreeInterestRateSeries.firstKey())) {
            throw new IllegalArgumentException("The two series must have the same first key (date or calendar).");
        }

        if (!aPriceSeries.lastKey().equals(aRiskFreeInterestRateSeries.lastKey())) {
            throw new IllegalArgumentException("The two series must have the same last key (date or calendar).");
        }

        final double[] tmpPrices = aPriceSeries.getPrimitiveValues();
        final double[] tmpRates = aRiskFreeInterestRateSeries.getPrimitiveValues();

        final Array1D<Double> retVal = Array1D.makePrimitive(tmpPrices.length - 1);

        final CalendarDateUnit tmpUnit = aPriceSeries.getResolution();
        double tmpThisRate, tmpNextRate, tmpAvgRate, tmpRateGrowth, tmpThisPrice, tmpNextPrice, tmpPriceGrowth, tmpAdjustedPriceGrowth;

        for (int i = 0; i < retVal.size(); i++) {

            tmpThisRate = tmpRates[i] / PrimitiveMath.HUNDRED;
            tmpNextRate = tmpRates[i + 1] / PrimitiveMath.HUNDRED;
            tmpAvgRate = (tmpThisRate + tmpNextRate) / PrimitiveMath.TWO;
            tmpRateGrowth = FinanceUtils.toGrowthRateFromInterestRate(tmpAvgRate, tmpUnit);

            tmpThisPrice = tmpPrices[i];
            tmpNextPrice = tmpPrices[i + 1];
            tmpPriceGrowth = Math.log(tmpNextPrice / tmpThisPrice);
            tmpAdjustedPriceGrowth = tmpPriceGrowth - tmpRateGrowth;

            retVal.set(i, tmpAdjustedPriceGrowth);
        }

        return SampleSet.wrap(retVal);
    }

    /**
     * GrowthFactor = exp(GrowthRate)
     *
     * @param anInterestRate Annualised interest rate (percentage per year)
     * @param aGrowthFactorUnit A growth factor unit
     * @return A growth factor per unit (day, week, month, year...)
     */
    public static double toGrowthFactorFromInterestRate(final double anInterestRate, final CalendarDateUnit aGrowthFactorUnit) {
        return PrimitiveFunction.EXP.invoke(FinanceUtils.toGrowthRateFromInterestRate(anInterestRate, aGrowthFactorUnit));
    }

    /**
     * @deprecated v30 Use {@linkplain #toGrowthRateFromInterestRate(double, CalendarDateUnit)} instead
     */
    @Deprecated
    public static double toGrowthRate(final double anInterestRate, final CalendarDateUnit aUnit) {
        return FinanceUtils.toGrowthRateFromInterestRate(anInterestRate, aUnit);
    }

    /**
     * GrowthRate = ln(1.0 + InterestRate) / GrowthRateUnitsPerYear
     *
     * @param anInterestRate Annualised interest rate (percentage per year)
     * @param aGrowthRateUnit A growth rate unit
     * @return A growth rate per unit (day, week, month, year...)
     */
    public static double toGrowthRateFromInterestRate(final double anInterestRate, final CalendarDateUnit aGrowthRateUnit) {
        final double tmpUnitsPerYear = (double) CalendarDateUnit.YEAR.size() / (double) aGrowthRateUnit.size();
        return PrimitiveFunction.LOG1P.invoke(anInterestRate) / tmpUnitsPerYear;
    }

    /**
     * @deprecated v30 Use {@linkplain #toInterestRateFromGrowthRate(double, CalendarDateUnit)} instead
     */
    @Deprecated
    public static double toInterestRate(final double aGrowthRate, final CalendarDateUnit aUnit) {
        return FinanceUtils.toInterestRateFromGrowthRate(aGrowthRate, aUnit);
    }

    /**
     * GrowthRate = ln(GrowthFactor)
     * 
     * @param aGrowthFactor A growth factor per unit (day, week, month, year...)
     * @param aGrowthFactorUnit A growth factor unit
     * @return Annualised interest rate (percentage per year)
     */
    public static double toInterestRateFromGrowthFactor(final double aGrowthFactor, final CalendarDateUnit aGrowthFactorUnit) {
        return FinanceUtils.toInterestRateFromGrowthRate(PrimitiveFunction.LOG.invoke(aGrowthFactor), aGrowthFactorUnit);
    }

    /**
     * InterestRate = exp(GroiwthRate * GrowthRateUnitsPerYear) + 1.0
     * 
     * @param aGrowthRate A growth rate per unit (day, week, month, year...)
     * @param aGrowthRateUnit A growth rate unit
     * @return Annualised interest rate (percentage per year)
     */
    public static double toInterestRateFromGrowthRate(final double aGrowthRate, final CalendarDateUnit aGrowthRateUnit) {
        final double tmpUnitsPerYear = (double) CalendarDateUnit.YEAR.size() / (double) aGrowthRateUnit.size();
        return PrimitiveFunction.EXPM1.invoke(aGrowthRate * tmpUnitsPerYear);
    }

    private static <K extends Comparable<K>> void copyValues(final BasicTimeSeries<K, BigDecimal> aSeries, final K aFirstKey, final double[] someValues) {

        K tmpKey = aFirstKey;

        for (int tmpValueIndex = 0; tmpValueIndex < someValues.length; tmpValueIndex++) {

            aSeries.put(tmpKey, new BigDecimal(someValues[tmpValueIndex]));

            tmpKey = aSeries.step(tmpKey);
        }
    }

    private FinanceUtils() {
        super();
    }

}
