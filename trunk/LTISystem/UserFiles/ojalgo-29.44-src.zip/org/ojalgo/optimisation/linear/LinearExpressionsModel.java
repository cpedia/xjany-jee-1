/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.linear;

import static org.ojalgo.constant.BigMath.*;

import java.util.Arrays;
import java.util.Collection;

import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.ModelValidationException;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.integer.IntegerSolver;
import org.ojalgo.optimisation.linear.mps.MathProgSysModel;
import org.ojalgo.optimisation.quadratic.QuadraticExpressionsModel;

/**
 * <ul>
 * <li>
 * No quadratic expressions whatsoever.
 * </li>
 * <li>
 * Variables cannot have lower limits smaller than 0:
 * <ul>
 * <li>
 * Unset lower limit on variables are assumed to be 0.
 * </li>
 * <li>
 * Setting the lower limit on a variable to something smaller than 0 will cause an exception.
 * </li>
 * </ul>
 * 
 * @author apete
 */
public final class LinearExpressionsModel extends ExpressionsBasedModel<LinearExpressionsModel> {

    public static final LinearExpressionsModel convert(final QuadraticExpressionsModel aQuadraticModel) {
        return new LinearExpressionsModel(aQuadraticModel);
    }

    public static LinearExpressionsModel makeInstance(final MathProgSysModel aModel) {

        final MathProgSysModel.Column[] tmpActCols = aModel.getActivatorVariableColumns();
        final MathProgSysModel.Column[] tmpNegCols = aModel.getNegativeVariableColumns();
        final MathProgSysModel.Column[] tmpPosCols = aModel.getPositiveVariableColumns();
        final MathProgSysModel.Row[] tmpAllRows = aModel.getExpressionRows();

        Arrays.sort(tmpActCols);
        Arrays.sort(tmpNegCols);
        Arrays.sort(tmpPosCols);
        Arrays.sort(tmpAllRows);

        final int tmpCountActCols = tmpActCols.length;
        final int tmpCountNegCols = tmpNegCols.length;
        final int tmpCountPosCols = tmpPosCols.length;
        final int tmpCountAllRows = tmpAllRows.length;

        // Define various local variables
        MathProgSysModel.Row tmpRow;
        MathProgSysModel.Column tmpCol;
        Variable tmpVar;
        Expression tmpExpr;
        int tmpIndex;

        // Create the LinearModel variables
        final Variable[] tmpVariables = new Variable[tmpCountActCols + tmpCountNegCols + tmpCountPosCols];
        for (int i = 0; i < tmpCountActCols; i++) {
            tmpCol = tmpActCols[i];
            tmpVar = new Variable(tmpCol.getNameForActivator());
            tmpVar.lower(ZERO).upper(ONE).integer(true);
            tmpVariables[i] = tmpVar;
        }
        for (int i = 0; i < tmpCountNegCols; i++) {
            tmpCol = tmpNegCols[i];
            tmpVar = new Variable(tmpCol.getNameForNegativePart());
            tmpVar.lower(tmpCol.isUpperLimitSet() ? tmpCol.getUpperLimit().negate().max(ZERO) : ZERO).upper(tmpCol.isLowerLimitSet() ? tmpCol.getLowerLimit().negate() : null).integer(tmpCol.isInteger());
            tmpVariables[tmpCountActCols + i] = tmpVar;
        }
        for (int i = 0; i < tmpCountPosCols; i++) {
            tmpCol = tmpPosCols[i];
            tmpVar = new Variable(tmpCol.getNameForPositivePart());
            tmpVar.lower(tmpCol.isLowerLimitSet() ? tmpCol.getLowerLimit().max(ZERO) : ZERO).upper(tmpCol.getUpperLimit()).integer(tmpCol.isInteger());
            tmpVariables[tmpCountActCols + tmpCountNegCols + i] = tmpVar;
        }

        // Instantiate the LinearModel
        final LinearExpressionsModel retVal = new LinearExpressionsModel(tmpVariables);

        final Expression[] tmpExpressions = new Expression[tmpCountAllRows];
        final String[] tmpExpressionNames = new String[tmpCountAllRows];

        for (int i = 0; i < tmpCountAllRows; i++) {
            tmpRow = tmpAllRows[i];
            tmpExpr = retVal.addEmptyLinearExpression(tmpRow.getName());
            tmpExpr.setLowerLimit(tmpRow.getLowerLimit());
            tmpExpr.setUpperLimit(tmpRow.getUpperLimit());
            tmpExpr.setContributionWeight(tmpRow.getContributionWeight());
            tmpExpressions[i] = tmpExpr;
            tmpExpressionNames[i] = tmpExpr.getName();
        }

        for (int i = 0; i < tmpCountActCols; i++) {
            tmpCol = tmpActCols[i];
            tmpVar = tmpVariables[i];
            for (final String tmpRowKey : tmpCol.getElementKeys()) {
                tmpIndex = Arrays.binarySearch(tmpExpressionNames, tmpRowKey);
                if (tmpIndex != -1) {
                    //tmpExpressions[tmpRowIndex].setLinearFactor(i, tmpCol.getRowValue(tmpRowKey));
                }
            }
        }
        for (int i = 0; i < tmpCountNegCols; i++) {
            tmpCol = tmpNegCols[i];
            tmpVar = tmpVariables[tmpCountActCols + i];
            for (final String tmpRowKey : tmpCol.getElementKeys()) {
                tmpIndex = Arrays.binarySearch(tmpExpressionNames, tmpRowKey);
                if (tmpIndex != -1) {
                    tmpExpressions[tmpIndex].setLinearFactor(tmpCountActCols + i, tmpCol.getRowValue(tmpRowKey).negate());
                }
            }
        }
        for (int i = 0; i < tmpCountPosCols; i++) {
            tmpCol = tmpPosCols[i];
            tmpVar = tmpVariables[tmpCountActCols + tmpCountNegCols + i];
            for (final String tmpRowKey : tmpCol.getElementKeys()) {
                tmpIndex = Arrays.binarySearch(tmpExpressionNames, tmpRowKey);
                if (tmpIndex != -1) {
                    tmpExpressions[tmpIndex].setLinearFactor(tmpCountActCols + tmpCountNegCols + i, tmpCol.getRowValue(tmpRowKey));
                }
            }
        }

        return retVal;
    }

    public LinearExpressionsModel(final Collection<? extends Variable> someVariables) {

        super(someVariables);

        this.assertLowerVariableLimits();
    }

    public LinearExpressionsModel(final Variable[] someVariables) {

        super(someVariables);

        this.assertLowerVariableLimits();
    }

    LinearExpressionsModel(final ExpressionsBasedModel<?> aModel) {

        super(aModel);

        this.assertLowerVariableLimits();
    }

    @Override
    public final LinearExpressionsModel copy() {
        return new LinearExpressionsModel(this);
    }

    @Override
    public OptimisationSolver getDefaultSolver() {
        if (this.isAnyVariableInteger()) {
            return new IntegerSolver.Builder(this).build();
        } else {
            return new LinearSolver.Builder(this).build();
        }
    }

    @Override
    public boolean validateComposition() throws ModelValidationException {

        for (final Expression tmpExpression : this.getExpressions()) {
            if (tmpExpression.hasQuadratic()) {
                throw new ModelValidationException(tmpExpression.toString() + " A linear model may not contain any quadratic expressions!");
            }
        }

        return super.validateComposition();
    }

}
