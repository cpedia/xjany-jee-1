/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.random.process;

import java.util.List;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.function.aggregator.Aggregator;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.random.Distribution;
import org.ojalgo.random.MultidimensionalGaussian;

public final class MultidimensionalProcess implements RandomProcess<Distribution> {

    private final MultidimensionalGaussian myGenerator;
    private final AbstractProcess<?>[] myProcesses;

    public MultidimensionalProcess(final List<? extends AbstractProcess<?>> someProcs, final Access2D<Double> aCorrelationsMatrix) {

        super();

        myProcesses = someProcs.toArray(new AbstractProcess[someProcs.size()]);
        myGenerator = new MultidimensionalGaussian(aCorrelationsMatrix);
    }

    public Distribution getDistribution(final double aStepSize) {
        throw new UnsupportedOperationException();
    }

    public double getExpected(final int index, final double aStepSize) {
        return myProcesses[index].getExpected(aStepSize);
    }

    public RandomProcess<?> getProcess(final int index) {
        return myProcesses[index];
    }

    public double getStandardDeviation(final int index, final double aStepSize) {
        return myProcesses[index].getStandardDeviation(aStepSize);
    }

    public double getValue(final int index) {
        return myProcesses[index].getValue();
    }

    public double getVariance(final int index, final double aStepSize) {
        return myProcesses[index].getVariance(aStepSize);
    }

    public void setValue(final int index, final double newValue) {
        myProcesses[index].setValue(newValue);
    }

    public double step(final double aStepSize) {

        final AggregatorFunction<Double> tmpAggr = Aggregator.NORM2.getPrimitiveFunction();

        final Array1D<Double> tmpSteps = this.stepAll(aStepSize);

        tmpSteps.visitAll(tmpAggr);

        return tmpAggr.doubleValue();
    }

    public Array1D<Double> stepAll(final double aStepSize) {

        final Array1D<Double> retVal = myGenerator.generate();

        for (int p = 0; p < myProcesses.length; p++) {
            retVal.set(p, myProcesses[p].step(aStepSize, retVal.doubleValue(p)));
        }

        return retVal;
    }

}
