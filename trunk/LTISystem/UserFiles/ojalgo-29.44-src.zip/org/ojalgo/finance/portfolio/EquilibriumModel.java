/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.BasicMatrix.Factory;
import org.ojalgo.matrix.PrimitiveMatrix;

abstract class EquilibriumModel extends FinancePortfolio {

    protected static final Factory FACTORY = PrimitiveMatrix.FACTORY;

    private transient BasicMatrix myAssetReturns;
    private transient BasicMatrix myAssetWeights;
    private final MarketEquilibrium myMarketEquilibrium;
    private transient BigDecimal myMeanReturn;
    private transient BigDecimal myReturnVariance;

    protected EquilibriumModel(final MarketEquilibrium aMarketEquilibrium) {

        super();

        myMarketEquilibrium = aMarketEquilibrium.copy();
    }

    EquilibriumModel(final EquilibriumModel aMarketEquilibrium) {
        this(aMarketEquilibrium.getMarketEquilibrium());
    }

    public final BasicMatrix getAssetReturns() {
        if (myAssetReturns == null) {
            myAssetReturns = this.calculateAssetReturns().round(CONTEXT_WEIGHT);
        }
        return myAssetReturns;
    }

    public final BasicMatrix getAssetWeights() {
        if (myAssetWeights == null) {
            final BasicMatrix tmpCalculateInstrumentWeights = this.calculateAssetWeights();
            if (tmpCalculateInstrumentWeights != null) {
                myAssetWeights = tmpCalculateInstrumentWeights.round(CONTEXT_WEIGHT);
            }
        }
        return myAssetWeights;
    }

    public final BasicMatrix getCovariances() {
        return myMarketEquilibrium.getCovariances();
    }

    public final BigDecimal getImpliedRiskAversion(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {
        return myMarketEquilibrium.getImpliedRiskAversion(aWeightsVctr, aReturnsVctr);
    }

    @Override
    public final BigDecimal getMeanReturn() {
        if (myMeanReturn == null) {
            final BasicMatrix tmpInstrumentWeights = this.getAssetWeights();
            final BasicMatrix tmpInstrumentReturns = this.getAssetReturns();
            if ((tmpInstrumentWeights != null) && (tmpInstrumentReturns != null)) {
                myMeanReturn = this.calculatePortfolioReturn(tmpInstrumentWeights, tmpInstrumentReturns);
            }
        }
        return myMeanReturn;
    }

    @Override
    public final BigDecimal getReturnVariance() {
        if (myReturnVariance == null) {
            myReturnVariance = this.calculatePortfolioVariance(this.getAssetWeights());
        }
        return myReturnVariance;
    }

    public final BigDecimal getRiskAversion() {
        return myMarketEquilibrium.getRiskAversion();
    }

    public final String[] getSymbols() {
        return myMarketEquilibrium.getSymbols();
    }

    @Override
    public final List<BigDecimal> getWeights() {

        final BasicMatrix tmpAssetWeights = this.getAssetWeights();

        if (tmpAssetWeights != null) {

            return tmpAssetWeights.toBigStore().asList();

        } else {

            return null;
        }
    }

    public final void setRiskAversion(final BigDecimal aFactor) {

        myMarketEquilibrium.setRiskAversion(aFactor);

        this.reset();
    }

    protected final BasicMatrix buildColumnVector(final List<BigDecimal> aColumn) {
        return FACTORY.makeColumnVector(aColumn);
    }

    protected abstract BasicMatrix calculateAssetReturns();

    protected abstract BasicMatrix calculateAssetWeights();

    protected final BasicMatrix calculateEquilibriumReturns(final BasicMatrix aWeightsVctr) {
        return myMarketEquilibrium.calculateAssetReturns(aWeightsVctr);
    }

    protected final BasicMatrix calculateEquilibriumWeights(final BasicMatrix aReturnsVctr) {
        return myMarketEquilibrium.calculateAssetWeights(aReturnsVctr);
    }

    protected final BigDecimal calculatePortfolioReturn(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {
        return MarketEquilibrium.calculatePortfolioReturn(aWeightsVctr, aReturnsVctr);
    }

    protected final BigDecimal calculatePortfolioVariance(final BasicMatrix aWeightsVctr) {
        return myMarketEquilibrium.calculatePortfolioVariance(aWeightsVctr);
    }

    protected final void calibrate(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {

        myMarketEquilibrium.calibrate(aWeightsVctr, aReturnsVctr);

        this.reset();
    }

    @Override
    protected void reset() {
        myAssetWeights = null;
        myAssetReturns = null;
        myMeanReturn = null;
        myReturnVariance = null;
    }

    final MarketEquilibrium getMarketEquilibrium() {
        return myMarketEquilibrium;
    }

}
