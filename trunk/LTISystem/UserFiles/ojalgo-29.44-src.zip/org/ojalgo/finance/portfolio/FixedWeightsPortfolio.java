/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.ProgrammingError;
import org.ojalgo.matrix.BasicMatrix;

public final class FixedWeightsPortfolio extends EquilibriumModel {

    private final BasicMatrix myWeights;

    public FixedWeightsPortfolio(final EquilibriumModel aCovarianceBasedModel, final BasicMatrix aPortfolio) {

        super(aCovarianceBasedModel);

        myWeights = aPortfolio;
    }

    public FixedWeightsPortfolio(final MarketEquilibrium aMarketEquilibrium, final BasicMatrix aPortfolio) {

        super(aMarketEquilibrium);

        myWeights = aPortfolio;
    }

    @SuppressWarnings("unused")
    private FixedWeightsPortfolio(final EquilibriumModel aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myWeights = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private FixedWeightsPortfolio(final MarketEquilibrium aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myWeights = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    public void calibrate(final BasicMatrix aReturnsVctr) {
        this.calibrate(myWeights, aReturnsVctr);
    }

    public void calibrate(final EquilibriumModel aPortfolio) {
        this.calibrate(aPortfolio.calculateAssetReturns());
    }

    public void calibrate(final List<BigDecimal> aReturnsList) {
        this.calibrate(this.buildColumnVector(aReturnsList));
    }

    @Override
    protected BasicMatrix calculateAssetReturns() {
        return this.calculateEquilibriumReturns(myWeights);
    }

    @Override
    protected BasicMatrix calculateAssetWeights() {
        return myWeights;
    }

}
