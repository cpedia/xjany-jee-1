/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.random.process;

import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.random.Distribution;
import org.ojalgo.random.SampleSet;

abstract class AbstractProcess<D extends Distribution> implements RandomProcess<D> {

    static final class Simulator {

        private final double myInitialState;
        private final AbstractProcess<?> myProcess;

        @SuppressWarnings("unused")
        private Simulator() {
            this(null);
        }

        Simulator(final AbstractProcess<?> aProcess) {

            super();

            myProcess = aProcess;
            myInitialState = aProcess.getValue();
        }

        SampleSet[] simulate(final int aNumberOfRealisations, final int aNumberOfSteps, final double aStepSize) {

            final SampleSet[] retVal = new SampleSet[aNumberOfSteps];

            final Array2D<Double> tmpRealisationValues = Array2D.makePrimitive(aNumberOfRealisations, aNumberOfSteps);

            for (int r = 0; r < aNumberOfRealisations; r++) {
                for (int s = 0; s < aNumberOfSteps; s++) {
                    tmpRealisationValues.set(r, s, myProcess.step(aStepSize));
                }
                myProcess.setValue(myInitialState);
            }

            for (int s = 0; s < aNumberOfSteps; s++) {
                retVal[s] = SampleSet.wrap(tmpRealisationValues.sliceColumn(0, s));
            }

            return retVal;
        }
    }

    private double myValue;

    @SuppressWarnings("unused")
    private AbstractProcess() {
        this(PrimitiveMath.NaN);
    }

    protected AbstractProcess(final double initialValue) {

        super();

        myValue = initialValue;
    }

    public abstract double getExpected(double aStepSize);

    public abstract double getStandardDeviation(double aStepSize);

    public final double getValue() {
        return myValue;
    }

    public abstract double getVariance(double aStepSize);

    public final void setValue(final double newValue) {
        myValue = newValue;
    }

    /**
     * @return An array of sample sets. The array has aNumberOfSteps
     * elements, and each sample set has aNumberOfRealisations samples.
     */
    public final SampleSet[] simulate(final int aNumberOfRealisations, final int aNumberOfSteps, final double aStepSize) {

        final Simulator tmpSimulator = new Simulator(this);

        return tmpSimulator.simulate(aNumberOfRealisations, aNumberOfSteps, aStepSize);
    }

    public final double step(final double aStepSize) {
        return this.step(aStepSize, this.getNormalisedRandomIncrement());
    }

    protected abstract double getNormalisedRandomIncrement();

    protected abstract double step(final double aStepSize, final double aNormalisedRandomIncrement);

}
