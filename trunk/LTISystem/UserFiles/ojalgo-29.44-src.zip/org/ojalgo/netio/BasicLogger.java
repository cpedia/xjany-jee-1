/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.netio;

import java.io.PrintStream;

import org.ojalgo.RecoverableCondition;
import org.ojalgo.access.Access2D;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.type.TypeUtils;

/**
 * An extremely simple/basic logging system that uses
 * {@linkplain System#out} and {@linkplain System#err}.
 * 
 * @author apete
 */
public class BasicLogger {

    public static PrintStream DEBUG = System.out;
    public static PrintStream ERROR = System.err;

    public static void logDebug() {
        DEBUG.println();
    }

    public static void logDebug(final String aMessage) {
        DEBUG.println(aMessage);
    }

    public static void logDebug(final String aMessage, final Access2D<?> aStore) {
        DEBUG.print(aMessage);
        MatrixUtils.printToStream(DEBUG, aStore, TypeUtils.EQUALS_NUMBER_CONTEXT);
    }

    public static void logDebug(final String aMessage, final BasicMatrix aMtrx) {
        DEBUG.print(aMessage);
        MatrixUtils.printToStream(DEBUG, aMtrx, TypeUtils.EQUALS_NUMBER_CONTEXT);
    }

    public static void logDebug(final String aMessagePattern, final Object... someArgs) {
        BasicLogger.logDebug(TypeUtils.format(aMessagePattern, someArgs));
    }

    public static void logDebugStackTrace(final String aMessage) {
        try {
            throw new RecoverableCondition(aMessage);
        } catch (final RecoverableCondition anException) {
            anException.printStackTrace(DEBUG);
        }
    }

    public static void logError() {
        ERROR.println();
    }

    public static void logError(final String aMessage) {
        ERROR.println(aMessage);
    }

    public static void logError(final String aMessagePattern, final Object... someArgs) {
        BasicLogger.logError(TypeUtils.format(aMessagePattern, someArgs));
    }

}
