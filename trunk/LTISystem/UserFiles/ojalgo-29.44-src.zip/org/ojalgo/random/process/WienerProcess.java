/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.random.process;

import static org.ojalgo.constant.PrimitiveMath.*;

import org.ojalgo.random.Normal;

public final class WienerProcess extends AbstractProcess<Normal> {

    private static final Normal GENERATOR = new Normal();

    public WienerProcess() {
        super(ZERO);
    }

    @SuppressWarnings("unused")
    private WienerProcess(final double initialValue) {
        super(initialValue);
    }

    public Normal getDistribution(final double aStepSize) {
        return new Normal(this.getValue(), Math.sqrt(aStepSize));
    }

    @Override
    public double getExpected(final double aStepSize) {
        return this.getValue();
    }

    @Override
    public double getStandardDeviation(final double aStepSize) {
        return Math.sqrt(aStepSize);
    }

    @Override
    public double getVariance(final double aStepSize) {
        return aStepSize;
    }

    @Override
    protected double getNormalisedRandomIncrement() {
        return GENERATOR.doubleValue();
    }

    @Override
    protected double step(final double aStepSize, final double aNormalisedRandomIncrement) {

        final double tmpIncrement = Math.sqrt(aStepSize) * aNormalisedRandomIncrement;
        final double retVal = this.getValue() + tmpIncrement;

        this.setValue(retVal);

        return retVal;
    }

}
