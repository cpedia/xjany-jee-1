/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.concurrent;

import org.ojalgo.OjAlgoUtils;

public abstract class ConcurrentStrategy {

    /**
     * The default strategy. Will check if the "count" is larger than
     * the "treshold" and if there are processors/threads available.
     *
     * @author apete
     */
    public static final ConcurrentStrategy BASIC = new ConcurrentStrategy() {

    };

    /**
     * Will use the basic strategy to determine if it should start
     * branching. If it does start it will go all the way down to put
     * one thread on each processor core. Note that multiple threads on
     * each core are disregarded (only one thread per core is used).
     *
     * @author apete
     */
    public static final ConcurrentStrategy DEEP = new ConcurrentStrategy() {

        @Override
        public boolean shouldBranch(final int aCount, final int aTreshold, final ProcessorCount availableCPUs) {
            if (availableCPUs.modified) {
                return (aCount > 1) && (availableCPUs.count > OjAlgoUtils.HARDWARE.threads);
            } else {
                return super.shouldBranch(aCount, aTreshold, availableCPUs);
            }
        }
    };

    /**
     * Will use the basic strategy to determine if it should branch,
     * but it will never branch more than once.
     *
     * @author apete
     */
    public static final ConcurrentStrategy ONCE = new ConcurrentStrategy() {

        @Override
        public boolean shouldBranch(final int aCount, final int aTreshold, final ProcessorCount availableCPUs) {
            if (availableCPUs.modified) {
                return false;
            } else {
                return super.shouldBranch(aCount, aTreshold, availableCPUs);
            }
        }
    };

    public ConcurrentStrategy() {
        super();
    }

    public boolean shouldBranch(final int aCount, final int aTreshold, final ProcessorCount availableCPUs) {
        return (aCount > aTreshold) && (availableCPUs.count > 1);
    }

}
