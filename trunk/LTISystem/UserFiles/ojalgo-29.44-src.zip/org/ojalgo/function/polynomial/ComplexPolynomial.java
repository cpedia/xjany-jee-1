/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.polynomial;

import java.util.List;

import org.ojalgo.array.Array1D;
import org.ojalgo.function.implementation.ComplexFunction;
import org.ojalgo.scalar.ComplexNumber;

public class ComplexPolynomial extends AbstractPolynomial<ComplexNumber> {

    public ComplexPolynomial(final Array1D<ComplexNumber> someCoefficients) {
        super(someCoefficients);
    }

    public ComplexPolynomial(final ComplexNumber[] someCoefficients) {
        super(Array1D.makeComplex(someCoefficients));
    }

    public ComplexPolynomial(final List<ComplexNumber> someCoefficients) {
        super(Array1D.makeComplex(someCoefficients.toArray(new ComplexNumber[someCoefficients.size()])));
    }

    public ComplexNumber integrate(final ComplexNumber aFromPoint, final ComplexNumber aToPoint) {

        final PolynomialFunction<ComplexNumber> tmpPrim = this.buildPrimitive();

        final ComplexNumber tmpFromVal = tmpPrim.invoke(aFromPoint);
        final ComplexNumber tmpToVal = tmpPrim.invoke(aToPoint);

        return tmpToVal.subtract(tmpFromVal);
    }

    public ComplexNumber invoke(final ComplexNumber anArg) {

        ComplexNumber retVal = this.getConstant();

        final int tmpSize = this.size();

        for (int i = 1; i < tmpSize; i++) {
            retVal = retVal.add(this.getNumber(i).multiply(ComplexFunction.POWER.invoke(anArg, i)));
        }

        return retVal;
    }

    public double invoke(final double anArg) {
        return this.invoke(new ComplexNumber(anArg)).doubleValue();
    }

    @Override
    protected ComplexNumber getDerivativeFactor(final int anIndex) {
        final int tmpNextIndex = anIndex + 1;
        return this.getNumber(tmpNextIndex).multiply(tmpNextIndex);
    }

    @Override
    protected ComplexNumber getPrimitiveFactor(final int anIndex) {
        if (anIndex <= 0) {
            return ComplexNumber.ZERO;
        } else {
            return this.getNumber(anIndex - 1).divide(anIndex);
        }
    }

    @Override
    protected ComplexNumber getStaticZero() {
        return ComplexNumber.ZERO;
    }

    @Override
    protected AbstractPolynomial<ComplexNumber> makeInstance(final int aSize) {
        return new ComplexPolynomial(Array1D.makeComplex(aSize));
    }

}
