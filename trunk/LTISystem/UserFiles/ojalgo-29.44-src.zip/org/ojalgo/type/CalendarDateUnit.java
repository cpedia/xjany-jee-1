/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.type;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

public enum CalendarDateUnit {

    /**
     * 
     */
    MILLIS(TimeUnit.MILLISECONDS),
    /**
     * 
     */
    SECOND(TimeUnit.SECONDS),
    /**
     * 
     */
    MINUTE(TypeUtils.MILLIS_PER_HOUR / 60L),
    /**
     * 
     */
    HOUR(TypeUtils.MILLIS_PER_HOUR),
    /**
     * 
     */
    DAY(24L * TypeUtils.MILLIS_PER_HOUR),
    /**
     * 
     */
    WEEK(7L * 24L * TypeUtils.MILLIS_PER_HOUR),
    /**
     * 
     */
    MONTH((TypeUtils.HOURS_PER_YEAR * TypeUtils.MILLIS_PER_HOUR) / 12L),
    /**
     * 
     */
    QUARTER((TypeUtils.HOURS_PER_YEAR * TypeUtils.MILLIS_PER_HOUR) / 4L),
    /**
     * 
     */
    YEAR(TypeUtils.HOURS_PER_YEAR * TypeUtils.MILLIS_PER_HOUR),
    /**
     * 
     */
    DECADE(10L * TypeUtils.HOURS_PER_YEAR * TypeUtils.MILLIS_PER_HOUR),
    /**
     * 
     */
    CENTURY(100L * TypeUtils.HOURS_PER_YEAR * TypeUtils.MILLIS_PER_HOUR),
    /**
     * 
     */
    MILLENIUM(1000L * TypeUtils.HOURS_PER_YEAR * TypeUtils.MILLIS_PER_HOUR);

    private final TimeUnit myTimeUnit;
    private final long mySize;
    private final long myHalf;

    CalendarDateUnit(final long aMillis) {
        myTimeUnit = null;
        mySize = aMillis;
        myHalf = mySize / 2L;
    }

    CalendarDateUnit(final TimeUnit aTimeUnit) {
        myTimeUnit = aTimeUnit;
        mySize = myTimeUnit.toMillis(1L);
        myHalf = mySize / 2L;
    }

    public long convert(final long aSourceDuration, final CalendarDateUnit aSourceUnit) {
        if ((myTimeUnit != null) && (aSourceUnit.getTimeUnit() != null)) {
            return myTimeUnit.convert(aSourceDuration, aSourceUnit.getTimeUnit());
        } else {
            return (aSourceDuration * aSourceUnit.size()) / mySize;
        }
    }

    public long count(final Calendar aToCalendar) {
        return aToCalendar.getTimeInMillis() / mySize;
    }

    public long count(final Calendar aFromCalendar, final Calendar aToCalendar) {
        return (aToCalendar.getTimeInMillis() - aFromCalendar.getTimeInMillis()) / mySize;
    }

    public long count(final Date aToDate) {
        return aToDate.getTime() / mySize;
    }

    public long count(final Date aFromDate, final Date aToDate) {
        return (aToDate.getTime() - aFromDate.getTime()) / mySize;
    }

    /**
     * Note that this method may, and actually does, return null in many cases.
     */
    public final TimeUnit getTimeUnit() {
        return myTimeUnit;
    }

    public Calendar round(final Calendar aCalendar) {
        final long tmpVal = (aCalendar.getTimeInMillis() + myHalf) / mySize;
        aCalendar.setTimeInMillis(mySize * tmpVal);
        return aCalendar;
    }

    public Date round(final Date aDate) {
        final long tmpVal = (aDate.getTime() + myHalf) / mySize;
        aDate.setTime(mySize * tmpVal);
        return aDate;
    }

    public long size() {
        return mySize;
    }

    public void strip(final Calendar aCalendar) {
        if (mySize >= SECOND.size()) {
            aCalendar.set(Calendar.MILLISECOND, 0);
            if (mySize >= MINUTE.size()) {
                aCalendar.set(Calendar.SECOND, 0);
                if (mySize >= HOUR.size()) {
                    aCalendar.set(Calendar.MINUTE, 0);
                    if (mySize >= DAY.size()) {
                        aCalendar.set(Calendar.HOUR, 0);
                    }
                }
            }
        }
    }

    public long toCenturies(final long aDuration) {
        return (aDuration * mySize) / CENTURY.size();
    }

    public long toDays(final long aDuration) {
        return (aDuration * mySize) / DAY.size();
    }

    public long toDecades(final long aDuration) {
        return (aDuration * mySize) / DECADE.size();
    }

    public long toHours(final long aDuration) {
        return (aDuration * mySize) / HOUR.size();
    }

    public long toMicros(final long aDuration) {
        return myTimeUnit.toMicros(aDuration);
    }

    public long toMilleniums(final long aDuration) {
        return (aDuration * mySize) / MILLENIUM.size();
    }

    public long toMillis(final long aDuration) {
        return myTimeUnit.toMillis(aDuration);
    }

    public long toMinutes(final long aDuration) {
        return (aDuration * mySize) / MINUTE.size();
    }

    public long toMonths(final long aDuration) {
        return (aDuration * mySize) / MONTH.size();
    }

    public long toNanos(final long aDuration) {
        return myTimeUnit.toNanos(aDuration);
    }

    public long toQuarters(final long aDuration) {
        return (aDuration * mySize) / QUARTER.size();
    }

    public long toSeconds(final long aDuration) {
        return myTimeUnit.toSeconds(aDuration);
    }

    public final long toTimeInMillis(final Calendar aCalendar) {

        final Calendar retVal = new GregorianCalendar();
        retVal.setTimeInMillis(aCalendar.getTimeInMillis());

        if (CalendarDateUnit.SECOND.size() < mySize) {

            retVal.set(Calendar.SECOND, 0);

            if (CalendarDateUnit.MINUTE.size() < mySize) {

                retVal.set(Calendar.MINUTE, 0);

                if (CalendarDateUnit.HOUR.size() < mySize) {

                    retVal.set(Calendar.HOUR_OF_DAY, 12);

                    if (CalendarDateUnit.DAY.size() < mySize) {

                        if (CalendarDateUnit.WEEK.size() == mySize) {

                            retVal.set(Calendar.DAY_OF_WEEK, aCalendar.getFirstDayOfWeek());
                            retVal.add(Calendar.WEEK_OF_YEAR, 1);
                            retVal.add(Calendar.DAY_OF_WEEK, -1);

                        } else if (CalendarDateUnit.MONTH.size() == mySize) {

                            retVal.set(Calendar.DAY_OF_MONTH, 1);
                            retVal.add(Calendar.MONTH, 1);
                            retVal.add(Calendar.DAY_OF_MONTH, -1);

                        } else if (CalendarDateUnit.YEAR.size() == mySize) {

                            retVal.set(Calendar.DAY_OF_YEAR, 1);
                            retVal.add(Calendar.YEAR, 1);
                            retVal.add(Calendar.DAY_OF_YEAR, -1);
                        }
                    }
                }
            }
        }

        retVal.set(Calendar.MILLISECOND, 0);

        //        if (CalendarDateUnit.MONTH.size() == mySize) {
        //            BasicLogger.logDebug("Converting {} to {}", aCalendar.getTime(), retVal.getTime());
        //        }

        return retVal.getTimeInMillis();
    }

    public final long toTimeInMillis(final Date aDate) {
        return this.toTimeInMillis(0L, aDate);
    }

    public final long toTimeInMillis(final Date aReference, final Date aDate) {
        return this.toTimeInMillis(aReference.getTime(), aDate);
    }

    public final long toTimeInMillisOld(final Calendar aCalendar) {

        final Calendar retVal = new GregorianCalendar(aCalendar.get(Calendar.YEAR), 0, 1, 0, 0, 0);

        if (CalendarDateUnit.MONTH.size() >= mySize) {
            retVal.set(Calendar.MONTH, aCalendar.get(Calendar.MONTH));
            if (CalendarDateUnit.WEEK.size() >= mySize) {
                retVal.set(Calendar.WEEK_OF_YEAR, aCalendar.get(Calendar.WEEK_OF_YEAR));
                if (CalendarDateUnit.DAY.size() >= mySize) {
                    retVal.set(Calendar.DAY_OF_MONTH, aCalendar.get(Calendar.DAY_OF_MONTH));
                    if (CalendarDateUnit.HOUR.size() >= mySize) {
                        retVal.set(Calendar.HOUR_OF_DAY, aCalendar.get(Calendar.HOUR_OF_DAY));
                        if (CalendarDateUnit.MINUTE.size() >= mySize) {
                            retVal.set(Calendar.MINUTE, aCalendar.get(Calendar.MINUTE));
                            if (CalendarDateUnit.SECOND.size() >= mySize) {
                                retVal.set(Calendar.SECOND, aCalendar.get(Calendar.SECOND));
                            }
                        }
                    }
                } else {
                    retVal.add(Calendar.WEEK_OF_YEAR, 1);
                    retVal.add(Calendar.DAY_OF_WEEK, -1);
                }
            } else {
                retVal.add(Calendar.MONTH, 1);
                retVal.add(Calendar.DAY_OF_MONTH, -1);
            }
        } else {
            retVal.add(Calendar.YEAR, 1);
            retVal.add(Calendar.DAY_OF_YEAR, -1);
        }

        return retVal.getTimeInMillis();
    }

    public long toWeeks(final long aDuration) {
        return (aDuration * mySize) / WEEK.size();
    }

    public long toYears(final long aDuration) {
        return (aDuration * mySize) / YEAR.size();
    }

    private final long toTimeInMillis(final long aReference, final Date aDate) {
        return (((aDate.getTime() - aReference) / mySize) * mySize) + aReference;
    }

}
