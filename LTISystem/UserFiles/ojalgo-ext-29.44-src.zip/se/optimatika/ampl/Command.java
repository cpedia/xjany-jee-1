/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.ampl;

import org.ojalgo.netio.ASCII;
import org.ojalgo.netio.Message;

public enum Command {

    MINIMIZE, MAXIMIZE, CLOSE, DATA, DELETE, DISPLAY, DROP, END, EXPAND, FIX, INCLUDE, LET, MODEL, OBJECTIVE, OPTION, PRINT, PRINTF, QUIT, READ, RESET, RESET_DATA, RESTORE, SHELL, SHOW, SOLUTION, SOLVE, SUBJECT_TO, UNFIX, UPDATE, UPDATE_DATA, VAR, WRITE, XREF;

    public Message toMessage() {
        return new Message(this.toString());
    }

    public Message toMessage(String anArg) {
        return new Message(this.toString(), anArg);
    }

    @Override
    public String toString() {
        return super.toString().toLowerCase().replace(ASCII.UNDERSCORE, ASCII.SP);
    }

}
