/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import static org.ojalgo.constant.PrimitiveMath.*;

import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.random.RandomUtils;
import org.ojalgo.type.TypeUtils;

public abstract class KeyFigures {

    public static double getSharpeRatio(final FinancePortfolio aPortfolio, final Number aRiskFreeReturn) {
        if (aRiskFreeReturn != null) {
            return BigFunction.DIVIDE.invoke(aPortfolio.getMeanReturn().subtract(TypeUtils.toBigDecimal(aRiskFreeReturn)), aPortfolio.getVolatility()).doubleValue();
        } else {
            return BigFunction.DIVIDE.invoke(aPortfolio.getMeanReturn(), aPortfolio.getVolatility()).doubleValue();
        }
    }

    /**
     * Value at Risk (VaR) is the maximum loss not exceeded with a 
     * given probability defined as the confidence level, over a given 
     * period of time.
     */
    public static double getValueAtRisk(final FinancePortfolio aPortfolio, final double aConfidenceLevel, final double aTimePeriod) {

        final double aReturn = aPortfolio.getMeanReturn().doubleValue();
        final double aStdDev = aPortfolio.getVolatility().doubleValue();

        final double tmpConfidenceScale = SQRT_TWO * RandomUtils.erfi(ONE - (TWO * (ONE - aConfidenceLevel)));

        return Math.max(Math.sqrt(aTimePeriod) * aStdDev * tmpConfidenceScale - aTimePeriod * aReturn, ZERO);
    }

    private KeyFigures() {
        super();
    }

}
