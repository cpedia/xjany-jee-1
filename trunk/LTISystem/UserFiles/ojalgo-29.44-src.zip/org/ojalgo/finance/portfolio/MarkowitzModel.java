/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.ojalgo.ProgrammingError;
import org.ojalgo.constant.BigMath;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.State;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.OptimisationSolver.Result;
import org.ojalgo.optimisation.quadratic.QuadraticExpressionsModel;

/**
 * <p>
 * The Markowitz model, in this class, is defined as:
 * </p><p>
 * min (RAF/2) [w]<sup>T</sup>[C][w] - [w]<sup>T</sup>[r]
 * <br>
 * subject to |[w]| = 1
 * </p><p>
 * RAF stands for Risk Aversion Factor. Instead of specifying a desired
 * risk or return level you specify a level of risk aversion that is
 * used to balance the risk and return.
 * </p><p>
 * The expected returns for each of the instruments/assets must be
 * excess returns. Otherwise this formulation is wrong.
 * </p><p>
 * The total weights of all instruments will always be 100%, but
 * shorting can be allowed or not according to your preference. (
 * {@linkplain #setShortingAllowed(boolean)}
 * ) In addition you may set lower and upper limits on any individual
 * instrument. (
 * {@linkplain #setLowerLimit(int, BigDecimal)}
 * and
 * {@linkplain #setUpperLimit(int, BigDecimal)}
 * )
 * </p><p>
 * Risk-free asset: That means there is no excess return and zero
 * variance. Don't (try to) include a risk-free asset here.
 * </p><p>
 * Do not worry about the minus sign in front of the return part of
 * the objective function - it is handled/negated for you. When you're
 * asked to supply the expected excess returns you should supply
 * precisely that.
 * </p>
 * 
 * @author apete
 */
public final class MarkowitzModel extends EquilibriumModel {

    private static final class LowerUpper {

        final BigDecimal lower;
        final BigDecimal upper;

        LowerUpper(final BigDecimal someLower, final BigDecimal someUpper) {

            super();

            lower = someLower;
            upper = someUpper;
        }
    }

    private final HashMap<int[], LowerUpper> myConstraints = new HashMap<int[], LowerUpper>();

    private static final double _0_000005 = 0.000005;
    private static final String BALANCE = "Balance";
    private static final String RETURN = "Return";
    private static final String VARIANCE = "Variance";

    private final BasicMatrix myExpectedExcessReturns;
    private transient QuadraticExpressionsModel myOptimisationModel;
    private transient State myOptimisationState = State.NEW;
    private boolean myShortingAllowed = false;
    private BigDecimal myTargetReturn;

    private BigDecimal myTargetVariance;

    private final Variable[] myVariables;

    public MarkowitzModel(final EquilibriumModel aCovarianceBasedModel, final BasicMatrix anExpectedExcessReturns) {
        this(aCovarianceBasedModel.getMarketEquilibrium(), anExpectedExcessReturns);
    }

    public MarkowitzModel(final MarketEquilibrium aMarketEquilibrium, final BasicMatrix anExpectedExcessReturns) {

        super(aMarketEquilibrium);

        myExpectedExcessReturns = anExpectedExcessReturns;

        final String[] tmpSymbols = this.getMarketEquilibrium().getSymbols();
        myVariables = new Variable[tmpSymbols.length];
        for (int i = 0; i < tmpSymbols.length; i++) {
            myVariables[i] = new Variable(tmpSymbols[i]);
            myVariables[i].setContributionWeight(myExpectedExcessReturns.toBigDecimal(i, 0).negate());
        }
    }

    @SuppressWarnings("unused")
    private MarkowitzModel(final EquilibriumModel aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myExpectedExcessReturns = null;
        myVariables = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private MarkowitzModel(final MarketEquilibrium aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myExpectedExcessReturns = null;
        myVariables = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    public LowerUpper addConstraint(final BigDecimal aLower, final BigDecimal anUpper, final int... someInstrumentIndeces) {
        return myConstraints.put(someInstrumentIndeces, new LowerUpper(aLower, anUpper));
    }

    public final void clearAllConstraints() {
        myConstraints.clear();
        this.reset();
    }

    public final State getOptimisationState() {
        if (myOptimisationState == null) {
            myOptimisationState = State.NEW;
        }
        return myOptimisationState;
    }

    public final void setLowerLimit(final int anInstrumentIndex, final BigDecimal aLimit) {
        myVariables[anInstrumentIndex].setLowerLimit(aLimit);
        this.reset();
    }

    public final void setShortingAllowed(final boolean aFlag) {
        myShortingAllowed = aFlag;
        this.reset();
    }

    /**
     * <p>
     * Will set the target return to whatever you input and the
     * target variance to <code>null</code>.
     * </p><p>
     * Setting the target return implies that you disregard the risk
     * aversion factor and want the minimum risk portfolio with return
     * that is equal to or greater than the target.
     * </p><p>
     * By setting the target return too high it is possible to define
     * an infeasible optimisation problem. It is in fact (in
     * combination with setting lower and upper bounds on the
     * instrument weights) very easy to do so without realising it.
     * </p><p>
     * Setting a target return is not recommnded. It's much better to
     * modify the risk aversion factor.
     * </p>
     * @see #setTargetVariance(BigDecimal)
     */
    public final void setTargetReturn(final BigDecimal aTargetReturn) {
        myTargetReturn = aTargetReturn;
        myTargetVariance = null;
        this.reset();
    }

    /**
     * <p>
     * Will set the target variance to whatever you input and the
     * target return to <code>null</code>.
     * </p><p>
     * Setting the target variance implies that you disregard the risk
     * aversion factor and want the maximum return portfolio with risk
     * that is equal to or as close to the target as possible.
     * </p><p>
     * A target variance isn't an infeasibility risk the way a return
     * target is. The algorithm will return a solution, but there is no
     * guaranty the portfolio variance is equal to or less than the
     * target (as one may expect).
     * </p><p>
     * There is a performance penalty for setting a target variance as
     * the underlying optimisation model has to be solved several
     * (many) times with different pararmeters (different risk aversion
     * factors).
     * </p><p>
     * Setting a target variance is not recommnded. It's much better to
     * modify the risk aversion factor.
     * </p>
     * @see #setTargetReturn(BigDecimal)
     */
    public final void setTargetVariance(final BigDecimal aTargetVariance) {
        myTargetVariance = aTargetVariance;
        myTargetReturn = null;
        this.reset();
    }

    public final void setUpperLimit(final int anInstrumentIndex, final BigDecimal aLimit) {
        myVariables[anInstrumentIndex].setUpperLimit(aLimit);
        this.reset();
    }

    @Override
    public String toString() {

        if (myOptimisationModel == null) {
            this.calculateAssetWeights();
        }

        return myOptimisationModel.toString();
    }

    private QuadraticExpressionsModel generateOptimisationModel(final BigDecimal aRiskAversion, final BigDecimal aLowerReturnLimit, final BigDecimal anUpperReturnLimit) {

        final Variable[] tmpVariables = new Variable[myVariables.length];
        for (int i = 0; i < tmpVariables.length; i++) {
            tmpVariables[i] = myVariables[i].copy();
            if (!myShortingAllowed && ((myVariables[i].getLowerLimit() == null) || (myVariables[i].getLowerLimit().signum() == -1))) {
                tmpVariables[i].setLowerLimit(BigMath.ZERO);
            }
        }

        final QuadraticExpressionsModel retVal = new QuadraticExpressionsModel(tmpVariables);

        final Expression tmpVarExpr = retVal.addQuadraticExpression(VARIANCE, this.getCovariances().toBigStore());
        tmpVarExpr.setContributionWeight(aRiskAversion.multiply(BigMath.HALF));

        final Expression tmpBalExpr = retVal.addSimpleWeightExpression(BALANCE);
        tmpBalExpr.setLowerLimit(BigMath.ONE);
        tmpBalExpr.setUpperLimit(BigMath.ONE);

        if ((aLowerReturnLimit != null) || (anUpperReturnLimit != null)) {
            final Expression tmpRetExpr = retVal.addWeightExpression(RETURN, myExpectedExcessReturns.toBigStore().asList());
            tmpRetExpr.setLowerLimit(aLowerReturnLimit);
            tmpRetExpr.setUpperLimit(anUpperReturnLimit);
        }

        for (final Map.Entry<int[], LowerUpper> tmpConstraintSet : myConstraints.entrySet()) {
            retVal.addWeightGroupExpression(tmpConstraintSet.getKey().toString(), tmpConstraintSet.getKey()).lower(tmpConstraintSet.getValue().lower).upper(tmpConstraintSet.getValue().upper);
        }

        return retVal;
    }

    private Result optimise() {

        Result retVal;

        if (myTargetReturn != null) {

            myOptimisationModel = this.generateOptimisationModel(this.getRiskAversion().multiply(BigMath.THOUSAND), myTargetReturn, null);
            retVal = myOptimisationModel.getDefaultSolver().solve();

        } else if (myTargetVariance != null) {

            BigDecimal tmpRiskAversion = this.getRiskAversion();
            BigDecimal tmpReturn = null;
            BigDecimal tmpVariance = null;

            BigDecimal tmpLowRiskAversion = null;
            BigDecimal tmpLowReturn = null;
            BigDecimal tmpLowVariance = null;

            BigDecimal tmpHighRiskAversion = null;
            BigDecimal tmpHighReturn = null;
            BigDecimal tmpHighVariance = null;

            BigDecimal tmpTargetDiff = null;

            myOptimisationModel = this.generateOptimisationModel(tmpRiskAversion, tmpLowReturn, tmpHighReturn);
            retVal = myOptimisationModel.getDefaultSolver().solve();

            tmpReturn = this.calculatePortfolioReturn(retVal.getSolution(), myExpectedExcessReturns);
            tmpVariance = this.calculatePortfolioVariance(retVal.getSolution());
            tmpTargetDiff = tmpVariance.subtract(myTargetVariance);

            if (tmpTargetDiff.signum() > 0) {

                tmpHighRiskAversion = tmpRiskAversion;
                tmpHighReturn = tmpReturn;

                tmpRiskAversion = tmpRiskAversion.multiply(BigMath.TEN);

                myOptimisationModel = this.generateOptimisationModel(tmpRiskAversion, tmpLowReturn, tmpHighReturn);
                retVal = myOptimisationModel.getDefaultSolver().solve();

                tmpReturn = this.calculatePortfolioReturn(retVal.getSolution(), myExpectedExcessReturns);
                tmpVariance = this.calculatePortfolioVariance(retVal.getSolution());
                tmpTargetDiff = tmpVariance.subtract(myTargetVariance);

                tmpLowRiskAversion = tmpRiskAversion;
                tmpLowReturn = tmpReturn;

            } else {

                tmpLowRiskAversion = tmpRiskAversion;
                tmpLowReturn = tmpReturn;

                tmpRiskAversion = tmpRiskAversion.multiply(BigMath.TENTH);

                myOptimisationModel = this.generateOptimisationModel(tmpRiskAversion, tmpLowReturn, tmpHighReturn);
                retVal = myOptimisationModel.getDefaultSolver().solve();

                tmpReturn = this.calculatePortfolioReturn(retVal.getSolution(), myExpectedExcessReturns);
                tmpVariance = this.calculatePortfolioVariance(retVal.getSolution());
                tmpTargetDiff = tmpVariance.subtract(myTargetVariance);

                tmpHighRiskAversion = tmpRiskAversion;
                tmpHighReturn = tmpReturn;
            }

            int tmpIterCount = 0;

            do {

                tmpRiskAversion = tmpHighRiskAversion.add(tmpLowRiskAversion).multiply(BigMath.HALF);

                myOptimisationModel = this.generateOptimisationModel(tmpRiskAversion, tmpLowReturn, tmpHighReturn);
                retVal = myOptimisationModel.getDefaultSolver().solve();

                final BasicMatrix tmpSolution = retVal.getSolution();

                if (tmpSolution != null) {

                    tmpReturn = this.calculatePortfolioReturn(tmpSolution, myExpectedExcessReturns);
                    tmpVariance = this.calculatePortfolioVariance(tmpSolution);
                    tmpTargetDiff = tmpVariance.subtract(myTargetVariance);

                    if (tmpTargetDiff.signum() < 0) {
                        tmpLowRiskAversion = tmpRiskAversion;
                        tmpLowReturn = tmpReturn;
                        tmpLowVariance = tmpVariance;
                    } else if (tmpTargetDiff.signum() > 0) {
                        tmpHighRiskAversion = tmpRiskAversion;
                        tmpHighReturn = tmpReturn;
                        tmpHighVariance = tmpVariance;
                    }

                    tmpIterCount++;

                    //                        BasicLogger.logDebug();
                    //                        BasicLogger.logDebug("Iter:   {}", tmpIterCount);
                    //                        BasicLogger.logDebug("Low:    {}", tmpLowVariance);
                    //                        BasicLogger.logDebug("Target: {}", myTargetVariance);
                    //                        BasicLogger.logDebug("High:   {}", tmpHighVariance);
                    //                        BasicLogger.logDebug("Diff:   {}", tmpTargetDiff);

                } else {

                    tmpIterCount = 20;
                    tmpTargetDiff = BigMath.ZERO;
                }

            } while ((tmpIterCount < 20) && (Math.abs(tmpTargetDiff.doubleValue()) > _0_000005));

        } else {

            myOptimisationModel = this.generateOptimisationModel(this.getRiskAversion(), null, null);
            retVal = myOptimisationModel.getDefaultSolver().solve();
        }

        //  BasicLogger.logDebug("Result: {}", retVal);

        return retVal;
    }

    @Override
    protected BasicMatrix calculateAssetReturns() {
        return myExpectedExcessReturns;
    }

    /**
     * Constrained optimisation.
     */
    @Override
    protected BasicMatrix calculateAssetWeights() {

        final Result tmpResult = this.optimise();

        myOptimisationState = tmpResult.getState();

        return tmpResult.getSolution();
    }

    @Override
    protected void reset() {

        super.reset();

        myOptimisationModel = null;
        myOptimisationState = State.NEW;
    }
}
