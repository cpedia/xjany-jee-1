/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.quadratic;

import java.util.Collection;

import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.ModelValidationException;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.integer.IntegerSolver;

/**
 * At least one, objective function, expression must be quadratic.
 * 
 * @author apete
 */
public final class QuadraticExpressionsModel extends ExpressionsBasedModel<QuadraticExpressionsModel> {

    public QuadraticExpressionsModel(final Collection<Variable> someVariables) {
        super(someVariables);
    }

    public QuadraticExpressionsModel(final Variable[] someVariables) {
        super(someVariables);
    }

    QuadraticExpressionsModel(final ExpressionsBasedModel<?> aModel) {
        super(aModel);
    }

    @Override
    public final QuadraticExpressionsModel copy() {
        return new QuadraticExpressionsModel(this);
    }

    @Override
    public OptimisationSolver getDefaultSolver() {
        if (this.isAnyVariableInteger()) {
            return new IntegerSolver.Builder(this).build();
        } else {
            return new QuadraticSolver.Builder(this).build();
        }
    }

    @Override
    public boolean validateComposition() throws ModelValidationException {

        for (final Expression tmpExpression : this.getExpressions()) {
            if (tmpExpression.isConstraint() && tmpExpression.hasQuadratic()) {
                throw new ModelValidationException("Cannot handle quadratic constraints!");
            }
        }

        return super.validateComposition();
    }

}
