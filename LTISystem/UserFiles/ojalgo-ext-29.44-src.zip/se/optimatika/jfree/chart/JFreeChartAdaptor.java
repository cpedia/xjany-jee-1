/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jfree.chart;

import java.awt.Font;
import java.awt.Paint;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.ojalgo.ProgrammingError;
import org.ojalgo.chart.BasicChart;

public final class JFreeChartAdaptor implements BasicChart<JFreeChart> {

    private static final String IMAGE_PNG = "image/png";

    private final JFreeChart myDelegate;

    private int myHeight;
    private int myWidth;

    public JFreeChartAdaptor(JFreeChart aDelegate) {

        super();

        myDelegate = aDelegate;
    }

    public JFreeChartAdaptor(Plot aPlot) {

        super();

        myDelegate = new JFreeChart(aPlot);
    }

    public JFreeChartAdaptor(String aTitle, Font aTitleFont, Plot aPlot, boolean aLegendFlag) {

        super();

        myDelegate = new JFreeChart(aTitle, aTitleFont, aPlot, aLegendFlag);
    }

    public JFreeChartAdaptor(String aTitle, Plot aPlot) {

        super();

        myDelegate = new JFreeChart(aTitle, aPlot);
    }

    public JFreeChartAdaptor(String aTitle, Plot aPlot, boolean aLegendFlag) {

        super();

        myDelegate = new JFreeChart(aTitle, JFreeChart.DEFAULT_TITLE_FONT, aPlot, aLegendFlag);
    }

    @SuppressWarnings("unused")
    private JFreeChartAdaptor() {

        super();

        myDelegate = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    public JFreeChart getDelegate() {
        return myDelegate;
    }

    public int getHeight() {
        return myHeight;
    }

    public String getMimeType() {
        return IMAGE_PNG;
    }

    public int getWidth() {
        return myWidth;
    }

    public void setBackgroundPaint(Paint aPaint) {
        this.getDelegate().setBackgroundPaint(aPaint);
    }

    public void setBorderVisible(boolean aFlag) {
        this.getDelegate().setBorderVisible(aFlag);
    }

    public void setHeight(int aHeight) {
        myHeight = aHeight;
    }

    public void setPlotBackgroundPaint(Paint aPaint) {
        this.getDelegate().getPlot().setBackgroundPaint(aPaint);
    }

    public void setPlotOutlinePaint(Paint aPaint) {
        this.getDelegate().getPlot().setOutlinePaint(aPaint);
    }

    public void setWidth(int aWidth) {
        myWidth = aWidth;
    }

    public byte[] toByteArray() {

        ByteArrayOutputStream tmpStream = new ByteArrayOutputStream();

        try {
            ChartUtilities.writeChartAsPNG(tmpStream, myDelegate, myWidth, myHeight);
        } catch (IOException anException) {
            // TODO Something!!
        }

        return tmpStream.toByteArray();
    }

}
