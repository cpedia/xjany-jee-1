/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.ampl;

import java.awt.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.ojalgo.netio.Message;

/**
 * GUI
 *
 * @author AMPL
 */
public class GUI extends Frame {

    private static String INITIAL_PROMPT = "ampl:";
    private static String TITLE = "AMPL/Java 0.04 19990819";

    static public void main(final String[] args) {
        new GUI(TITLE);
    }

    private JAMPL myAMPL = null;
    private final TextField myCommandLine = new TextField();
    private final TextArea myDataArea = new TextArea(15, 60);
    private Menu myFileMenu, myEditMenu, myViewMenu, mySendMenu, myHelpMenu;
    private final MenuBar myMenuBar = new MenuBar();
    private final TextArea myModelArea = new TextArea(15, 60);
    private final Label myPrompt = new Label(INITIAL_PROMPT);
    private int myTransactionCount = 0;
    private final TextArea myTranscript = new TextArea(30, 60);

    CheckboxMenuItem cbtool;
    TextField find = new TextField(20);
    GridBagLayout gb;
    GridBagConstraints gbc = new GridBagConstraints();
    int last_pat = 0; // last pattern location for find
    String last_sel = ""; // last selected text
    TextArea last_text = null; // who had the focus last
    String lastdir = "."; // directory for file opens
    Panel pl, pr, pb;

    public GUI() throws HeadlessException {

        super();

        this.initialise();
    }

    public GUI(final GraphicsConfiguration aGC) {

        super(aGC);

        this.initialise();
    }

    public GUI(final String aTitle) {

        super(aTitle);

        this.initialise();
    }

    public GUI(final String aTitle, final GraphicsConfiguration aGC) {

        super(aTitle, aGC);

        this.initialise();
    }

    @Override
    public boolean action(final Event anEvent, final Object what) {
        if (anEvent.target == myCommandLine) { // Return in command textfield
            this.sendCommand(myCommandLine.getText());
            return true;
        } else if (anEvent.target == find) {
            this.find_cmd();
            return true;
        } else if (anEvent.target == cbtool) {
            if (cbtool.getState() == false) {
                pb.hide();
            } else {
                pb.show();
            }
            this.pack();
            return true;
        } else if (anEvent.target instanceof Button) {
            final String b = (String) what;
            if (b.equals("New")) {
                this.file_new();
            } else if (b.equals("Model")) {
                this.readmod(myModelArea);
            } else if (b.equals("Data")) {
                this.readmod(myDataArea);
            } else if (b.equals("Solve")) {
                this.solve_button();
            } else if (b.equals("Reset")) {
                this.sendCommand("reset;");
            } else if (b.equals("Display")) {
                this.display_button();
            } else if (b.equals("Clear")) {
                last_text.setText("");
            }
            return true;
        } else if (anEvent.target instanceof MenuItem) {
            final String arg = (String) anEvent.arg;
            // File:
            if (arg.equals("New")) {
                this.file_new();
            } else if (arg.equals("Open model...")) {
                this.readmod(myModelArea);
            } else if (arg.equals("Open data...")) {
                this.readmod(myDataArea);
            } else if (arg.equals("Save...")) {
                this.savemod(last_text);
            } else if (arg.equals("Exit")) {
                if (myAMPL != null) {
                    myAMPL.communicate(new Message("exit")); // don't ask for reply
                }

                this.hide();
                this.dispose();
                System.exit(0); // needed standalone

                // Edit:
            } else if (arg.equals("Cut")) {
                last_sel = last_text.getSelectedText();
                final int n1 = last_text.getSelectionStart();
                final int n2 = last_text.getSelectionEnd();
                last_text.replaceText("", n1, n2);
            } else if (arg.equals("Copy")) {
                last_sel = last_text.getSelectedText();
            } else if (arg.equals("Paste")) {
                final int n1 = last_text.getSelectionStart();
                final int n2 = last_text.getSelectionEnd();
                last_sel = "" + last_sel + "";
                last_text.replaceText(last_sel, n1, n2);
            } else if (arg.equals("Select All")) {
                last_text.selectAll();

                // View:

                // Send:
            } else if (arg.equals("Selection")) {
                this.sendCommand(myTranscript.getSelectedText());
            } else if (arg.equals("Model")) {
                this.sendCommand("reset; model;\n" + myModelArea.getText());
            } else if (arg.equals("Data")) {
                this.sendCommand("reset data; data;\n" + myDataArea.getText());
            } else if (arg.equals("Solve")) {
                this.solve_button();
            } else if (arg.equals("Reset")) {
                this.sendCommand("reset;");
            } else if (arg.equals("Reset Data")) {
                this.sendCommand("reset data;");

                // Options:
            } else if (arg.equals("Network connection")) {

                // Help:
            } else if (arg.equals("README file")) {
                final Notepad d = new Notepad(this, "readme.txt");
            } else if (arg.equals("About AMPL/Java")) {
                final Notepad d = new Notepad(this, "about.txt");
            } // last one
            return true;
        }
        return false;
    }

    public void display_button() {

        // myJAMPL.writeMessage(new Message("displat", last_text.getSelectedText()))

        this.sendCommand("display " + last_text.getSelectedText() + ";");
    }

    public void file_new() {
        // should save and close previous files first
        myTranscript.setText("");
        myModelArea.setText("# Type model here or open a model file...\n");
        myDataArea.setText("# Type data here or open a data file...\n");
        myTransactionCount = 0;
    }

    public void find_cmd() {
        final String pat = find.getText();
        if (last_text == null) {
            last_text = myTranscript; // kludge
        }
        final String targ = last_text.getText();
        int n = 0;
        if (last_pat + pat.length() >= targ.length()) {
            last_pat = 0;
        }
        n = targ.indexOf(pat, last_pat); // look for it
        if (n == -1) {
            last_pat = 0;
            n = targ.indexOf(pat, 0); // look again
        }
        if (n >= 0) {
            last_text.select(n, n + pat.length());
            last_pat = n + 1;
            // there's a bug here: indexOf appears to count \r's while select does not.
            System.err.println("n = " + n);
        }
    }

    @Override
    public boolean gotFocus(final Event e, final Object what) {
        // so we know where to apply Edit menu items
        if (e.target instanceof TextArea) {
            last_text = (TextArea) e.target;
            return true;
        }
        return false;
    }

    public void initfont(final String ft, final int size) {
        final Font f = new Font(ft, Font.PLAIN, size);
        myTranscript.setFont(f);
        myCommandLine.setFont(f);
        myModelArea.setFont(f);
        myDataArea.setFont(f);
    }

    @Override
    public boolean mouseDown(final Event e, final int x, final int y) {
        // does not work for textareas; just unused parts of frames and panels
        //System.err.println("mouse down " + e.target);
        if (e.target instanceof TextArea) {
            last_text = (TextArea) e.target;
            return true;
        }
        return false;
    }

    public String readfile(final String fname) {
        int n;
        final byte buf[] = new byte[1000];
        String s = new String("");
        FileInputStream in;

        try {
            in = new FileInputStream(fname);
        } catch (final FileNotFoundException e) {
            System.err.println(e + " can't open " + fname);
            return e + " can't open " + fname;
        }
        try {
            while ((n = in.read(buf)) > 0) {
                final String s1 = new String(buf, 0, 0, n);
                s = s + s1;
            }
        } catch (final IOException e) {
            System.err.println(e + " readfile error");
            return e + " readfile error";
        }
        return s;
    }

    public void readmod(final TextArea t) {
        final String which = (t == myModelArea) ? "Model" : "Data";

        final FileDialog fd = new FileDialog(this, "Open " + which, FileDialog.LOAD);
        fd.setDirectory(lastdir); // back to where we were
        fd.pack();
        fd.show();

        lastdir = fd.getDirectory();
        if (fd.getFile() != null) {
            t.setText(this.readfile(lastdir + fd.getFile()));
        }
    }

    public void savemod(TextArea t) {
        String which;
        if (t == myModelArea) {
            which = "Model";
        } else if (t == myDataArea) {
            which = "Data";
        } else {
            t = myTranscript;
            which = "Command";
        }

        final FileDialog fd = new FileDialog(this, "Save " + which, FileDialog.SAVE);
        fd.setDirectory(lastdir);
        fd.pack();
        fd.show();
        if (fd.getFile() != null) {
            this.writefile(t.getText(), fd.getDirectory() + fd.getFile());
        }
    }

    public void sendCommand(final String aCommand) {

        myTranscript.append("== " + ++myTransactionCount + " == " + aCommand + "\n");

        final Message tmpMessage = new Message(aCommand);
        final List<Message> tmpReply = myAMPL.communicate(tmpMessage);

        myCommandLine.selectAll();

        this.appendToTranscript(tmpReply);

        myPrompt.setText(myAMPL.getLastReturnArgument());
    }

    public void solve_button() {
        this.sendCommand("reset;\n" + myModelArea.getText() + "\n" + "data;\n" + myDataArea.getText() + "solve;\n");
    }

    public JAMPL startAmpl() {

        if (myAMPL != null) {
            myAMPL.terminate();
            myAMPL = null;
        }

        myCommandLine.setBackground(Color.white);
        myCommandLine.setText("");

        try {
            myAMPL = new JAMPL();
        } catch (final Exception e) {
            myCommandLine.setBackground(Color.yellow);
            myCommandLine.setText(e + " starting " + "AMPL");
            System.err.println(e + " starting " + "AMPL");
        }

        if (myAMPL != null) { // Test for vital signs

            List<Message> tmpList = new ArrayList<Message>();
            tmpList.add(new Message("option", "show_stats", "1"));
            tmpList.add(new Message("option", "display_eps", ".000001"));
            tmpList.add(new Message("print", "$version"));
            tmpList = myAMPL.communicate(tmpList);

            this.appendToTranscript(tmpList);
        }

        return myAMPL;
    }

    public void startGui() {

        this.setMenuBar(myMenuBar);

        myFileMenu = new Menu("File");
        myFileMenu.add(new MenuItem("New"));
        myFileMenu.add(new MenuItem("Open model..."));
        myFileMenu.add(new MenuItem("Open data..."));
        myFileMenu.add(new MenuItem("-"));
        myFileMenu.add(new MenuItem("Save..."));
        myFileMenu.add(new MenuItem("-"));
        myFileMenu.add(new MenuItem("Exit"));
        myMenuBar.add(myFileMenu);

        myEditMenu = new Menu("Edit");
        myEditMenu.add(new MenuItem("Cut"));
        myEditMenu.add(new MenuItem("Copy"));
        myEditMenu.add(new MenuItem("Paste"));
        myEditMenu.add(new MenuItem("Select All"));
        myMenuBar.add(myEditMenu);

        myViewMenu = new Menu("View");
        cbtool = new CheckboxMenuItem("Toolbar");
        cbtool.setState(true);
        myViewMenu.add(cbtool);
        myMenuBar.add(myViewMenu);

        mySendMenu = new Menu("Send");
        mySendMenu.add(new MenuItem("Selection"));
        mySendMenu.add(new MenuItem("-"));
        mySendMenu.add(new MenuItem("Model"));
        mySendMenu.add(new MenuItem("Data"));
        mySendMenu.add(new MenuItem("Solve"));
        mySendMenu.add(new MenuItem("-"));
        mySendMenu.add(new MenuItem("Reset"));
        mySendMenu.add(new MenuItem("Reset Data"));
        myMenuBar.add(mySendMenu);

        myHelpMenu = new Menu("Help");
        myHelpMenu.add(new MenuItem("README file"));
        myHelpMenu.add(new MenuItem("-"));
        myHelpMenu.add(new MenuItem("About AMPL/Java"));
        myMenuBar.add(myHelpMenu);

        //	initfont("Courier", 12);

        // left side: prompt, command input acmd and output trans:

        final Panel p0 = new Panel();
        final GridBagLayout g0 = new GridBagLayout();
        final GridBagConstraints g0c = new GridBagConstraints();
        p0.setLayout(g0);
        g0c.fill = GridBagConstraints.HORIZONTAL;
        g0c.anchor = GridBagConstraints.WEST;
        g0c.weightx = 0;
        g0c.weighty = 0;
        g0c.gridx = 0;
        g0c.gridy = 0;
        g0.setConstraints(myPrompt, g0c);
        p0.add(myPrompt);

        g0c.weightx = 1;
        g0c.weighty = 0;
        g0c.gridx = 1;
        g0c.gridy = 0;
        g0.setConstraints(myCommandLine, g0c);
        p0.add(myCommandLine);

        pl = new Panel();
        gb = new GridBagLayout();
        pl.setLayout(gb);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.weightx = 1;
        gbc.weighty = 0;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gb.setConstraints(p0, gbc);
        pl.add(p0);

        gbc.weighty = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gb.setConstraints(myTranscript, gbc);
        pl.add(myTranscript);

        // right side: model and data:
        pr = new Panel();
        pr.setLayout(gb);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.weighty = .5;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gb.setConstraints(myModelArea, gbc);
        pr.add(myModelArea);

        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gb.setConstraints(myDataArea, gbc);
        pr.add(myDataArea);

        // top: toolbar:
        pb = new Panel();
        pb.setLayout(new FlowLayout(FlowLayout.LEFT));
        pb.add(new Button("New"));
        pb.add(new Button("Model"));
        pb.add(new Button("Data"));
        pb.add(new Button("Solve"));
        pb.add(new Button("Reset"));
        pb.add(new Button("Display"));
        pb.add(new Button("Clear"));
        pb.add(find); // "Find"

        // overall:
        this.setLayout(gb);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.weightx = 1;
        gbc.weighty = 0;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // spans horiz
        gb.setConstraints(pb, gbc);
        this.add(pb);

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = .5;
        gbc.weighty = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1; // revert
        gb.setConstraints(pl, gbc);
        this.add(pl);

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = .5;
        gbc.weighty = 1;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1; // revert
        gb.setConstraints(pr, gbc);
        this.add(pr);

        this.pack();
        this.show();
        myModelArea.setText("# Type model here or open a model file...\n");
        myDataArea.setText("# Type data here or open a data file...\n");
        myCommandLine.requestFocus();
    }

    public void writefile(final String s, final String fname) {
        FileOutputStream out;

        try {
            out = new FileOutputStream(fname);
            final byte buf[] = new byte[s.length()];
            s.getBytes(0, s.length(), buf, 0);
            out.write(buf);
            out.close();
        } catch (final FileNotFoundException e) {
            System.err.println(e + " can't open " + fname);
        } catch (final IOException e) {
            System.err.println(e + " writefile error");
        }
    }

    private void appendToTranscript(final List<Message> someMessages) {
        for (int i = 0; i < someMessages.size() - 1; i++) {
            myTranscript.append(someMessages.get(i).toString());
        }
    }

    private void initialise() {

        this.startGui();

        myAMPL = this.startAmpl();
    }

}

class Notepad extends Dialog {

    GUI gui;

    public Notepad(final Frame parent, final String fname) {
        super(parent, "Viewing " + fname, false); // non-modal
        gui = (GUI) parent;

        this.setLayout(new BorderLayout());
        this.add("Center", new TextArea(gui.readfile(fname)));
        final Button ok = new Button("    OK    ");
        this.add("South", ok);

        this.move(30, 30);
        this.pack();
        this.show();
    }

    public boolean action(final Event e, final Object arg) {
        if (arg.equals("    OK    ")) {
            this.hide();
            this.dispose();
            return true;
        }
        return false;
    }

}
