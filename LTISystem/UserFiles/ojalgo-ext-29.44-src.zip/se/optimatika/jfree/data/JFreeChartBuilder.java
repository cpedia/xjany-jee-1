/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jfree.data;

import java.awt.Paint;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.Timeline;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.StackedXYAreaRenderer2;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.data.general.WaferMapDataset;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.WindDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.util.TableOrder;
import org.ojalgo.chart.ChartBuilder;
import org.ojalgo.chart.Orientation;
import org.ojalgo.chart.Priority;
import org.ojalgo.chart.Type;

import se.optimatika.jfree.chart.JFreeChartAdaptor;

/**
 * JFreeData
 * 
 * @author apete
 */
abstract class JFreeChartBuilder extends ChartBuilder {

    public JFreeChartBuilder(final Type aType) {
        super(aType);
    }

    protected final JFreeChartAdaptor createAreaChart(final String title, final String categoryAxisLabel, final String valueAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createAreaChart(title, categoryAxisLabel, valueAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createBarChart(final String title, final String categoryAxisLabel, final String valueAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend, final List<Paint> colours) {

        final JFreeChart retVal = ChartFactory.createBarChart(title, categoryAxisLabel, valueAxisLabel, dataset, orientation, legend, false, false);

        final BarRenderer tmpRenderer = (BarRenderer) ((CategoryPlot) retVal.getPlot()).getRenderer();

        Paint tmpPaint;
        for (int i = 0; i < colours.size(); i++) {
            tmpPaint = colours.get(i);
            tmpRenderer.setSeriesPaint(i, tmpPaint);
        }

        tmpRenderer.setBarPainter(new StandardBarPainter());
        tmpRenderer.setShadowVisible(false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createBarChart3D(final String title, final String categoryAxisLabel, final String valueAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createBarChart3D(title, categoryAxisLabel, valueAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createBoxAndWhiskerChart(final String title, final String timeAxisLabel, final String valueAxisLabel, final BoxAndWhiskerXYDataset dataset, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createBoxAndWhiskerChart(title, timeAxisLabel, valueAxisLabel, dataset, legend);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createBubbleChart(final String title, final String xAxisLabel, final String yAxisLabel, final XYZDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createBubbleChart(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createCandlestickChart(final String title, final String timeAxisLabel, final String valueAxisLabel, final OHLCDataset dataset, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createCandlestickChart(title, timeAxisLabel, valueAxisLabel, dataset, legend);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createGanttChart(final String title, final String categoryAxisLabel, final String dateAxisLabel, final IntervalCategoryDataset dataset, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createGanttChart(title, categoryAxisLabel, dateAxisLabel, dataset, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createHighLowChart(final String title, final String timeAxisLabel, final String valueAxisLabel, final OHLCDataset dataset, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createHighLowChart(title, timeAxisLabel, valueAxisLabel, dataset, legend);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createHighLowChart(final String title, final String timeAxisLabel, final String valueAxisLabel, final OHLCDataset dataset, final Timeline timeline, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createHighLowChart(title, timeAxisLabel, valueAxisLabel, dataset, timeline, legend);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createHistogram(final String title, final String xAxisLabel, final String yAxisLabel, final IntervalXYDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createHistogram(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createLineChart(final String title, final String categoryAxisLabel, final String valueAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createLineChart(title, categoryAxisLabel, valueAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createLineChart3D(final String title, final String categoryAxisLabel, final String valueAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createLineChart3D(title, categoryAxisLabel, valueAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createMultiplePieChart(final String title, final CategoryDataset dataset, final TableOrder order, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createMultiplePieChart(title, dataset, order, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createMultiplePieChart3D(final String title, final CategoryDataset dataset, final TableOrder order, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createMultiplePieChart3D(title, dataset, order, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createPieChart(final String title, final PieDataset dataset, final boolean legend, final Map<String, Paint> colours) {

        final JFreeChart retVal = ChartFactory.createPieChart(title, dataset, legend, false, false);

        if ((colours != null) && (colours.size() >= 1)) {

            final PiePlot tmpPlot = (PiePlot) retVal.getPlot();

            String tmpKey;
            for (final Iterator<String> tmpIter = colours.keySet().iterator(); tmpIter.hasNext();) {
                tmpKey = tmpIter.next();
                tmpPlot.setSectionPaint(tmpKey, colours.get(tmpKey));
            }
        }

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createPieChart(final String title, final PieDataset dataset, final PieDataset previousDataset, final int percentDiffForMaxScale, final boolean greenForIncrease, final boolean legend, final boolean subTitle, final boolean showDifference) {

        final JFreeChart retVal = ChartFactory.createPieChart(title, dataset, previousDataset, percentDiffForMaxScale, greenForIncrease, legend, false, false, subTitle, showDifference);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createPieChart3D(final String title, final PieDataset dataset, final boolean legend, final Map<String, Paint> colours) {

        final JFreeChart retVal = ChartFactory.createPieChart3D(title, dataset, legend, false, false);

        if ((colours != null) && (colours.size() >= 1)) {

            final PiePlot tmpPlot = (PiePlot) retVal.getPlot();

            String tmpKey;
            for (final Iterator<String> tmpIter = colours.keySet().iterator(); tmpIter.hasNext();) {
                tmpKey = tmpIter.next();
                tmpPlot.setSectionPaint(tmpKey, colours.get(tmpKey));
            }
        }

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createPolarChart(final String title, final XYDataset dataset, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createPolarChart(title, dataset, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createRingChart(final String title, final PieDataset dataset, final boolean legend, final Map<String, Paint> colours) {

        final JFreeChart retVal = ChartFactory.createRingChart(title, dataset, legend, false, false);

        if ((colours != null) && (colours.size() >= 1)) {

            final PiePlot tmpPlot = (PiePlot) retVal.getPlot();

            String tmpKey;
            for (final Iterator<String> tmpIter = colours.keySet().iterator(); tmpIter.hasNext();) {
                tmpKey = tmpIter.next();
                tmpPlot.setSectionPaint(tmpKey, colours.get(tmpKey));
            }
        }

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createScatterPlot(final String title, final String xAxisLabel, final String yAxisLabel, final XYDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createScatterPlot(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createStackedAreaChart(final String title, final String categoryAxisLabel, final String valueAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createStackedAreaChart(title, categoryAxisLabel, valueAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createStackedBarChart(final String title, final String domainAxisLabel, final String rangeAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createStackedBarChart(title, domainAxisLabel, rangeAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createStackedBarChart3D(final String title, final String domainAxisLabel, final String rangeAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createStackedBarChart3D(title, domainAxisLabel, rangeAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createStackedXYAreaChart(final String title, final String xAxisLabel, final String yAxisLabel, final TableXYDataset dataset, final PlotOrientation orientation, final boolean legend, final Map<String, Paint> colours) {

        final JFreeChart retVal = ChartFactory.createStackedXYAreaChart(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        if (colours != null) {

            final StackedXYAreaRenderer2 tmpRenderer = (StackedXYAreaRenderer2) ((XYPlot) retVal.getPlot()).getRenderer();

            String tmpKey;
            Paint tmpPaint;
            for (int i = 0; i < dataset.getSeriesCount(); i++) {
                tmpKey = (String) dataset.getSeriesKey(i);
                tmpPaint = colours.get(tmpKey);
                tmpRenderer.setSeriesPaint(i, tmpPaint);
            }
        }

        // TODO Är detta fortfarande nödvändigt? Varför var det nödvändigt?
        retVal.getXYPlot().getRangeAxis().configure();

        return new JFreeChartAdaptor(retVal);
    }

    /**
     * @see ChartFactory#createTimeSeriesChart(String, String, String, XYDataset, boolean, boolean, boolean)
     */
    protected final JFreeChartAdaptor createTimeSeriesChart(final String title, final String timeAxisLabel, final String valueAxisLabel, final XYDataset dataset, final boolean legend, final Map<String, Paint> colours, final boolean log, final boolean deviation) {

        final ValueAxis tmpTimeAxis = new DateAxis(timeAxisLabel);
        tmpTimeAxis.setLowerMargin(0.02); // reduce the default margins 
        tmpTimeAxis.setUpperMargin(0.02);
        NumberAxis tmpValueAxis = null;
        if (log) {
            tmpValueAxis = new LogarithmicAxis(valueAxisLabel);
        } else {
            tmpValueAxis = new NumberAxis(valueAxisLabel);
        }
        tmpValueAxis.setAutoRangeIncludesZero(false); // override default

        final XYPlot tmpPlot = new XYPlot(dataset, tmpTimeAxis, tmpValueAxis, null);

        XYLineAndShapeRenderer tmpRenderer = null;
        if (deviation) {
            tmpRenderer = new DeviationRenderer(true, false);
        } else {
            tmpRenderer = new XYLineAndShapeRenderer(true, false);
        }
        tmpRenderer.setBaseToolTipGenerator(null);
        tmpRenderer.setURLGenerator(null);

        if (colours != null) {

            String tmpKey;
            Paint tmpPaint;
            for (int i = 0; i < dataset.getSeriesCount(); i++) {
                tmpKey = (String) dataset.getSeriesKey(i);
                tmpPaint = colours.get(tmpKey);
                tmpRenderer.setSeriesPaint(i, tmpPaint);
                tmpRenderer.setSeriesFillPaint(i, tmpPaint);
            }
        }

        tmpPlot.setRenderer(tmpRenderer);

        return new JFreeChartAdaptor(title, tmpPlot, legend);
    }

    protected final JFreeChartAdaptor createWaferMapChart(final String title, final WaferMapDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createWaferMapChart(title, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createWaterfallChart(final String title, final String categoryAxisLabel, final String valueAxisLabel, final CategoryDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createWaterfallChart(title, categoryAxisLabel, valueAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createWindPlot(final String title, final String xAxisLabel, final String yAxisLabel, final WindDataset dataset, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createWindPlot(title, xAxisLabel, yAxisLabel, dataset, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createXYAreaChart(final String title, final String xAxisLabel, final String yAxisLabel, final XYDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createXYAreaChart(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createXYBarChart(final String title, final String xAxisLabel, final boolean dateAxis, final String yAxisLabel, final IntervalXYDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createXYBarChart(title, xAxisLabel, dateAxis, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createXYLineChart(final String title, final String xAxisLabel, final String yAxisLabel, final XYDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createXYLineChart(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createXYStepAreaChart(final String title, final String xAxisLabel, final String yAxisLabel, final XYDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createXYStepAreaChart(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected final JFreeChartAdaptor createXYStepChart(final String title, final String xAxisLabel, final String yAxisLabel, final XYDataset dataset, final PlotOrientation orientation, final boolean legend) {

        final JFreeChart retVal = ChartFactory.createXYStepChart(title, xAxisLabel, yAxisLabel, dataset, orientation, legend, false, false);

        return new JFreeChartAdaptor(retVal);
    }

    protected PlotOrientation getJFreeOrientation() {

        PlotOrientation retVal = PlotOrientation.VERTICAL;

        if (this.getOrientation() == Orientation.HORISONTAL) {
            retVal = PlotOrientation.HORIZONTAL;
        }

        return retVal;
    }

    protected TableOrder getJFreePriority() {

        TableOrder retVal = TableOrder.BY_COLUMN;

        if (this.getPriority() == Priority.ROW) {
            retVal = TableOrder.BY_ROW;
        }

        return retVal;
    }

}
