/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.util.List;

import org.ojalgo.access.Access2D;
import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;

public final class SimplePortfolio extends EquilibriumModel {

    public static SimplePortfolio make(final Access2D<?> aCorrelationsMatrix, final List<SimpleAsset> someAssets) {

        final int tmpSize = someAssets.size();

        final PhysicalStore<Double> tmpCovaris = PrimitiveDenseStore.FACTORY.copy(aCorrelationsMatrix);
        final PhysicalStore<Double> tmpReturns = PrimitiveDenseStore.FACTORY.makeEmpty(tmpSize, 1);
        final PhysicalStore<Double> tmpWeights = PrimitiveDenseStore.FACTORY.makeEmpty(tmpSize, 1);

        SimpleAsset tmpAsset;
        for (int ij = 0; ij < tmpSize; ij++) {

            tmpAsset = someAssets.get(ij);

            tmpReturns.set(ij, 0, tmpAsset.getMeanReturn().doubleValue());
            tmpWeights.set(ij, 0, tmpAsset.getWeight().doubleValue());

            final PreconfiguredSecond<Double> tmpFunc = new PreconfiguredSecond<Double>(PrimitiveFunction.MULTIPLY, tmpAsset.getVolatility().doubleValue());
            tmpCovaris.modifyRow(ij, 0, tmpFunc);
            tmpCovaris.modifyColumn(0, ij, tmpFunc);
        }

        final BasicMatrix tmpCovarisMtrx = FACTORY.copy(tmpCovaris);
        final BasicMatrix tmpReturnsMtrx = FACTORY.copy(tmpReturns);
        final BasicMatrix tmpWeightsMtrx = FACTORY.copy(tmpWeights);

        final MarketEquilibrium tmpME = new MarketEquilibrium(tmpCovarisMtrx);
        tmpME.calibrate(tmpWeightsMtrx, tmpReturnsMtrx);

        return new SimplePortfolio(tmpME, tmpReturnsMtrx, tmpWeightsMtrx);
    }

    private final BasicMatrix myReturnsMatrx;
    private final BasicMatrix myWeightsMatrix;

    @SuppressWarnings("unused")
    private SimplePortfolio(final EquilibriumModel aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myReturnsMatrx = null;
        myWeightsMatrix = null;
    }

    @SuppressWarnings("unused")
    private SimplePortfolio(final MarketEquilibrium aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myReturnsMatrx = null;
        myWeightsMatrix = null;
    }

    SimplePortfolio(final MarketEquilibrium aMarketEquilibrium, final BasicMatrix aReturnsMatrx, final BasicMatrix aWeightsMatrix) {

        super(aMarketEquilibrium);

        myReturnsMatrx = aReturnsMatrx;
        myWeightsMatrix = aWeightsMatrix;
    }

    @Override
    protected BasicMatrix calculateAssetReturns() {
        return myReturnsMatrx;
    }

    @Override
    protected BasicMatrix calculateAssetWeights() {
        return myWeightsMatrix;
    }

}
