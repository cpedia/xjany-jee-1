/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.concurrent;

import java.util.Arrays;

public class Hardware {

    public static final class MemoryThreads {

        private static final String BYTES = "bytes/";
        private static final String GIGA = "GB/";
        private static final String KILO = "kB/";
        private static final String MEGA = "MB/";
        private static final String THREAD = "thread";
        private static final String THREADS = "threads";

        public final long memory;
        public final int threads;

        public MemoryThreads(final long aMemory, final int aThreads) {

            super();

            memory = aMemory;
            threads = aThreads;
        }

        @SuppressWarnings("unused")
        private MemoryThreads() {
            this(0L, 1);
        }

        @Override
        public String toString() {

            int tmpPrefix = 1;
            int tmpMeasure = (int) (memory / 1024);

            while (tmpMeasure / 1024 > 0) {
                tmpPrefix++;
                tmpMeasure = tmpMeasure / 1024;
            }

            switch (tmpPrefix) {

            case 1:

                return tmpMeasure + KILO + threads + ((threads == 1) ? THREAD : THREADS);

            case 2:

                return tmpMeasure + MEGA + threads + ((threads == 1) ? THREAD : THREADS);

            case 3:

                return tmpMeasure + GIGA + threads + ((threads == 1) ? THREAD : THREADS);

            default:

                return memory + BYTES + threads + ((threads == 1) ? THREAD : THREADS);
            }

        }
    }

    /**
     * Status   Launched
     * Launch Date  Q1'08
     * Processor Number E8500
     * # of Cores   2
     * # of Threads 2
     * Clock Speed  3.16 GHz
     * L2 Cache 6 MB
     * Bus/Core Ratio   9.5
     * FSB Speed    1333 MHz
     * FSB Parity   No
     * Instruction Set  64-bit
     * Embedded Options Available   No
     * Supplemental SKU No
     * Lithography  45 nm
     * Max TDP  65 W
     * VID Voltage Range    0.8500V-1.3625V
     * Tray 1ku Budgetary Price $183.00
     * 
     * 3.5 GB RAM
     * 
     *  <code>new MemoryThreads[] { SYSTEM, L2 cache }</code>
     */
    public static final Hardware B5950053 = new Hardware(new MemoryThreads[] { new MemoryThreads(7L * 512L * 1024L * 1024L, 2), new MemoryThreads(6L * 1024L * 1024L, 2) });

    /**
     *  Model Name: iMac
     *  Model Identifier: iMac7,1
     *  Processor Name:   Intel Core 2 Duo
     *  Processor Speed:  2,4 GHz
     *  Number Of Processors: 1
     *  Total Number Of Cores:    2
     *  L2 Cache: 4 MB
     *  Memory:   3 GB
     *  Bus Speed:    800 MHz
     *  Boot ROM Version: IM71.007A.B03
     *  SMC Version (system): 1.20f4
     *  Serial Number (system):   W8735035X88
     *  Hardware UUID:    00000000-0000-1000-8000-001B639A63C6
     *  
     *  <code>new MemoryThreads[] { SYSTEM, L2 cache }</code>
     */
    public static final Hardware MANTA = new Hardware(new MemoryThreads[] { new MemoryThreads(3L * 1024L * 1024L * 1024L, 2), new MemoryThreads(4L * 1024L * 1024L, 2) });

    /**
     * Peter Abeles' (EJML) Pentium-M machine.
     */
    public static final Hardware PENTIUM_M = new Hardware(new MemoryThreads[] { new MemoryThreads(1L * 1024L * 1024L * 1024L, 1), new MemoryThreads(2L * 1024L * 1024L, 1) });

    /**
     * Peter Abeles' (EJML) Q9400 machine.
     * 
     * Status   Launched
     * Launch Date Q3'08
     * Processor Number    Q9400
     * # of Cores  4
     * # of Threads    4
     * Clock Speed 2.66 GHz
     * L2 Cache    6 MB
     * Bus/Core Ratio  8
     * FSB Speed   1333 MHz
     * FSB Parity  No
     * Instruction Set 64-bit
     * Embedded Options Available  Yes
     * Supplemental SKU    No
     * Lithography 45 nm
     * Max TDP 95 W
     * VID Voltage Range   0.8500v-1.3625v
     * Tray 1ku Budgetary Price    $183.00
     */
    public static final Hardware Q9400 = new Hardware(new MemoryThreads[] { new MemoryThreads(3L * 1024L * 1024L * 1024L, 4), new MemoryThreads(6L * 1024L * 1024L, 4) });

    /**
     * 2 CPUs
     * 4 cores per CPU
     * 2 (hyper) threads per core
     * Total 16 threads
     * 
     * 12 GB RAM
     * 8MB L3 cache per CPU
     * 256kB L2 cache per core
     * 
     * <code>new MemoryThreads[] { SYSTEM, L3 cache, L2 cache }</code>
     */
    public static final Hardware SAILFISH = new Hardware(new MemoryThreads[] { new MemoryThreads(12L * 1024L * 1024L * 1024L, 16), new MemoryThreads(8L * 1024L * 1024L, 8), new MemoryThreads(256L * 1024L, 2) });

    /**
     * 1 CPU
     * 4 cores per CPU
     * 2 (hyper) threads per core
     * Total 8 threads
     * 
     * 8 GB RAM
     * 8MB L3 cache per CPU
     * 256kB L2 cache per core
     * 32kB L1 cache per core
     * 
     * <code>new MemoryThreads[] { SYSTEM, L3 cache, L2 cache }</code>
     */
    public static final Hardware COREI7 = new Hardware(new MemoryThreads[] { new MemoryThreads(8L * 1024L * 1024L * 1024L, 8), new MemoryThreads(8L * 1024L * 1024L, 4), new MemoryThreads(256L * 1024L, 2) });

    private static final String COLON_SPACE = ": ";

    /**
     * Cache size per core (or CPU) in bytes
     */
    public final long cache;
    /**
     * The dimension (size) of the largest square matrix that will fit in a cache
     */
    public final int dim;
    /**
     * The largest number of matrix elements that will fit in a cache
     */
    public final int elements;
    /**
     * Total amount of RAM in bytes
     */
    public final long memory;
    /**
     * Total number of threads
     * 
     * @see Runtime#availableProcessors()
     */
    public final int processors;
    /**
     * Threads per cache
     */
    public final int threads;
    /**
     * The number of cache units (the number of cores or CPUs)
     */
    public final int units;

    private final MemoryThreads[] myLevels;

    public Hardware(final MemoryThreads[] someLevels) {

        super();

        myLevels = someLevels;

        final int tmpFirstIndex = 0;
        final int tmpLastIndex = someLevels.length - 1;

        memory = myLevels[tmpFirstIndex].memory;
        cache = myLevels[tmpLastIndex].memory;

        processors = myLevels[tmpFirstIndex].threads;
        threads = myLevels[tmpLastIndex].threads;

        units = processors / threads;

        elements = (int) (cache / 8);

        dim = (int) Math.sqrt(elements);
    }

    @SuppressWarnings("unused")
    private Hardware() {
        this(null);
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + COLON_SPACE + Arrays.toString(myLevels);
    }

}
