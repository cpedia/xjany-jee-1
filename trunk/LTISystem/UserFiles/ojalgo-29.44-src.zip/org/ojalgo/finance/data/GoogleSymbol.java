/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.data;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.ojalgo.netio.ASCII;
import org.ojalgo.type.CalendarDateUnit;

public class GoogleSymbol extends DataSource {

    public static final class Data implements DatePrice {

        public BigDecimal close;
        public Date date;
        public BigDecimal high;
        public BigDecimal low;
        public BigDecimal open;
        public BigDecimal volume;

        public Date getDate() {
            return date;
        }

        public BigDecimal getPrice() {
            return close;
        }

        @Override
        public String toString() {
            return date + ": " + close;
        }

    }

    private static final String CSV = "csv";
    private static final String DAILY = "daily";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MMM-yy");
    private static final String FINANCE_GOOGLE_COM = "finance.google.com";
    private static final String FINANCE_HISTORICAL = "/finance/historical";
    private static final String HISTPERIOD = "histperiod";
    private static final String JAN_2_1970 = "Jan+2,+1970";
    private static final String OUTPUT = "output";
    private static final String Q = "q";
    private static final String STARTDATE = "startdate";
    private static final String WEEKLY = "weekly";

    public GoogleSymbol(final String aSymbol) {
        this(aSymbol, CalendarDateUnit.DAY);
    }

    public GoogleSymbol(final String aSymbol, final CalendarDateUnit aTimeUnit) {

        super(aSymbol, aTimeUnit);

        this.setHost(FINANCE_GOOGLE_COM);
        this.setPath(FINANCE_HISTORICAL);
        this.addQueryParameter(Q, aSymbol);
        this.addQueryParameter(STARTDATE, JAN_2_1970);
        switch (aTimeUnit) {
        case WEEK:
            this.addQueryParameter(HISTPERIOD, WEEKLY);
            break;
        default:
            this.addQueryParameter(HISTPERIOD, DAILY);
            break;
        }
        this.addQueryParameter(OUTPUT, CSV);
    }

    @Override
    protected DatePrice parse(final String aLine) {

        final Data retVal = new Data();

        int tmpInclusiveBegin = 0;
        int tmpExclusiveEnd = aLine.indexOf(ASCII.COMMA, tmpInclusiveBegin);
        String tmpString = aLine.substring(tmpInclusiveBegin, tmpExclusiveEnd);
        try {
            retVal.date = DATE_FORMAT.parse(tmpString);
        } catch (final ParseException anException) {
            anException.printStackTrace();
        }

        tmpInclusiveBegin = tmpExclusiveEnd + 1;
        tmpExclusiveEnd = aLine.indexOf(ASCII.COMMA, tmpInclusiveBegin);
        tmpString = aLine.substring(tmpInclusiveBegin, tmpExclusiveEnd);
        retVal.open = new BigDecimal(tmpString);

        tmpInclusiveBegin = tmpExclusiveEnd + 1;
        tmpExclusiveEnd = aLine.indexOf(ASCII.COMMA, tmpInclusiveBegin);
        tmpString = aLine.substring(tmpInclusiveBegin, tmpExclusiveEnd);
        retVal.high = new BigDecimal(tmpString);

        tmpInclusiveBegin = tmpExclusiveEnd + 1;
        tmpExclusiveEnd = aLine.indexOf(ASCII.COMMA, tmpInclusiveBegin);
        tmpString = aLine.substring(tmpInclusiveBegin, tmpExclusiveEnd);
        retVal.low = new BigDecimal(tmpString);

        tmpInclusiveBegin = tmpExclusiveEnd + 1;
        tmpExclusiveEnd = aLine.indexOf(ASCII.COMMA, tmpInclusiveBegin);
        tmpString = aLine.substring(tmpInclusiveBegin, tmpExclusiveEnd);
        retVal.close = new BigDecimal(tmpString);

        tmpInclusiveBegin = tmpExclusiveEnd + 1;
        tmpString = aLine.substring(tmpInclusiveBegin);
        retVal.volume = new BigDecimal(tmpString);

        return retVal;
    }

}
