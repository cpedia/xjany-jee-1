/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

public abstract class GeneralEvD1<N extends Number> extends EigenvalueDecomposition<N> {

    static final class Primitive extends GeneralEvD1<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY, new SymmetricEvD1.Primitive(), new NonsymmetricEvD1.Primitive());
        }

    }

    private final NonsymmetricEvD1<N> myNonsymmetric;

    private final SymmetricEvD1<N> mySymmetric;
    private boolean mySymmetricOrNot = false;

    protected GeneralEvD1(final DecompositionStore.Factory<N> aFactory, final SymmetricEvD1<N> aSymmetric, final NonsymmetricEvD1<N> aNonsymmetric) {

        super(aFactory);

        mySymmetric = aSymmetric;
        myNonsymmetric = aNonsymmetric;
    }

    public boolean compute(final Access2D<N> aMtrx) {

        final int tmpDim = aMtrx.getRowDim();

        boolean tmpSymmetric = true;

        for (int j = 0; tmpSymmetric && (j < tmpDim); j++) {
            for (int i = j + 1; tmpSymmetric && (i < tmpDim); i++) {
                tmpSymmetric &= TypeUtils.isZero(aMtrx.doubleValue(i, j) - aMtrx.doubleValue(j, i));
            }
        }

        if (tmpSymmetric) {
            return this.computeSymmetric(aMtrx);
        } else {
            return this.computeNonsymmetric(aMtrx);
        }
    }

    public boolean computeNonsymmetric(final Access2D<N> aNonsymmetric) {

        this.reset();

        mySymmetricOrNot = false;

        return this.computed(myNonsymmetric.computeNonsymmetric(aNonsymmetric));
    }

    public boolean computeSymmetric(final Access2D<N> aSymmetric) {

        this.reset();

        mySymmetricOrNot = true;

        return this.computed(mySymmetric.computeSymmetric(aSymmetric));
    }

    public boolean equals(final MatrixStore<N> aMtrx, final NumberContext aCntxt) {
        if (mySymmetricOrNot) {
            return mySymmetric.equals(aMtrx, aCntxt);
        } else {
            return myNonsymmetric.equals(aMtrx, aCntxt);
        }
    }

    public MatrixStore<N> getD() {
        if (mySymmetricOrNot) {
            return mySymmetric.getD();
        } else {
            return myNonsymmetric.getD();
        }
    }

    public ComplexNumber getDeterminant() {
        if (mySymmetricOrNot) {
            return mySymmetric.getDeterminant();
        } else {
            return myNonsymmetric.getDeterminant();
        }
    }

    public Array1D<ComplexNumber> getEigenvalues() {
        if (mySymmetricOrNot) {
            return mySymmetric.getEigenvalues();
        } else {
            return myNonsymmetric.getEigenvalues();
        }
    }

    public ComplexNumber getTrace() {
        if (mySymmetricOrNot) {
            return mySymmetric.getTrace();
        } else {
            return myNonsymmetric.getTrace();
        }
    }

    public MatrixStore<N> getV() {
        if (mySymmetricOrNot) {
            return mySymmetric.getV();
        } else {
            return myNonsymmetric.getV();
        }
    }

    public boolean isFullSize() {
        if (mySymmetricOrNot) {
            return mySymmetric.isFullSize();
        } else {
            return myNonsymmetric.isFullSize();
        }
    }

    public boolean isOrdered() {
        if (mySymmetricOrNot) {
            return mySymmetric.isOrdered();
        } else {
            return myNonsymmetric.isOrdered();
        }
    }

    public boolean isSolvable() {
        if (mySymmetricOrNot) {
            return mySymmetric.isSolvable();
        } else {
            return myNonsymmetric.isSolvable();
        }
    }

    public boolean isSymmetric() {
        if (mySymmetricOrNot) {
            return mySymmetric.isSymmetric();
        } else {
            return myNonsymmetric.isSymmetric();
        }
    }

    @Override
    public void reset() {

        super.reset();

        myNonsymmetric.reset();
        mySymmetric.reset();

        mySymmetricOrNot = false;
    }

    @Override
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        if (mySymmetricOrNot) {
            return mySymmetric.solve(aRHS);
        } else {
            return myNonsymmetric.solve(aRHS);
        }
    }

    @Override
    MatrixStore<N> makeInverse() {
        if (mySymmetricOrNot) {
            return mySymmetric.makeInverse();
        } else {
            return myNonsymmetric.makeInverse();
        }
    }
}
