/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.jfree.data;

import java.awt.Paint;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.jfree.data.general.DefaultKeyedValues2DDataset;
import org.ojalgo.chart.Type;

import se.optimatika.jfree.chart.JFreeChartAdaptor;

/**
 * CategoryData
 *
 * @author apete
 */
public class KeyedValues2D extends JFreeChartBuilder {

    private String myCategoryAxisLabel;
    private final List<Paint> myColours = new ArrayList<Paint>();
    private final DefaultKeyedValues2DDataset myDataset = new DefaultKeyedValues2DDataset();
    private String myValueAxisLabel;

    public KeyedValues2D(Type aType) {
        super(aType);
    }

    @Override
    public JFreeChartAdaptor build(Type aType) {

        switch (aType) {

        case AreaChart:

            return this.createAreaChart(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        case BarChart:

            return this.createBarChart(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend(), myColours);

        case BarChart3D:

            return this.createBarChart3D(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        case LineChart:

            return this.createLineChart(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        case LineChart3D:

            return this.createLineChart3D(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        case MultiplePieChart:

            return this.createMultiplePieChart(this.getTitle(), myDataset, this.getJFreePriority(), this.isLegend());

        case MultiplePieChart3D:

            return this.createMultiplePieChart3D(this.getTitle(), myDataset, this.getJFreePriority(), this.isLegend());

        case StackedAreaChart:

            return this.createStackedAreaChart(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        case StackedBarChart:

            return this.createStackedBarChart(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        case StackedBarChart3D:

            return this.createStackedBarChart3D(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        case WaterfallChart:

            return this.createWaterfallChart(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend());

        default:

            return this.createBarChart(this.getTitle(), myCategoryAxisLabel, myValueAxisLabel, myDataset, this.getJFreeOrientation(), this.isLegend(), myColours);
        }
    }

    /**
     * Value Axis Label
     */
    public KeyedValues2D columnLabel(String aLabel) {
        myValueAxisLabel = aLabel;
        return this;
    }

    /**
     * Category Axis Label
     */
    public KeyedValues2D rowLabel(String aLabel) {
        myCategoryAxisLabel = aLabel;
        return this;
    }

    public void setValue(String aRowKey, String aColumnKey, Paint aPaint, BigDecimal aValue) {
        myDataset.setValue(aValue, aRowKey, aColumnKey);
        myColours.add(aPaint);
    }

}
