/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.series;

import java.awt.Color;
import java.util.Date;
import java.util.Map;
import java.util.SortedMap;

import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.TimeFilter;

public class DateSeries<N extends Number> extends AbstractTimeSeries<Date, N> {

    private final TimeFilter myFilter;

    public DateSeries(final CalendarDateUnit aResolution) {

        super(aResolution);

        myFilter = new TimeFilter(aResolution);
    }

    public DateSeries(final Date aReference, final CalendarDateUnit aResolution) {

        super(aResolution);

        myFilter = new TimeFilter(aReference, aResolution);
    }

    @SuppressWarnings("unused")
    private DateSeries(final Map<Long, N> aDelegate, final CalendarDateUnit aResolution) {

        super(aDelegate, aResolution);

        myFilter = new TimeFilter(aResolution);
    }

    DateSeries(final Map<Long, N> aDelegate, final Date aReference, final CalendarDateUnit aResolution) {

        super(aDelegate, aResolution);

        myFilter = new TimeFilter(aReference, aResolution);
    }

    DateSeries(final TimeInMillisSeries<N> aDelegate, final CalendarDateUnit aResolution) {

        super(aDelegate, aResolution);

        myFilter = new TimeFilter(aResolution);
    }

    @Override
    public DateSeries<N> colour(final Color aPaint) {
        return (DateSeries<N>) super.colour(aPaint);
    }

    public Date getReference() {
        return TimeFilter.makeDate(myFilter.getReference());
    }

    public DateSeries<N> headMap(final Date aToKey) {

        final SortedMap<Long, N> tmpMap = this.getInternalHeadMap(this.convertToTimeInMillis(aToKey));

        return new DateSeries<N>(tmpMap, this.getReference(), this.getResolution()).name(this.getName()).colour(this.getColour());
    }

    @Override
    public DateSeries<N> name(final String aName) {
        return (DateSeries<N>) super.name(aName);
    }

    @Override
    public DateSeries<N> resample(final CalendarDateUnit aResolution) {
        return (DateSeries<N>) super.resample(aResolution);
    }

    @Override
    public DateSeries<N> resample(final Date aFirstKey, final Date aLastKey, final CalendarDateUnit aResolution) {
        return (DateSeries<N>) super.resample(aFirstKey, aLastKey, aResolution);
    }

    public Date step(final Date anExternalKey) {
        return myFilter.step(anExternalKey);
    }

    public DateSeries<N> subMap(final Date aFromKey, final Date aToKey) {

        final SortedMap<Long, N> tmpMap = this.getInternalSubMap(this.convertToTimeInMillis(aFromKey), this.convertToTimeInMillis(aToKey));

        return new DateSeries<N>(tmpMap, this.getReference(), this.getResolution()).name(this.getName()).colour(this.getColour());
    }

    public DateSeries<N> tailMap(final Date aFromKey) {

        final SortedMap<Long, N> tmpMap = this.getInternalTailMap(this.convertToTimeInMillis(aFromKey));

        return new DateSeries<N>(tmpMap, this.getReference(), this.getResolution()).name(this.getName()).colour(this.getColour());
    }

    @Override
    protected Long convertToTimeInMillis(final Date aDate) {
        return myFilter.toTimeInMillis(aDate);
    }

    @Override
    protected DateSeries<N> make(final CalendarDateUnit aResolution) {
        return new DateSeries<N>(this.getReference(), this.getResolution()).name(this.getName()).colour(this.getColour());
    }

    @Override
    protected Date toExternalKey(final Long aTimeInMillis) {
        return new Date(aTimeInMillis);
    }

}
