/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package se.optimatika.ampl;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.ProgrammingError;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.BasicMatrix.Factory;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.netio.ASCII;
import org.ojalgo.netio.Batch;
import org.ojalgo.netio.Message;
import org.ojalgo.netio.SystemProcess;
import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ModelValidationException;
import org.ojalgo.optimisation.OptimisationModel;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.State;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.type.context.NumberContext;

public class JAMPL extends SystemProcess implements OptimisationModel, OptimisationSolver {

    public static boolean DEBUG = true;

    private static final String TIMES = " * ";
    private static final String PLUS = " + ";
    private static final String[] COMMAND_ARRAY = new String[] { "ampl", "-b" };
    private static final String LAST_COMMAND_PREFIX = "prompt";

    private Factory myMatrixFactory = PrimitiveMatrix.FACTORY;
    private boolean myMinimisation = true;
    private State myState = State.NEW;

    public JAMPL() {
        super(COMMAND_ARRAY, LAST_COMMAND_PREFIX);
    }

    public JAMPL(final ExpressionsBasedModel<?> aModel) {

        this();

        final Batch tmpBatch = new Batch();

        final Variable[] tmpVars = aModel.getVariables();
        for (int i = 0; i < tmpVars.length; i++) {
            tmpBatch.add(Command.VAR.toMessage(this.toArgumentString(tmpVars[i])));
        }

        final Expression tmpObj = aModel.getObjectiveExpression();
        if (aModel.isMinimisation()) {
            tmpBatch.add(Command.MINIMIZE.toMessage(this.toArgumentString(tmpVars, tmpObj)));
        } else {
            tmpBatch.add(Command.MAXIMIZE.toMessage(this.toArgumentString(tmpVars, tmpObj)));
        }

        final Expression[] tmpExprs = aModel.getExpressions();
        for (int i = 0; i < tmpExprs.length; i++) {

            if (tmpExprs[i].isLowerConstraint()) {

            }

            if (tmpExprs[i].isUpperConstraint()) {

            }

            if (tmpExprs[i].isUpperConstraint()) {

            }
        }
    }

    @SuppressWarnings("unused")
    private JAMPL(final String[] aCommandArray, final String aLastCommandPrefix) {

        super(aCommandArray, aLastCommandPrefix);

        ProgrammingError.throwForIllegalInvocation();
    }

    public List<Message> communicate(final Command aCommand) {
        return this.communicate(aCommand.toMessage());
    }

    public List<Message> communicate(final Command aCommand, final String anArg) {
        return this.communicate(aCommand.toMessage(anArg));
    }

    public OptimisationSolver getDefaultSolver() {
        return this;
    }

    public Factory getMatrixFactory() {
        return myMatrixFactory;
    }

    public State getState() {
        return myState;
    }

    public BigDecimal getValue() {
        return null;
    }

    public boolean isMaximisation() {
        return !myMinimisation;
    }

    public boolean isMinimisation() {
        return myMinimisation;
    }

    public BigDecimal maximise() {

        if (!myMinimisation) {
            //myState = this.solve();
        } else {
            // TODO Auto-generated method stub
        }

        return null;
    }

    public BigDecimal minimise() {

        if (myMinimisation) {
            //myState = this.solve();
        } else {
            // TODO Auto-generated method stub
        }

        return null;
    }

    public void reset() {

        this.communicate(Command.RESET);

        myState = State.NEW;
    }

    public void setMatrixFactory(final Factory aMatrixFactory) {
        myMatrixFactory = aMatrixFactory;
    }

    public void setMaximisation(final boolean aFlag) {
        myMinimisation = aFlag;
    }

    public void setMinimisation(final boolean aFlag) {
        myMinimisation = aFlag;
    }

    public OptimisationSolver.Result solve() {

        this.communicate(Command.SOLVE);

        //  List<Message> tmpVal = this.communicate(Command.SOLVE);
        // TODO something

        return new OptimisationSolver.Result(myState, null, 1);
    }

    public Result solve(final OptimisationModel aValidationModel) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void terminate() {

        this.communicate(Command.QUIT);

        super.terminate();
    }

    public String toArgumentString(final Variable aVar) {

        final StringBuilder retVal = new StringBuilder();

        retVal.append(aVar.getName());

        if (aVar.isBinary()) {
            retVal.append(ASCII.SP);
            retVal.append("binary");
        } else {
            if (aVar.isInteger()) {
                retVal.append(ASCII.SP);
                retVal.append("integer");
            }
            if (aVar.isLowerConstraint()) {
                retVal.append(ASCII.SP);
                retVal.append(">=");
                retVal.append(aVar.getLowerLimit());
            }
            if (aVar.isUpperConstraint()) {
                retVal.append(ASCII.SP);
                retVal.append("<=");
                retVal.append(aVar.getUpperLimit());
            }
        }

        if (aVar.getValue() != null) {
            retVal.append(ASCII.SP);
            retVal.append(":=");
            retVal.append(aVar.getValue());
        }

        return retVal.toString();
    }

    public String toArgumentString(final Variable[] theVars, final Expression aFunction) {

        final StringBuilder retVal = new StringBuilder();

        if (aFunction.hasConstant()) {
            retVal.append(aFunction.getConstant());
        }

        if (aFunction.hasConstant() && aFunction.hasLinear()) {
            retVal.append(PLUS);
        }

        if (aFunction.hasLinear()) {

            final PhysicalStore<BigDecimal> tmpLin = aFunction.getLinear().getFactors();

            retVal.append(tmpLin.doubleValue(0, 0));
            retVal.append(TIMES);
            retVal.append(theVars[0].getName());

            for (int i = 1; i < theVars.length; i++) {
                retVal.append(PLUS);
                retVal.append(tmpLin.doubleValue(i, 0));
                retVal.append(TIMES);
                retVal.append(theVars[i].getName());
            }
        }

        if (aFunction.hasLinear() && aFunction.hasQuadratic()) {
            retVal.append(PLUS);
        }

        if (aFunction.hasQuadratic()) {

            final PhysicalStore<BigDecimal> tmpQuad = aFunction.getQuadratic().getFactors();

            retVal.append(tmpQuad.doubleValue(0, 0));
            retVal.append(TIMES);
            retVal.append(theVars[0].getName());
            retVal.append(TIMES);
            retVal.append(theVars[0].getName());

            for (int j = 1; j < theVars.length; j++) {
                retVal.append(PLUS);
                retVal.append(tmpQuad.doubleValue(0, j));
                retVal.append(TIMES);
                retVal.append(theVars[0].getName());
                retVal.append(TIMES);
                retVal.append(theVars[j].getName());
            }

            for (int i = 1; i < theVars.length; i++) {
                for (int j = 0; j < theVars.length; j++) {
                    retVal.append(PLUS);
                    retVal.append(tmpQuad.doubleValue(i, j));
                    retVal.append(TIMES);
                    retVal.append(theVars[i].getName());
                    retVal.append(TIMES);
                    retVal.append(theVars[j].getName());
                }
            }
        }

        return retVal.toString();
    }

    public boolean validateComposition() throws ModelValidationException {
        // TODO Auto-generated method stub
        return false;
    }

    public boolean validateSolution(final BasicMatrix aSolution, final NumberContext aContext) {
        // TODO Auto-generated method stub
        return false;
    }

    public boolean validateSolution(final NumberContext aContext) {
        // TODO Auto-generated method stub
        return false;
    }

}
